#!/usr/bin/env bash
set -euo pipefail
cd /mnt/c/Users/Jinho/.codex/.chatgpt-projects/g-p-6ad1e56cf8f881919fe23e1ab94d2855/work/Pysical_AI_ROS2_13_6_final_validation_20261104_v13
export CH13_REUSE_BUILD=/home/jinho/ch13_reuse_13_6_guide_validation_v13_20261104
export CH13_REUSE_VENV=/home/jinho/ch13_reuse_iit_d010212_venv
export PYTHONDONTWRITEBYTECODE=1
validation_out=/mnt/c/Users/Jinho/.codex/.chatgpt-projects/g-p-6ad1e56cf8f881919fe23e1ab94d2855/work/Pysical_AI_ROS2_reuse/.superpowers/sdd/SECTION_13_6_REUSE_IMPLEMENTATION_PLAN_KO
"$CH13_REUSE_VENV/bin/python" Ch13/scripts/reuse_13_6/freeze_runtime.py verify Ch13/dependencies/section_13_6_reuse_acceptance_v13.json > "$validation_out/download_freeze_v13.log" 2>&1
if [[ -e "$CH13_REUSE_BUILD" ]]; then echo 'fresh validation build already exists'; exit 2; fi
bash Ch13/scripts/reuse_13_6/build.sh > "$validation_out/download_build_v13.log" 2>&1
bash Ch13/scripts/reuse_13_6/env.sh Ch13/scripts/reuse_13_6/audit_install.py "$validation_out/download_install_v13.json" > "$validation_out/download_install_v13.log" 2>&1
for validation_uuid in 20662d06-ec82-4232-8a8a-6426d347557e 4448d833-3500-4108-8b00-2464f67aba00 70837980-da92-49a0-b542-563a5f07f2c2 a854efd7-67fc-4964-aced-0fd36b59f7bf; do
  if [[ -e Ch13/evidence/section_13_6_reuse/$validation_uuid/run/engine.json ]]; then echo 'expected empty restoration target'; exit 2; fi
done
bash Ch13/scripts/reuse_13_6/env.sh Ch13/scripts/reuse_13_6/restore_evidence.py Ch13/evidence/section_13_6_reuse/20662d06-ec82-4232-8a8a-6426d347557e Ch13/evidence/section_13_6_reuse/4448d833-3500-4108-8b00-2464f67aba00 Ch13/evidence/section_13_6_reuse/70837980-da92-49a0-b542-563a5f07f2c2 Ch13/evidence/section_13_6_reuse/a854efd7-67fc-4964-aced-0fd36b59f7bf > "$validation_out/download_restore_v13.log" 2>&1
bash Ch13/scripts/reuse_13_6/env.sh Ch13/scripts/reuse_13_6/verify_pick.py Ch13/evidence/section_13_6_reuse/20662d06-ec82-4232-8a8a-6426d347557e > "$validation_out/download_pick_v13.log" 2>&1
bash Ch13/scripts/reuse_13_6/env.sh Ch13/scripts/reuse_13_6/verify_held_cancel.py Ch13/evidence/section_13_6_reuse/4448d833-3500-4108-8b00-2464f67aba00 > "$validation_out/download_held_v13.log" 2>&1
bash Ch13/scripts/reuse_13_6/env.sh Ch13/scripts/reuse_13_6/verify_moveit.py Ch13/evidence/section_13_6_reuse/70837980-da92-49a0-b542-563a5f07f2c2 > "$validation_out/download_moveit_v13.log" 2>&1
bash Ch13/scripts/reuse_13_6/env.sh Ch13/verification/reuse_13_6/review_loss.py Ch13/evidence/section_13_6_reuse/a854efd7-67fc-4964-aced-0fd36b59f7bf "$validation_out/download_loss_review_v13.json" > "$validation_out/download_loss_review_v13.log" 2>&1
bash Ch13/scripts/reuse_13_6/env.sh Ch13/scripts/reuse_13_6/run_tests.py Ch13/verification/reuse_13_6/test_loss_review.py > "$validation_out/download_grader_tests_v13.log" 2>&1
printf 'DOWNLOAD_VALIDATION_PASS\n'