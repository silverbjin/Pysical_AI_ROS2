import hashlib,importlib.util,json
from pathlib import Path
root=Path.cwd()
base=root/'Ch13/evidence/section_13_6_reuse'
scratch=root/'.superpowers/sdd/SECTION_13_6_REUSE_IMPLEMENTATION_PLAN_KO'
index=json.loads((base/'ACCEPTANCE_V13.json').read_text())
assert len(index['cases'])==16 and len({c['uuid'] for c in index['cases']})==16
assert (index['original_pass'],index['original_fail'],index['reviewed_pass'])==(15,1,1)
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,expected in index['grading_files_sha256'].items():
    assert digest(root/'Ch13/verification/reuse_13_6'/name)==expected
spec=importlib.util.spec_from_file_location('freeze',root/'Ch13/scripts/reuse_13_6/freeze_runtime.py')
freeze=importlib.util.module_from_spec(spec);spec.loader.exec_module(freeze)
manifest=json.loads((root/'Ch13/dependencies'/index['runtime_freeze']).read_text())
assert freeze.sources()==manifest['source'] and len(manifest['source'])==248
assert digest(root/'Ch13/dependencies'/index['runtime_freeze'])==index['runtime_freeze_sha256']
for case in index['cases']:
    folder=base/case['uuid'];run=folder/'run'
    s=json.loads((run/'navigation_summary.json').read_text());e=json.loads((run/'engine.json').read_text())
    assert s['result']=='PASS' and not s['remaining_launch_pids'] and s['clean_launch_exits']==len(s['owned_launch_pids'])
    assert e['result']=='COMPLETED' and e['normal_shutdown_requested'] and e['rx_joined'] and e['upstream_threads_joined']
    assert e['max_force_cap_ratio']<=1.+1e-8
    assert json.loads((folder/'post_residual.json').read_text())['result']=='PASS'
    assert json.loads((folder/'matrix_residual.json').read_text())['result']=='PASS'
    assert json.loads((folder/'freeze_audit.json').read_text())['manifest_sha256']==index['runtime_freeze_sha256']
    if case['case']=='nav_raw_loss':
        assert json.loads((run/'navigation_verification.json').read_text())['result']=='FAIL'
        review=json.loads((folder/case['review']).read_text())
        assert review['result']=='PASS' and review['legacy_result']=='FAIL'
        assert digest(root/'Ch13/verification/reuse_13_6/review_loss.py')==review['reviewer_sha256']
        for name,expected in review['input_sha256'].items():assert digest(root/name)==expected
    else:
        path=run/'navigation_verification.json' if case['case'].startswith('nav_') else folder/'verification.log'
        results=json.loads(path.read_text());results=results if isinstance(results,list) else [results]
        assert results and all(r['result']=='PASS' for r in results)
assert '199 passed' in (scratch/'subtick_full_suite.log').read_text()
assert '12 passed' in (scratch/'download_grader_tests_v13.log').read_text()
assert 'DOWNLOAD_VALIDATION_PASS' in (scratch/'download_validation_retry_v13.log').read_text()
assert json.loads((scratch/'final_residual_v13.json').read_text())['result']=='PASS'
print(json.dumps(dict(result='PASS',runtime_source_files=248,cases=16,legacy_pass=15,legacy_fail_preserved=1,reviewed_pass=1,download_validation=True)))