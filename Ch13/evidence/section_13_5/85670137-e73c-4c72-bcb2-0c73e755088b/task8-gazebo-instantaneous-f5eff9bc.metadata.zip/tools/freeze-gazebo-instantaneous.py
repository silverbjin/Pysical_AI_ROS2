"""Exclusive byte-exact checkpoint archive. Original FAIL and files stay intact."""
import hashlib
import json
from pathlib import Path
import zipfile

repo = Path.cwd().resolve()
base = repo/'Ch13/evidence/section_13_5/85670137-e73c-4c72-bcb2-0c73e755088b'
name = 'native-g1-gazebo-f5eff9bc-cc1a-49f1-a3d9-fc158b9b43db'
root = base/name
manifest = json.loads((root/'source_manifest.json').read_text())
archive = base/'task8-gazebo-instantaneous-f5eff9bc.zip'
ledger = archive.with_suffix('.json')
assert not archive.exists() and not ledger.exists()
members = {}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as output:
    def add(path,label,expected=None):
        raw = path.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        assert expected is None or digest == expected, path
        assert label not in members and not Path(label).is_absolute() and '..' not in Path(label).parts
        output.writestr(label,raw)
        members[label] = dict(size=len(raw),sha256=digest)
    for relative,digest in manifest['files'].items():
        add(repo/relative,'sources/'+relative,digest)
    for directory in (root,root.with_name(name+'-prepared')):
        for path in sorted(directory.rglob('*')):
            if path.is_file(): add(path,'evidence/'+str(path.relative_to(base)))
    for label in ('task8-instant-reference-navigation-full.log',
            'task8-gazebo-ecm-reference-frozen-green-build.log',
            'task8-gazebo-ecm-reference-frozen-green-test.log',
            'task8-gazebo-ecm-reference-frozen-green-install-audit.json',
            'task8-gazebo-instant-reference-red.log','task8-gazebo-instant-reference-green.log',
            'task8-gazebo-ecm-reference-native-red.log',
            'task8-gazebo-ecm-reference-native-red-confirmed.log'):
        add(base/label,'verification/'+label)
    add(Path(__file__),'tools/freeze-gazebo-instantaneous.py')
with zipfile.ZipFile(archive) as saved:
    assert saved.testzip() is None
    for label,record in members.items():
        assert hashlib.sha256(saved.read(label)).hexdigest() == record['sha256']
value = dict(scope='checkpoint_not_G1_completion',original_status='FAIL',
    source_count=len(manifest['files']),source_head=manifest['head'],
    archive=archive.name,size=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
    source_manifest_sha256=hashlib.sha256((root/'source_manifest.json').read_bytes()).hexdigest(),
    members=members,originals_retained=True)
assert value['size'] < 95_000_000, 'do not stage an oversized GitHub artifact'
with ledger.open('x') as stream: json.dump(value,stream,indent=2,allow_nan=False)
print(json.dumps({key:val for key,val in value.items() if key != 'members'},indent=2))
