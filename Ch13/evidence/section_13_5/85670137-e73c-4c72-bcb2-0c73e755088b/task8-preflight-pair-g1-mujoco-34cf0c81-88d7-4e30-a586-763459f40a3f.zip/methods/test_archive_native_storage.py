import json,zipfile,hashlib
from pathlib import Path
import pytest
from archive_native_storage import export_closed,archive_sources

def case(tmp_path):
    native=tmp_path/'native';native.mkdir();original=native/'native-g2-mujoco-unit';original.mkdir()
    evidence=tmp_path/'evidence';evidence.mkdir();destination=evidence/original.name
    (original/'teardown.json').write_text(json.dumps(dict(parent_reaped=True,residual_live_pids=[])))
    (original/'result.json').write_text('{"status":"FAIL"}')
    (original/'observations.capture').write_bytes(b'original raw '*1000)
    return native,original,destination

def test_large_original_streams_to_identical_archive_without_duplicate_or_deletion(tmp_path):
    native,original,destination=case(tmp_path)
    ledger=export_closed(original,destination,native,archive_large=True,threshold=300)
    assert not (destination/'observations.capture').exists()
    assert (destination/'result.json').is_file(),'small verdict must be copied before archive admission'
    assert (destination/'result.json').read_bytes()==(original/'result.json').read_bytes()
    (destination/'storage-copy-ledger.json').write_text(json.dumps(ledger))
    records=archive_sources(destination,native)
    packed=tmp_path/'full.zip'
    with zipfile.ZipFile(packed,'w',compression=zipfile.ZIP_DEFLATED) as out:
        for path,name,expected in records:
            data=path.read_bytes();assert hashlib.sha256(data).hexdigest()==expected
            out.writestr(name,data)
    with zipfile.ZipFile(packed) as out:
        assert out.read('observations.capture')==(original/'observations.capture').read_bytes()
        assert json.loads(out.read('result.json'))['status']=='FAIL'
        assert out.testzip() is None
    assert (original/'observations.capture').is_file()

def test_default_still_makes_every_byte_exact_copy(tmp_path):
    native,original,destination=case(tmp_path)
    export_closed(original,destination,native)
    assert (destination/'observations.capture').read_bytes()==(original/'observations.capture').read_bytes()

@pytest.mark.parametrize('closed',[dict(parent_reaped=False,residual_live_pids=[]),dict(parent_reaped=True,residual_live_pids=[33])])
def test_no_export_before_confirmed_reap_and_residual_inspection(tmp_path,closed):
    native,original,destination=case(tmp_path);(original/'teardown.json').write_text(json.dumps(closed))
    with pytest.raises(RuntimeError):export_closed(original,destination,native,archive_large=True)
    assert not destination.exists()

def test_descriptor_cannot_read_outside_owned_native_root(tmp_path):
    native,original,destination=case(tmp_path);destination.mkdir()
    (destination/'storage-copy-ledger.json').write_text(json.dumps(dict(archive_from_native=True,native_original=str(tmp_path),files={})))
    with pytest.raises(RuntimeError):archive_sources(destination,native)

def test_modified_small_copy_or_original_is_not_accepted(tmp_path):
    native,original,destination=case(tmp_path)
    ledger=export_closed(original,destination,native,archive_large=True,threshold=300)
    (destination/'storage-copy-ledger.json').write_text(json.dumps(ledger))
    (destination/'result.json').write_text('{"status":"PASS"}')
    with pytest.raises(RuntimeError):archive_sources(destination,native)

def test_failure_before_engine_start_is_still_preserved_without_success_promotion(tmp_path):
    native,original,destination=case(tmp_path)
    (original/'teardown.json').write_text(json.dumps(dict(parent_reaped=False,residual_live_pids=[])))
    (original/'result.json').write_text(json.dumps(dict(status='FAIL',engine_started=False)))
    export_closed(original,destination,native,archive_large=True)
    assert json.loads((destination/'result.json').read_text())==dict(status='FAIL',engine_started=False)
