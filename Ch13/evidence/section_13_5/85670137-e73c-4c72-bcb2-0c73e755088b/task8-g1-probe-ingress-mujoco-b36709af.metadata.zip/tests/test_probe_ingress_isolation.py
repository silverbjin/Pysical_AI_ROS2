"""Native input queue must not share control/clock/RPC head-of-line waits."""
import threading
import time
import pytest
import rclpy
from rclpy.context import Context
from rclpy.clock import Clock
from rclpy.clock_type import ClockType
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from integrated_robot_interfaces.msg import FootContacts
from probe_navigation_13_5 import NavigationProbe,ProbeReceiver


def test_native_ingress_keeps_original_receipts_while_main_queue_waits(tmp_path):
    context=Context();rclpy.init(context=context)
    probe=NavigationProbe(tmp_path,engine='gazebo',bounded_history=True,context=context)
    peer=Node('isolated_probe_input_peer',context=context)
    publisher=peer.create_publisher(FootContacts,'/navigation/foot_contacts',qos_profile_sensor_data)
    entered,release=threading.Event(),threading.Event();receiver=None
    def blocked():
        timer.cancel();entered.set();assert release.wait(3.)
    timer=probe.create_timer(.01,blocked,clock=Clock(clock_type=ClockType.STEADY_TIME))
    try:
        receiver=ProbeReceiver(probe);assert entered.wait(1.)
        message=FootContacts();message.header.frame_id='odom'
        message.names=['fr_foot','fl_foot','rr_foot','rl_foot']
        sent=time.monotonic_ns();message.header.stamp.sec=17;message.sequence=77
        deadline=time.monotonic()+.15;selected=None
        while time.monotonic()<deadline:
            publisher.publish(message);time.sleep(.005)
            with probe._lock:selected=probe.inbox.pending['contacts'].get(17_000_000_000)
            if selected is not None:break
        assert selected is not None,'native capture waited behind the blocked main queue'
        assert sent<=selected.received_ns<=time.monotonic_ns()
        assert time.monotonic_ns()-selected.received_ns<100_000_000
        assert selected.stamp_ns==17_000_000_000
        assert not probe.frames,'isolated input is not synthetic complete physics feedback'
        assert sum(s.topic_name=='/clock' for n in (probe,probe.ingress_node,probe.recording_node) for s in n.subscriptions)==1
        assert not any(s.topic_name=='/clock' for s in probe.ingress_node.subscriptions)
    finally:
        release.set()
        if receiver:assert receiver.shutdown(timeout_sec=2.)
        probe.close_log();probe.destroy_node();peer.destroy_node();context.try_shutdown()


def test_unfinished_ingress_retains_all_ros_resources_and_failure_is_sticky(tmp_path):
    context=Context();rclpy.init(context=context)
    probe=NavigationProbe(tmp_path,engine='gazebo',bounded_history=True,context=context)
    entered,release=threading.Event(),threading.Event();receiver=None
    try:
        assert getattr(probe,'ingress_node',None) is not None
        def blocked():entered.set();assert release.wait(3.);raise ValueError('native ingress fault fixture')
        probe.ingress_node.create_timer(.01,blocked,clock=Clock(clock_type=ClockType.STEADY_TIME))
        receiver=ProbeReceiver(probe);assert entered.wait(1.)
        assert not receiver.shutdown(timeout_sec=.01)
        assert not receiver.closed and receiver.ingress_receiver.thread.is_alive()
        assert probe.ingress_node.context.ok()
        release.set()
        assert receiver.shutdown(timeout_sec=2.)
        with pytest.raises(RuntimeError,match='native ingress fault fixture'):receiver.check()
        report=receiver.report()
        assert report['closed'] and report['ingress']['closed'] and report['recording']['closed']
        assert not report['ingress']['thread_alive'] and not report['recording']['thread_alive']
    finally:
        release.set()
        if receiver:assert receiver.shutdown(timeout_sec=2.)
        probe.close_log();probe.destroy_node();context.try_shutdown()
