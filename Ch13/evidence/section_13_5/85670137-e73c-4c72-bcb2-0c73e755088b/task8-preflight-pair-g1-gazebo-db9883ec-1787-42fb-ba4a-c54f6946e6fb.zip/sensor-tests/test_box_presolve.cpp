// SPDX-License-Identifier: Apache-2.0
#include "integrated_robot_navigation_sensors/box_presolve.hpp"
#include <gtest/gtest.h>
using integrated_robot_navigation_sensors::strict_box_rows;
using Eigen::MatrixXd;using Eigen::VectorXd;

TEST(BoxPresolve,OriginalAndPresolvedFeasibleSetsAgreeOnTheSameBox) {
  MatrixXd a(4,2);a<<1.,1.,-2.,0.,.1,.1,0.,1.;
  VectorXd b(4);b<<.5,3.,1.,1.;
  VectorXd lo=VectorXd::Constant(2,-1.),hi=VectorXd::Ones(2);
  const auto keep=strict_box_rows(a,b,lo,hi);
  ASSERT_EQ(keep,(std::vector<Eigen::Index>{0,3}));
  for(int i=0;i<=40;++i) {for(int j=0;j<=40;++j) {
    VectorXd x(2);x<<-1.+i*.05,-1.+j*.05;
    bool reduced=true;for(auto r:keep) {reduced=reduced && a.row(r).dot(x)<=b(r)+1e-12;}
    EXPECT_EQ(reduced,(a*x-b).maxCoeff()<=1e-12);
  }}
}
TEST(BoxPresolve,FixedCoordinatesAndNonzeroOffsetsUseOriginalBounds) {
  MatrixXd a(2,2);a<<100.,1.,-100.,-1.;VectorXd b(2);b<<200.5,-198.;
  VectorXd lo(2),hi(2);lo<<2.,-1.;hi<<2.,1.;
  EXPECT_EQ(strict_box_rows(a,b,lo,hi),(std::vector<Eigen::Index>{0}));
}
TEST(BoxPresolve,BoundaryAndRoundingUncertaintyAreNeverPruned) {
  MatrixXd a=MatrixXd::Ones(1,2);VectorXd b=VectorXd::Constant(1,2.+1e-15);
  EXPECT_EQ(strict_box_rows(a,b,VectorXd::Constant(2,-1.),VectorXd::Ones(2)).size(),1u);
}
TEST(BoxPresolve,InvalidInputsFailClosed) {
  MatrixXd a=MatrixXd::Ones(1,2);VectorXd b=VectorXd::Ones(1),lo=VectorXd::Zero(2),hi=VectorXd::Ones(2);
  hi(0)=-1.;EXPECT_THROW(strict_box_rows(a,b,lo,hi),std::invalid_argument);
  hi.setOnes();a(0,0)=std::numeric_limits<double>::quiet_NaN();
  EXPECT_THROW(strict_box_rows(a,b,lo,hi),std::invalid_argument);
}

MatrixXd facets() {
  MatrixXd a(8,3);
  for(int r=0;r<8;++r) {for(int c=0;c<3;++c) {a(r,c)=(r&(1<<(2-c))) ? 1. : -1.;}}
  return a;
}
TEST(BoxPresolve,L1FacetsImplyOmittedUnitBoundsOverOriginalAndExteriorGrid) {
  const auto a=facets();VectorXd b=VectorXd::Ones(8),lo=VectorXd::Constant(3,-1.),hi=VectorXd::Ones(3);
  const auto bounds=integrated_robot_navigation_sensors::l1_implied_unit_bounds(a,b,0,lo,hi);
  EXPECT_TRUE((bounds.first.array()==-std::numeric_limits<double>::infinity()).all());
  EXPECT_TRUE((bounds.second.array()==std::numeric_limits<double>::infinity()).all());
  for(int i=-8;i<=8;++i) {for(int j=-8;j<=8;++j) {for(int k=-8;k<=8;++k) {
    VectorXd x(3);x<<i*.25,j*.25,k*.25;
    const bool l1=(a*x-b).maxCoeff()<=1e-12;
    EXPECT_EQ(l1,l1 && (x-lo).minCoeff()>=-1e-12 && (hi-x).minCoeff()>=-1e-12);
  }}}
}
TEST(BoxPresolve,FixedAndNonunitEnvelopeBoundsStayAndMissingProofFailsClosed) {
  auto a=facets();VectorXd b=VectorXd::Ones(8),lo(3),hi(3);lo<<0.,-1.,-.2;hi<<0.,1.,.3;
  const auto bounds=integrated_robot_navigation_sensors::l1_implied_unit_bounds(a,b,0,lo,hi);
  EXPECT_EQ(bounds.first(0),0.);EXPECT_EQ(bounds.second(0),0.);
  EXPECT_EQ(bounds.first(2),-.2);EXPECT_EQ(bounds.second(2),.3);
  a(0,0)=-.9;
  EXPECT_THROW(integrated_robot_navigation_sensors::l1_implied_unit_bounds(a,b,0,lo,hi),std::invalid_argument);
}
