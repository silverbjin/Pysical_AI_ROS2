#!/usr/bin/env bash
set -e
cd /mnt/c/Users/Jinho/.codex/.chatgpt-projects/g-p-6ad1e56cf8f881919fe23e1ab94d2855/work/Pysical_AI_ROS2
source .superpowers/sdd/SECTION_13_5_IMPLEMENTATION_PLAN_KO/env-native.sh
label=$1
test ! -e "$CH13_NAV_EVIDENCE/$label-build.log"
python /usr/bin/colcon --log-base "$CH13_NAV_LOG" build --base-paths Ch13/ros2_ws/src --build-base "$CH13_NAV_BUILD" --install-base "$CH13_NAV_INSTALL" --packages-select integrated_robot_runtime integrated_robot_navigation --executor sequential > "$CH13_NAV_EVIDENCE/$label-build.log" 2>&1 || { tail -n 35 "$CH13_NAV_EVIDENCE/$label-build.log"; exit 1; }
tail -n 12 "$CH13_NAV_EVIDENCE/$label-build.log"
bash .superpowers/sdd/SECTION_13_5_IMPLEMENTATION_PLAN_KO/audit-native.sh "$label-install-audit"
python - "$CH13_NAV_EVIDENCE/$label-runtime-audit" <<'PY'
from pathlib import Path
import sys
sys.path.insert(0,str(Path.cwd()/'Ch13/scripts'))
from run_navigation_13_5 import audit_runtime
output=Path(sys.argv[1]);output.mkdir(exist_ok=False)
audit_runtime(Path.cwd(),output)
print('Strict runtime/vision/navigation source bytes and installed backend audit passed')
PY
