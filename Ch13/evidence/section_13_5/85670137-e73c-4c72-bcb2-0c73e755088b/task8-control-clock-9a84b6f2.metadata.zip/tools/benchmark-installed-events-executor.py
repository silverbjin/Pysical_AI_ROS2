"""Same ordered DDS workload, installed upstream executors, no engine PASS."""
import hashlib
import json
from pathlib import Path
import sys
import time
import rclpy
from rclpy.context import Context
from rclpy.event_handler import PublisherEventCallbacks,SubscriptionEventCallbacks
from rclpy.executors import SingleThreadedExecutor
from rclpy.experimental.events_executor import EventsExecutor
from rclpy.node import Node
from std_msgs.msg import String
rows=[]
for name,factory in (('waitset',SingleThreadedExecutor),('events',EventsExecutor)):
    context=Context();rclpy.init(context=context,domain_id=164)
    node=Node('executor_cost_fixture',context=context);executor=factory(context=context)
    received=[[] for _ in range(8)];publishers=[]
    try:
        for i in range(8):
            topic='/executor_cost/ch'+str(i)
            publishers.append(node.create_publisher(String,topic,100,
                event_callbacks=PublisherEventCallbacks(use_default_callbacks=False)))
            node.create_subscription(String,topic,lambda msg,index=i:received[index].append(int(msg.data)),100,
                event_callbacks=SubscriptionEventCallbacks(use_default_callbacks=False))
        executor.add_node(node);end=time.monotonic()+2.
        while not all(p.get_subscription_count()==1 for p in publishers):
            assert time.monotonic()<end
            executor.spin_once(timeout_sec=.01)
        sent=[0]
        def publish():
            sent[0]+=1
            for p in publishers:p.publish(String(data=str(sent[0])))
        timer=node.create_timer(.02,publish)
        cpu=time.process_time_ns();start=time.monotonic_ns();end=start+4_000_000_000
        while time.monotonic_ns()<end:executor.spin_once(timeout_sec=.05)
        elapsed=time.monotonic_ns()-start;cpu=time.process_time_ns()-cpu;timer.cancel()
        for _ in range(32):executor.spin_once(timeout_sec=.001)
        assert all(v==list(range(1,sent[0]+1)) for v in received),(name,sent,list(map(len,received)))
        rows.append(dict(executor=name,messages=sum(map(len,received)),wall_ns=elapsed,
            process_cpu_ns=cpu,cpu_ns_per_message=cpu/sum(map(len,received))))
    finally:
        executor.shutdown();node.destroy_node();rclpy.shutdown(context=context)
wrapper=Path('/opt/ros/jazzy/lib/python3.12/site-packages/rclpy/experimental/events_executor.py')
value=dict(scope='installed7.1.12_8topic50Hz_REAL_DDS_NOT_actual_stack_or_acceptance',
    upstream_tag_commit='bd637294dd02b1c128422395c059fa06df8387a3',
    wrapper_sha256=hashlib.sha256(wrapper.read_bytes()).hexdigest(),rows=rows)
payload=json.dumps(value,indent=2)
with Path(sys.argv[1]).open('x') as output:output.write(payload)
print(payload)
