"""Predeclared three-run verification, STOP at first FAIL, never a retry loop."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import uuid

repo=Path.cwd();task=Path(__file__).parent
base=repo/'Ch13/evidence/section_13_5/85670137-e73c-4c72-bcb2-0c73e755088b'
key=str(uuid.uuid4());ledger=base/('task8-fixed-g1-gazebo-series-'+key+'.json')
state=dict(series_uuid=key,planned_runs=3,stop_on_first_failure=True,
    scope='fixed_source_Gazebo_G1_only_not_G2_Nav2_or_13_5_completion',runs=[],status='RUNNING')
assert not ledger.exists()
def save():
    temporary=ledger.with_suffix('.tmp');temporary.write_text(json.dumps(state,indent=2)+'\n')
    os.replace(temporary,ledger)
save();print(json.dumps(dict(series=str(ledger))),flush=True)
reference=None
environment=dict(os.environ,CH13_CONTROL_CLOCK_MODE='relay100',CH13_G1_REFERENCE_RAMP='ramp20ms',
    CH13_G1_CONTACT_ALLOWANCE='allowance50um')
for name in ('CH13_THREAD_CPU_DIAGNOSTIC','CH13_G1_PROFILE_NODE'):environment.pop(name,None)
for index in range(1,4):
    if reference is not None:
        assert all(hashlib.sha256((repo/p).read_bytes()).hexdigest()==sha for p,sha in reference.items()),'source changed between verification runs'
    before=set(p.name for p in base.glob('native-g1-gazebo-*') if not p.name.endswith('-prepared'))
    environment['CH13_GZ_TRIAL_PURPOSE']=f'fixed-source-draining-G1-series-{key}-case-{index}-of-3'
    print(json.dumps(dict(event='start',index=index)),flush=True)
    process=subprocess.run(['bash',str(task/'native-output-gz.sh')],env=environment)
    after=set(p.name for p in base.glob('native-g1-gazebo-*') if not p.name.endswith('-prepared'))
    fresh=after-before;assert len(fresh)==1,'one fresh serial owned trial required'
    root=base/fresh.pop();result=json.loads((root/'result.json').read_text())
    teardown=json.loads((root/'teardown.json').read_text())
    manifest=json.loads((root/'source_manifest.json').read_text())
    same=reference is None or manifest['files']==reference
    if reference is None:reference=manifest['files']
    clean=(teardown.get('parent_reaped') is True and teardown.get('residual_live_pids')==[]
        and teardown.get('forced_cleanup') is False)
    passed=(process.returncode==0 and result['status']=='PASS' and clean and same
        and all(result['checks'][key] is True for key in result['required_checks']))
    row=dict(index=index,trial=root.name,result_run_id=result['run_id'],original_status=result['status'],
        passed=passed,source_manifest_sha256=hashlib.sha256((root/'source_manifest.json').read_bytes()).hexdigest(),
        same_runtime_sources=same,cleanup_confirmed=clean)
    state['runs'].append(row);save()
    assert clean,'owned cleanup unconfirmed; no next engine or archive'
    log=base/('task8-fixed-series-freeze-'+root.name.removeprefix('native-g1-gazebo-')+'.log')
    with log.open('x') as output:
        archived=subprocess.run(['bash',str(task/'finish-control-clock-evidence.sh'),root.name],
            stdout=output,stderr=subprocess.STDOUT)
    assert archived.returncode==0,'source/evidence archive failed; do not continue'
    print(json.dumps(dict(event='finished',**row)),flush=True)
    if not passed:
        state['status']='FAIL';state['completed_consecutive_passes_before_failure']=index-1;save()
        raise SystemExit(1)
state['status']='PASS';state['completed_consecutive_passes']=3;save()
print(json.dumps(dict(event='series_complete',status='PASS',ledger=str(ledger))),flush=True)
