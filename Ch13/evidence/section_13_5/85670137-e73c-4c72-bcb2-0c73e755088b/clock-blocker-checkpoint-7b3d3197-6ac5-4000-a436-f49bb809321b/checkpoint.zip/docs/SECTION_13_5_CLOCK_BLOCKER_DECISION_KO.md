# 13.5 시각 차단 요인과 제한된 판별 실험

2026-10-27. 사용자가 일시 중지·복원 비교를 승인했다. 영구 설정을 변경하지 않는다.

## 실제 증거

`preflight-mujoco-pairs-cd782528-3efb-405e-8c83-6e753f4f9d4e`는 원본 SYSTEM/MONOTONIC을 40초 관측해 READY가 됐다. 이어진 시동·종료 회귀는 19개 모두 통과(30.51초)했지만, 같은 부팅의 uptime 131.280초에 SYSTEM−MONOTONIC 차이가 +1,594,437,682ns 변했다. 해당 시리즈는 엔진을 한 번도 시작하지 않고 중단했다. 앞선 부팅에서 ±2.3초 변동도 기록됐다. 40초 사전 관측은 이후 안정성을 보증하지 않는다.

현재 kernel은 6.18.40.1-microsoft-standard-WSL2, clocksource는 hyperv_clocksource_tsc_page다. 일반 사용자로 조회한 systemd-timesyncd는 활성 상태이며 외부 ntp.ubuntu.com에 동기화한다. 서비스의 존재와 시각 변동만으로 단독 원인을 확정하지 않는다.

[Ubuntu WSL 공식 문서](https://ubuntu.com/wsl/docs/stable/explanation/time-sync/)는 Hyper-V의 암묵적 동기화와 게스트 NTP가 충돌할 수 있음을 설명하고, Ubuntu 24.04의 timesyncd를 별도로 다룬다(문서 갱신 2026-10-20). [systemd 설명](https://www.freedesktop.org/software/systemd/man/253/systemd-timesyncd.service.html)은 큰 오차를 연속 보정 대신 step으로 바꿀 수 있음을 명시한다. 이 설명과 현상은 부합하지만 인과 관계는 비교로 확인해야 한다.

## 승인받을 구체적 변경

1. 최초 active/enabled 상태·부팅 ID·원본 시각과 서비스 로그를 저장한다.
2. Ubuntu-24.04 내부의 `systemd-timesyncd.service`만 해당 검증 세션 동안 `systemctl stop systemd-timesyncd.service`로 일시 중지한다. Linux root 권한이 필요하다. disable/mask·설정 파일 변경·시각 수동 변경·Windows 관리자·드라이버 변경은 하지 않는다.
3. 소유한 단일 부모 프로세스 아래에서 원본 SYSTEM/MONOTONIC을 같은 방법으로 관측한다. 역행이나 불연속이 계속되면 이 가설을 기각하고 실제 엔진을 시작하지 않는다. 안정될 경우 기존 사전 관측과 동일 회귀를 실행한다. 기존 원본 header·ROS/wall age·역행 latch를 유지한다.
4. 실제 엔진은 기존 순차·첫 실패 중단·reap/잔여/원본 SHA/아카이브 규칙을 유지한다. 시각 문제 해결은 G1/G2 물리 성공의 증거가 아니다.
5. 정상·실패 경로 모두에서 서비스의 원래 active 상태를 복원하고 상태를 기록한다. 비정상 중단 시 복원 필요 여부를 체크포인트에 남긴다. 원래 enabled 상태는 변경하지 않는다.

승인이 없으면 위 시스템 조작을 실행하지 않고, Ch13 내부의 독립적인 결함 수정·회귀와 차단 요인 문서화를 진행한다. 안전 검사를 끄거나 과거 실패를 제외하는 방식으로 진행하지 않는다.

## 첫 판별 결과와 다음 가설

`timesync-comparison-fa3e279b-5db5-4176-a0e1-ee42f9a0305b`는 일반 사용자75초 관측에서 uptime40.863초에 -7,327,677,899ns 변동을 기록했다. 실제 엔진은 시작하지 않았다. root 래퍼의 finally에서 서비스 active/enabled 복원을 확인했다. 서비스 중지만으로 모든 시각 변동이 사라진다는 가설은 기각한다.

단, 변동은 초기 약30초 지점 한 번이며 이후 약45초는 조용했다. 다음 판별은 Windows 원본 UTC/Stopwatch를 함께 기록하고, 이미 정의한 **40초 연속 quiet/150초 deadline** 게이트로 초기 보정 후의 안정 여부를 평가한다. 첫 진단의 추가 조건인 ‘75초 전체에 변동0회’는 부팅 시 초기 보정과 반복 불안정을 구분하지 못했다. 변경된 판별은 기존 Gate를 사용하고 원본 모든 변동을 보존한다. 이후 사전 관측·시동 회귀 중 다시 변하면 엔진을 시작하지 않으며, 실제 엔진의 원본 역행 보호와 물리 기준은 변경하지 않는다. Windows 시간 서비스는 조회 당시 Stopped였으나 이것만으로 호스트나 Hyper-V를 원인으로 확정하지 않는다.

## 2026-10-28: 공유 커널과 시간 진행률을 교차 측정한 결과

새 수정본의 빌드와 8패키지 설치 감사는 통과했다. 그러나 `preflight-mujoco-pairs-a386ee08-36fa-4d7a-9370-f0b8b6015679`는 같은 부팅 `87c3f02d-25d7-4fbb-a9ab-39eacf7e7fdd`에서 150초 안에 +2.926/+2.956/+2.958/+2.936/+2.937초의 SYSTEM−MONOTONIC 변화를 관측해 실패했다. **엔진 시작0회**다. 승인된 Ubuntu-24.04 서비스 비교 `timesync-comparison-e4d9e6b6-a635-446d-87b9-fbe156110c67`의 finally 복원은 active/enabled 일치·restored=true로 확인했다. 이 실패를 보행 실패나 새 G1/G2 결과로 세지 않는다.

추측 대신 세 개의 독립적인 원본 측정을 추가했다. 모두 일반 사용자이며, 시각·서비스 설정을 변경하지 않았다.

| 측정 | 고유 증거 | 결과 |
|---|---|---|
| Linux RAW/REALTIME/MONOTONIC와 `adjtimex(modes=0)` 150초 | `clock-discipline-18ba439f-97f6-47aa-bb12-3019199fe70d` | 6414개 표본, tick=9166µs 일정, freq=32.221710ppm. MONOTONIC/RAW 중앙값0.916994. REALTIME는 +2.902~2.918초 step4회 |
| Windows UTC/QPC 150초 | `host-clock-43de3fba-abf5-4964-8d0e-7e4ba9bd7f67` | UTC/QPC=0.99999885 |
| Windows QPC가 Linux 조회 전후를 감싼 60초 | `clock-cross-boundary-12e96348-4d8d-4475-a9df-1c02f029b8e8` | 실제 호스트 경과59.777~60.093초. RAW59.93584초(비율0.99738~1.00266), MONOTONIC54.97213초(0.91478~0.91962) |

위 오차 구간을 포함해도 이번 부팅의 게스트 MONOTONIC은 호스트보다 약8.3% 느리다. RAW 자체가8.3% 빠르다는 설명과는 맞지 않는다. 시스템의 큰 진행률 보정값 `tick=9166`이 원인에 직접 관련됐다는 강한 근거다. 32.22ppm 주파수 값만으로8.3% 차이는 설명되지 않는다. 누가 tick을 이 값으로 설정했는지는 아직 증명하지 못했다. Hyper-V·NTP·특정 프로세스 중 하나를 단독 원인으로 확정하지 않는다.

별도 `shared-clock-environment-2fe63f82-20bf-4a23-b26f-e7f9840716f2`에서 **Ubuntu-22.04도 실행 중이고 그 안의 timesyncd PID108이 active/enabled**인 것을 발견했다. 24.04의 PID2177과 독립적인 서비스다. 두 배포판의 boot ID와 time namespace가 같으며, Docker 컨테이너는0개다. 22.04 서비스의 이번 부팅 로그에는 시작 이후 중지 기록이 없다. 따라서 ‘24.04 서비스 하나 중지’는 WSL VM 전체 NTP 중지가 아니었다. 이것이 지난 비교의 범위 한계다. Linux의 REALTIME은 time namespace로 가상화되지 않으므로, 별도 배포판이라는 이유로 독립 시계라고 가정하면 안 된다.

분석 산출물은 `clock-discipline-analysis-2fd204f1-1580-4d60-b5d7-7e5633ab0581/result.json`이다. 실제 측정 방법·명령·완료 표식·SHA·시간 조회 호출을 감싼 불확실성 구간을 보존했다. 진단 C 프로그램은 `adjtimex`의 modes=0만 호출하고 root가 아니다.

```mermaid
flowchart TD
    H["Windows UTC / QPC<br/>측정 비율 약1.0"] --> R["Hyper-V 공급원 / Linux RAW<br/>호스트와 일치하는 측정 구간"]
    R --> K["공유 Linux 커널의 시간 보정<br/>tick=9166µs 관측"]
    K --> M["MONOTONIC 진행률 약0.917<br/>60초에 약55초 진행"]
    K --> S["REALTIME의 반복 step<br/>약 +2.9초"]
    N22["Ubuntu-22.04 timesyncd<br/>여전히 active"] -. "단독 기여는 미확정" .-> K
    N24["Ubuntu-24.04 timesyncd<br/>중지·복원 비교 완료"] -. "단독 중지로 미해결" .-> K
    S --> F["원래40초 quiet /150초 deadline 실패<br/>엔진 시작 차단"]
    M --> F
```

### 다음 판별을 위해 추가로 필요한 승인 범위

아래는 **제안이며 아직 실행하지 않았다**. 기존 승인은 Ubuntu-24.04의 서비스 하나만 일시 중지·복원하는 범위다. 다른 배포판 서비스와 커널 시간 보정값 변경은 새 승인이 필요하다.

1. 두 배포판의 서비스 active/enabled, 동일 boot/time namespace, 커널 tick/freq/status를 저장하고 승인한 상태와 다르면 조작하지 않는다. 소유 엔진·명령 프로세스가 없는 상태에서 시작한다.
2. Ubuntu-22.04와24.04의 timesyncd만 검증 세션 동안 일시 중지한다. 배포판 자체 종료, 다른 서비스·Windows 설정·드라이버·clocksource·영구 설정 변경은 하지 않는다.
3. 공유 커널의 `adjtimex(ADJ_TICK)`으로 tick만 명목10000µs로 임시 보정한다. USER_HZ=100을 실제 조회했다. freq·status·현재 날짜/시각을 직접 설정하지 않는다. 기존 tick=9166을 복원용으로 저장한다. 커널 시간 진행률은 **다른 실행 중 WSL 작업에도 영향을 준다**. 따라서 Ch13 내부 변경으로 취급하지 않는다.
4. 먼저 원본 시계의 진행률·불연속을 호스트 QPC와 재측정한다. 기존40초 quiet/150초 deadline와 원래 시동 회귀를 통과한 경우에만 같은 임시 설정을 유지한 채 기존 고정본 순차G1/G2 검증을 진행한다. 첫 실패에서 중단하며, 시계나 인수 기준을 완화하지 않는다. 실제 ROS header·시뮬레이터 물리2ms·native100Hz controller는 그대로다.
5. 정상·실패 경로의 finally에서 저장한 tick과 두 서비스의 원래 active/enabled를 복원하고, 각각 실측 확인한다. 외부 조작·부팅 변경으로 복원 소유권이 불명확하면 자동 덮어쓰기하지 않고 복원 미확정으로 보고한다. 전원 차단처럼 finally가 실행되지 못한 경우를 위해 디스크에 복원 대기 표식을 먼저 남긴다.

근거: [Microsoft의 WSL2 구조 설명](https://learn.microsoft.com/en-us/windows/wsl/compare-versions)은 배포판이 관리 VM 내부의 격리된 컨테이너임을 설명한다. [Linux time namespaces 문서](https://man7.org/linux/man-pages/man7/time_namespaces.7.html)는 REALTIME 비격리를 명시한다. [adjtimex API](https://man7.org/linux/man-pages/man2/adjtimex.2.html)는 modes=0 조회와 CAP_SYS_TIME이 필요한 ADJ_TICK 변경을 구분한다. [Linux v6.18 ntp.c](https://raw.githubusercontent.com/torvalds/linux/v6.18/kernel/time/ntp.c)의 tick은 USER_HZ 주기이며 기본값은 USER_TICK_USEC다. 공식 소스를 개념 근거로만 읽었고 외부 코드를 복사하거나 수정하지 않았다.
