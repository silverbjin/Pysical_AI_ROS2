"""Freeze current audited source and the external blocker without engine claims."""
import hashlib,json,sys,uuid,zipfile
from pathlib import Path

repo=Path.cwd().resolve();base=repo/'Ch13/evidence/section_13_5/85670137-e73c-4c72-bcb2-0c73e755088b'
out=base/('clock-blocker-checkpoint-'+str(uuid.uuid4()));out.mkdir()
sys.path.insert(0,str(repo/'Ch13/scripts'))
from run_navigation_13_5 import audit_runtime
audit_runtime(repo,out)
manifest=json.loads((out/'source_manifest.json').read_text())
inputs=[base/name for name in (
 'preflight-mujoco-pairs-a386ee08-36fa-4d7a-9370-f0b8b6015679',
 'timesync-comparison-e4d9e6b6-a635-446d-87b9-fbe156110c67',
 'clock-discipline-18ba439f-97f6-47aa-bb12-3019199fe70d',
 'host-clock-43de3fba-abf5-4964-8d0e-7e4ba9bd7f67',
 'clock-cross-boundary-12e96348-4d8d-4475-a9df-1c02f029b8e8',
 'clock-discipline-analysis-2fd204f1-1580-4d60-b5d7-7e5633ab0581',
 'shared-clock-environment-2fe63f82-20bf-4a23-b26f-e7f9840716f2')]
inputs.extend(base/name for name in (
 'task8-shift-only-swing-cap-red.log','task8-shift-only-swing-cap-green.log',
 'task8-applied-elapsed-clock-stable-timesync-comparison-e4d9e6b6-a635-446d-87b9-fbe156110c67-build.log',
 'task8-applied-elapsed-clock-stable-timesync-comparison-e4d9e6b6-a635-446d-87b9-fbe156110c67-install-audit.json'))
assert all(p.exists() for p in inputs)
service=json.loads((inputs[1]/'service-lifecycle.json').read_text())
preflight=json.loads((inputs[0]/'preflight/result.json').read_text())
assert service['restored'] and not service['restoration_pending']
assert not preflight['passed'] and preflight['engine_attempts']==0
files={};archive=out/'checkpoint.zip'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    def add(p,name,expected=None):
        value=digest(p);assert expected is None or value==expected
        assert name not in files
        z.write(p,name);files[name]=dict(size=p.stat().st_size,sha256=value)
    add(Path(__file__),'method.py')
    for relative,sha in manifest['files'].items():add(repo/relative,'sources/'+relative,sha)
    tests=repo/'Ch13/ros2_ws/src/integrated_robot_navigation/test'
    for p in sorted(tests.rglob('*')):
        if p.is_file() and p.suffix in ('.py','.json'):add(p,'tests/'+str(p.relative_to(tests)))
    for root in inputs:
        paths=sorted(root.rglob('*')) if root.is_dir() else [root]
        for p in paths:
            if p.is_file():add(p,'evidence/'+str(p.relative_to(base)))
    for name in ('source_manifest.json','install_manifest.json'):add(out/name,name)
    add(repo/'Ch13/docs/SECTION_13_5_CLOCK_BLOCKER_DECISION_KO.md','docs/SECTION_13_5_CLOCK_BLOCKER_DECISION_KO.md')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,identity in files.items():assert hashlib.sha256(z.read(name)).hexdigest()==identity['sha256']
report=dict(scope='audited_source_and_external_clock_blocker_not_engine_acceptance',
    source_files=len(manifest['files']),head=manifest['head'],source_manifest_sha256=digest(out/'source_manifest.json'),
    archive_sha256=digest(archive),archive_bytes=archive.stat().st_size,members=files,
    engine_attempts=0,preflight_passed=False,services_restored=True,required_checks_unchanged=True,
    needs_new_user_authorization='both distro timesyncd and temporary shared kernel tick normalization; not yet executed')
(out/'checkpoint.json').write_text(json.dumps(report,indent=2))
print(json.dumps(dict(output=str(out),**{k:v for k,v in report.items() if k!='members'}),indent=2))
