"""Parent owns bounded XYZ commits and full restoration, not the math child."""
from copy import deepcopy
import numpy as np
import pytest
from test_async_load_owner import ready,next_capture


def ready_xyz(model):
    m,b,q,p,points,f=ready(model);peer=m._load_transfer
    peer.command_space='stance_xyz'
    peer.last_model.update(command_space='stance_xyz',future_geometry_validated=True)
    m._load_transfer_origin_xyz=deepcopy(m._targets)
    m.planning_future_targets=deepcopy(m._targets)
    return m,b,q,p,points,f


def complete_xyz(m,f,delta=None):
    peer=m._load_transfer
    if delta is None:
        delta={name:([0.,0.,1e-5] if name==f else [1e-5,-1e-5,0.]) for name in m.model.feet}
    peer.reply=dict(delta=delta,context=deepcopy(peer.pending),
        received_wall_ns=m._last_wall+20_000_000,submitted_wall_ns=m._last_wall,
        computed_wall_ns=m._last_wall+2_000_000)


def test_xyz_submission_uses_owned_transition_origins_and_future_geometry(nav_robot_model):
    m,b,q,p,points,f=ready_xyz(nav_robot_model)
    m._transfer_stance_load(b,q,p,points,f,.02)
    args=m._load_transfer.requests[0]
    assert 'reference_xyz' in args and 'reference_z' not in args
    assert all(np.array_equal(args['origins'][n],m._targets[n]) for n in m.model.feet)
    assert set(args['future_targets'])==set(m.model.feet)


def test_xyz_result_commits_once_and_restores_the_full_stance_vector(nav_robot_model):
    m,b,q,p,points,f=ready_xyz(nav_robot_model);before=deepcopy(m._targets)
    m._transfer_stance_load(b,q,p,points,f,.02);complete_xyz(m,f);b=next_capture(m,b)
    m._transfer_stance_load(b,q,p,points,f,.02)
    stance=next(n for n in m.model.feet if n!=f)
    assert np.allclose(m._targets[stance]-before[stance],[1e-5,-1e-5,0.],atol=1e-12)
    assert m.load_transfer_observation['applied_delta_xyz'][stance]==[1e-5,-1e-5,0.]
    m._discard_load_transfer();m.phase='SETTLE'
    assert m._restore_stance_load(.02)
    assert all(np.array_equal(m._targets[n],before[n]) for n in m.model.feet if n!=f)
    assert m._load_transfer_rest_xyz=={}


@pytest.mark.parametrize('bad',['vector_rate','selected_xy','total_vector','geometry_proof'])
def test_xyz_parent_rejects_unowned_or_over_limit_numeric_result(nav_robot_model,bad):
    m,b,q,p,points,f=ready_xyz(nav_robot_model)
    if bad=='total_vector':
        stance=next(n for n in m.model.feet if n!=f)
        m._load_transfer_origin_xyz[stance]=m._targets[stance]-np.array([.01,0.,0.])
    m._transfer_stance_load(b,q,p,points,f,.02);complete_xyz(m,f)
    if bad=='vector_rate':m._load_transfer.reply['delta'][f]=[0.,0.,.000041]
    elif bad=='selected_xy':m._load_transfer.reply['delta'][f]=[1e-5,0.,0.]
    elif bad=='geometry_proof':m._load_transfer.last_model['future_geometry_validated']=False
    b=next_capture(m,b);before=deepcopy(m._targets)
    with pytest.raises(ValueError,match='transition optimization'):
        m._transfer_stance_load(b,q,p,points,f,.02)
    assert all(np.array_equal(before[n],m._targets[n]) for n in m.model.feet)


def test_xyz_restore_speed_is_one_vector_cap_not_one_cap_per_axis(nav_robot_model):
    m,b,q,p,points,f=ready_xyz(nav_robot_model);m.phase='SETTLE'
    stance=next(n for n in m.model.feet if n!=f)
    original=m._targets[stance].copy();m._load_transfer_rest_xyz={stance:original+np.array([.003,.003,.003])}
    assert not m._restore_stance_load(.02)
    assert np.linalg.norm(m._targets[stance]-original)==pytest.approx(.002*.02,abs=1e-12)
