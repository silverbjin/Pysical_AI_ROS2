"""Preserve one approved experiment, never rewrite its original verdict/files."""
import hashlib
import json
from pathlib import Path
import sys
import zipfile

repo = Path.cwd().resolve()
base = repo/'Ch13/evidence/section_13_5/85670137-e73c-4c72-bcb2-0c73e755088b'
root = (base/sys.argv[1]).resolve(strict=True)
assert root.parent == base and root.name.startswith('native-g1-gazebo-')
manifest = json.loads((root/'source_manifest.json').read_text())
result = json.loads((root/'result.json').read_text())
assert result['execution_mode']['control_clock'] == 'relay100' and result['execution_mode']['validation_only'] is True
archive = base/('task8-control-clock-'+root.name.removeprefix('native-g1-gazebo-')[:8]+'.zip')
ledger = archive.with_suffix('.json')
assert not archive.exists() and not ledger.exists()
members = {}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as output:
    def add(path,label,expected=None):
        raw = path.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        assert expected is None or digest == expected, path
        assert label not in members and not Path(label).is_absolute() and '..' not in Path(label).parts
        output.writestr(label,raw)
        members[label] = dict(size=len(raw),sha256=digest)
    for relative,digest in manifest['files'].items():
        add(repo/relative,'sources/'+relative,digest)
    for directory in (root,root.with_name(root.name+'-prepared')):
        for path in sorted(directory.rglob('*')):
            if path.is_file(): add(path,'evidence/'+str(path.relative_to(base)))
    for path in sorted(set(base.glob('task8-control-clock-*')) | set(base.glob('task8-sensor-*'))):
        if path.is_file() and path.suffix in ('.log','.xml','.json','.stderr'):
            add(path,'verification/'+path.name)
    for name in ('freeze-control-clock.py','analyze-control-clock.py','analyze-native-timing.py',
                 'native-output-gz.py','native-output-gz.sh','build-control-clock.sh',
                 'check-clock-core.sh','check-clock-ros.sh','capture-native-tree.py'):
        add(Path(__file__).parent/name,'tools/'+name)
    add(Path('/home/jinho/ch13_5_completion_85670137-e73c-4c72-bcb2-0c73e755088b/build/integrated_robot_navigation_sensors/CMakeCache.txt'),
        'build/CMakeCache.txt')
with zipfile.ZipFile(archive) as saved:
    assert saved.testzip() is None
    for label,record in members.items():
        assert hashlib.sha256(saved.read(label)).hexdigest() == record['sha256']
value = dict(scope='approved_opt_in_experiment_not_G1_or_13_5_completion', original_status=result['status'],
    trial=root.name, result_run_id=result['run_id'], source_count=len(manifest['files']),source_head=manifest['head'],
    archive=archive.name,size=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
    source_manifest_sha256=hashlib.sha256((root/'source_manifest.json').read_bytes()).hexdigest(),
    members=members, originals_retained=True)
assert value['size'] < 95_000_000, 'do not stage an oversized artifact'
with ledger.open('x') as stream: json.dump(value,stream,indent=2,allow_nan=False)
print(json.dumps({key:val for key,val in value.items() if key != 'members'},indent=2))
