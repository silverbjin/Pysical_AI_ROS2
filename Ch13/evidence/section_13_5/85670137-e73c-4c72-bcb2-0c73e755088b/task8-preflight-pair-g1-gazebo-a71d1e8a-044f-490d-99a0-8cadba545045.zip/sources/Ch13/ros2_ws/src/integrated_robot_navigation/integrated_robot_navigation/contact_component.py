"""Small physical-observation protocol; cannot produce a G2 admission proof."""
import numpy as np
from .samples import Sample,sample_valid
from .projection import body_rotation
from .leg_kinematics import fk_leg


class ContactTransitionTracker:
    def __init__(self,model,baseline):
        self.model=model;self.events=[];self.last_capture=None;self.samples=0
        centers,contact=self._read(baseline)
        if not all(v>=2. for v in contact.data['forces']):
            raise ValueError('component baseline requires four measured supports')
        self.baseline={f:float(p[2]) for f,p in centers.items()}
        self.maximum={f:0. for f in model.feet}
        self.low_since={f:None for f in model.feet}
        self.lifted=set();self.completed=set()

    def _read(self,frame):
        samples={key:Sample(**frame['samples'][key]) for key in ('joints','body','contacts')}
        for key,sample in samples.items():
            good,reason=sample_valid(sample,frame['ros_ns'],frame['wall_ns'],0,max_age_ns=200_000_000)
            if not good:raise ValueError('component '+key+':'+reason)
        captures=[s.stamp_ns for s in samples.values()]
        if max(captures)-min(captures)>40_000_000:
            raise ValueError('component body/joint/contact capture mismatch')
        contact=samples['contacts'];data=contact.data
        if (tuple(data['names'])!=self.model.feet or data['unexpected_contacts']!=0
                or data.get('force_vectors_valid') is not True):
            raise ValueError('component contact identity/vector attestation')
        vectors=np.asarray(data.get('forces_world'),dtype=float)
        if (vectors.shape!=(4,3) or not np.isfinite(vectors).all()
                or not np.allclose(vectors[:,2],data['forces'],rtol=1e-6,atol=1e-6)):
            raise ValueError('component signed force mismatch')
        q=samples['joints'].data['position'];body=samples['body']
        if body.frame_id!='odom' or body.data['child_frame_id']!='base_footprint':
            raise ValueError('component world body frame')
        pose=np.eye(4);pose[:3,:3]=body_rotation(body.data)[0];pose[:3,3]=body.data['position']
        centers={}
        for foot in self.model.feet:
            angles=tuple(q[foot[:2]+'_'+part+'_joint'] for part in ('hip','thigh','calf'))
            centers[foot]=(pose@np.r_[fk_leg(self.model,foot,angles),1.])[:3]
        return centers,contact

    def update(self,frame):
        centers,contact=self._read(frame);token=contact.stamp_ns
        if self.last_capture is not None:
            if token<self.last_capture:raise ValueError('component capture rollback')
            if token==self.last_capture:return len(self.completed)==4
        self.last_capture=token;self.samples+=1
        for foot,force in zip(self.model.feet,contact.data['forces']):
            lift=float(centers[foot][2]-self.baseline[foot]);self.maximum[foot]=max(self.maximum[foot],lift)
            if force<2.:
                if self.low_since[foot] is None:self.low_since[foot]=(token,contact.received_ns)
                start=self.low_since[foot]
                if (token-start[0]>=100_000_000 and contact.received_ns-start[1]>=100_000_000
                        and lift>=.005 and foot not in self.lifted):
                    self.lifted.add(foot)
                    self.events.append(dict(foot=foot,event='measured_unload_and_lift',
                        capture_ns=token,received_ns=contact.received_ns,lift_m=lift))
            else:
                if foot in self.lifted and foot not in self.completed and lift<=.005:
                    self.completed.add(foot)
                    self.events.append(dict(foot=foot,event='measured_return',capture_ns=token,
                        received_ns=contact.received_ns,lift_m=lift,normal_force_n=float(force)))
                self.low_since[foot]=None
        return len(self.completed)==4

    def report(self):
        return dict(scope='observed_contact_component_not_full_G2_acceptance',
            all_four_contacts_completed=len(self.completed)==4,
            completed_feet=sorted(self.completed),maximum_lift_m=dict(self.maximum),
            baseline_center_z_m=dict(self.baseline),unique_contact_captures=self.samples,events=list(self.events))


def component_outcome(original,tracker,*,protocol_finished,dart_observed):
    """Keep original G2 FAIL and all its checks intact, never mint admission."""
    unexecuted={'forward','left','right','dart_contact_contract'}
    mandatory={'normal_runtime_exit','normal_engine_exit','carry_terminal_received',
        'joint_tf_ownership','contact_support','sensor_freshness','stability','native_ctrl_observed'}
    required=set(original.get('required_checks',()))
    checks=original.get('checks',{})
    failed=sorted(k for k in required-unexecuted if checks.get(k) is not True)
    complete=(original.get('gate')=='G2' and original.get('status')=='FAIL'
        and mandatory|unexecuted<=required and not failed and bool(protocol_finished)
        and dart_observed is True and tracker.get('all_four_contacts_completed') is True)
    return dict(scope='contact_component_only_original_G2_incomplete',observations_complete=bool(complete),
        full_G2_acceptance=False,original_G2_status=original.get('status'),
        predeclared_unexecuted_G2_checks=sorted(unexecuted),unexpected_failed_checks=failed,
        protocol_finished=bool(protocol_finished),dart_component_observed=dart_observed is True,tracker=tracker)
