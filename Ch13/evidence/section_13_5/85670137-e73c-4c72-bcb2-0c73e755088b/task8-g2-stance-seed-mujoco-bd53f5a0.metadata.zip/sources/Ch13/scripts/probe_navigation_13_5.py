#!/usr/bin/env python3
"""Read-only native observations plus explicit services to the existing owners."""
from dataclasses import asdict
from collections import Counter, deque
import gc
import json
from threading import Event, RLock, Thread
import time

from rclpy.executors import SingleThreadedExecutor
from rclpy.node import Node
from rclpy.parameter import Parameter
from rclpy.qos import qos_profile_sensor_data, QoSProfile, DurabilityPolicy
from geometry_msgs.msg import PoseStamped, Twist
from nav_msgs.msg import Odometry
from sensor_msgs.msg import JointState, Imu, LaserScan
from std_srvs.srv import Trigger
from std_msgs.msg import String
from lifecycle_msgs.srv import ChangeState
from tf2_msgs.msg import TFMessage
from integrated_robot_interfaces.msg import MotionState, FootContacts
from integrated_robot_interfaces.srv import SetMode
from integrated_robot_navigation.observations import SensorInbox, sensor_sample
from integrated_robot_navigation.samples import Sample


def transport_receipt(stamp_ns, received_ns, system_ns, info):
    def field(name):
        value = info.get(name) if isinstance(info, dict) else getattr(info, name, None)
        return value if type(value) is int and value > 0 else None
    return dict(stamp_ns=stamp_ns, received_ns=received_ns, callback_system_ns=system_ns,
                source_system_ns=field('source_timestamp'),
                rmw_received_system_ns=field('received_timestamp'))


class ProbeReceiver:
    """One owned callback executor, independent of caller IO/graph/proc scans."""
    def __init__(self, node):
        if node.executor is not None:
            raise ValueError('probe already has an executor owner')
        self.stopping, self.closed, self.error = Event(), False, None
        self.executor = SingleThreadedExecutor(context=node.context)
        self.node = node
        self.thread = Thread(target=self._spin, name='navigation_probe_receiver')
        try:
            self.executor.add_node(node)
            self.thread.start()  # last: a constructor failure cannot orphan it
        except BaseException:
            self.executor.shutdown(timeout_sec=2.)
            raise

    def _spin(self):
        try:
            while not self.stopping.is_set() and self.node.context.ok():
                self.executor.spin_once(timeout_sec=.02)
        except BaseException as error:
            self.error = error  # sticky; the caller must fail, never restart it

    def check(self):
        if self.error is not None:
            raise RuntimeError('probe receiver callback failed: '+repr(self.error)) from self.error
        if not self.thread.is_alive() and not self.stopping.is_set():
            raise RuntimeError('probe receiver exited unexpectedly')

    def shutdown(self, *, timeout_sec):
        if self.closed:
            return True
        deadline = time.monotonic()+timeout_sec
        self.stopping.set()
        self.executor.wake()
        self.thread.join(timeout=max(0., deadline-time.monotonic()))
        if self.thread.is_alive():
            return False  # retain the executor/ROS handles until the callback ends
        self.closed = bool(self.executor.shutdown(timeout_sec=max(0., deadline-time.monotonic())))
        return self.closed


class NavigationProbe(Node):
    def __init__(self, directory, engine='mujoco', *, bounded_history=False, **kwargs):
        super().__init__('navigation_native_probe', parameter_overrides=[Parameter('use_sim_time', value=True)], **kwargs)
        self._lock = RLock()
        self.inbox = SensorInbox(0)
        self.native_com, self.com_pending = None, {}
        self.motion = {}
        self.frames, self.errors, self.transforms = [], [], []
        self.tf_api = {}
        self.transport_errors = []
        self.engine, self.native_controls = engine, []
        self.body_references = []
        self.bounded_history = bounded_history
        self.journal_path = directory/'observations.jsonl'
        self.journal_counts = Counter()
        self.history_restored = False
        self.gc_spans, self.gc_started = deque(maxlen=512), {}
        self.gc_observer = None
        if bounded_history:
            self.frames, self.native_controls = deque(maxlen=128), deque(maxlen=128)
            self.transforms, self.body_references = deque(maxlen=128), deque(maxlen=128)
        self.stage, self.ignore_faults = 'bootstrap', False
        self.missing = Counter()
        self.raw = (directory/'observations.jsonl').open('w', encoding='utf-8')
        qos = qos_profile_sensor_data
        for key, kind, topic in (
            ('joints', JointState, '/joint_states'), ('imu', Imu, '/navigation/imu'),
            ('contacts', FootContacts, '/navigation/foot_contacts'), ('body', Odometry, '/odom'),
            ('scan', LaserScan, '/scan'), ('carry', MotionState, '/navigation/carry_state')):
            self.create_subscription(kind, topic,
                lambda msg, info, stream=key: self._dispatch(self._sensor, stream, msg, info), qos)
        if engine == 'mujoco':
            from mujoco_ros2_control_msgs.msg import FreeJointStateArray
            self.create_subscription(FreeJointStateArray, '/native/free_joint_states',
                lambda msg, info: self._dispatch(self._body_source, msg, info), qos)
        # Both native MuJoCo and the installed Gazebo bridge offer RELIABLE.
        # Keep per-capture gyro references separate from best-effort sensors.
        self.create_subscription(String, '/navigation/native_controls',
            lambda msg: self._dispatch(self._controls, msg),
            QoSProfile(depth=100))
        self.create_subscription(PoseStamped, '/navigation/native_com',
            lambda msg: self._dispatch(self._com, msg), qos)
        for key in ('crawl', 'carry', 'guard', 'startup'):
            self.create_subscription(MotionState, '/navigation/'+key+'_state',
                                     lambda msg, stream=key: self._dispatch(self._motion, stream, msg), 10)
        self.create_subscription(TFMessage, '/tf', lambda msg, info: self._dispatch(self._tf, msg, info), qos)
        self.create_subscription(TFMessage, '/tf_static', lambda msg, info: self._dispatch(self._tf, msg, info),
            QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL))
        self.mode = self.create_client(SetMode, '/navigation/set_mode')
        self.calibrate = self.create_client(Trigger, '/crawl_controller/calibrate_contact')
        self.crawl_report = self.create_client(Trigger, '/crawl_controller/report')
        self.lifecycle = self.create_client(ChangeState, '/crawl_controller/change_state')
        self.carry_report = self.create_client(Trigger, '/carry_manager/report')
        self.carry_stop = self.create_client(Trigger, '/carry_manager/stop')
        self.native_stop = self.create_client(Trigger, '/navigation/stop_native_sensors')
        self.control_clock_report = self.create_client(Trigger, '/navigation_control_clock/report')
        self.control_clock_stop = self.create_client(Trigger, '/navigation_control_clock/stop')
        self.create_timer(.02, lambda: self._dispatch(self._frame))
        if bounded_history:
            # Observe, never disable or tune the process GC policy. Installed
            # last so constructor failure cannot leak a global callback.
            self.gc_observer = self._gc_event
            gc.callbacks.append(self.gc_observer)

    def _gc_event(self, phase, info):
        generation = info['generation']
        if phase == 'start':
            self.gc_started[generation] = time.monotonic_ns()
        elif generation in self.gc_started:
            start = self.gc_started.pop(generation)
            end = time.monotonic_ns()
            if end-start >= 1_000_000:
                self.gc_spans.append(dict(generation=generation,started_wall_ns=start,
                    finished_wall_ns=end,duration_ms=(end-start)/1e6,
                    live_frames=len(self.frames),live_controls=len(self.native_controls)))

    def _stop_gc_observer(self):
        if self.gc_observer is not None:
            gc.callbacks.remove(self.gc_observer)
            self.gc_observer = None

    def restore_history(self, *, receiver_joined):
        """Only after native shutdown and callback join; assess the WHOLE journal."""
        if not receiver_joined:
            raise RuntimeError('probe receiver must be joined before restoring journal')
        if not self.bounded_history or self.history_restored:
            return
        self._stop_gc_observer()
        self.raw.flush()
        streams = {key: [] for key in ('frame','native_controls','body_reference','tf_transform')}
        with self.journal_path.open(encoding='utf-8') as source:
            for line in source:
                row = json.loads(line)  # corrupt/truncated evidence must fail
                if row['kind'] in streams:
                    streams[row['kind']].append(row['value'])
        if any(len(rows) != self.journal_counts[key] for key,rows in streams.items()):
            raise RuntimeError('journal record count differs from live recording')
        report = dict(scope='all_journal_records_after_native_stop_and_receiver_join',
            counts=dict(self.journal_counts),live_cache_limit=128,
            live_lengths=dict(frames=len(self.frames),controls=len(self.native_controls),
                transforms=len(self.transforms),body_references=len(self.body_references)),
            gc_policy_changed=False,gc_spans=list(self.gc_spans))
        self.frames,self.native_controls = streams['frame'],streams['native_controls']
        self.body_references,self.transforms = streams['body_reference'],streams['tf_transform']
        self.history_restored = True
        with (self.journal_path.parent/'recording_report.json').open('x') as output:
            json.dump(report,output,indent=2,allow_nan=False)

    def _dispatch(self, callback, *args):
        with self._lock:
            callback(*args)

    def set_stage(self, stage, *, ignore_faults=None):
        with self._lock:
            self.stage = stage
            if ignore_faults is not None:
                self.ignore_faults = ignore_faults

    def transform_snapshot(self):
        with self._lock:
            return list(self.transforms)

    def _write(self, kind, value):
        if self.history_restored:
            raise RuntimeError('journal finalized; no callback may append')
        self.raw.write(json.dumps(dict(kind=kind, value=value), allow_nan=False)+'\n')
        if self.bounded_history and kind in ('frame','native_controls','body_reference','tf_transform'):
            self.journal_counts[kind] += 1

    def _sensor(self, key, msg, info=None):
        receipt = time.monotonic_ns()
        system_ns = time.time_ns() if key == 'body' else None
        try:
            value = sensor_sample(key, msg, receipt, 0)
            self.inbox.receive(key, value)
            self._write(key, asdict(value))
            if key == 'body':
                self._write('body_transport', transport_receipt(value.stamp_ns, receipt, system_ns, info))
                if self.engine == 'gazebo':
                    if len(self.body_references) >= 20000:
                        raise ValueError('native body reference capacity')
                    reference = dict(capture_ns=value.stamp_ns,epoch=value.epoch,
                        sequence=value.sequence,frame_id=value.data['child_frame_id'],
                        source='gazebo_native_odometry',
                        angular_velocity=list(value.data['angular_velocity']))
                    if self.bounded_history:self._write('body_reference',reference)
                    self.body_references.append(reference)
        except (ValueError, TypeError) as error:
            self.errors.append(key+':'+str(error))

    def _body_source(self, msg, info):
        receipt, system_ns = time.monotonic_ns(), time.time_ns()
        states = [state for state in msg.free_joints if state.name == 'base_link']
        if len(states) != 1 or states[0].pose.header.frame_id != '':
            self.transport_errors.append('native body source shape/frame')
            return
        stamp = states[0].pose.header.stamp
        self._write('body_source', transport_receipt(
            stamp.sec*1_000_000_000+stamp.nanosec, receipt, system_ns, info))

    def _controls(self, msg):
        receipt = time.monotonic_ns()
        try:
            value = json.loads(msg.data)
            schema = (isinstance(value, dict) and (
                self.engine == 'mujoco' and value.get('schema') == 1
                and isinstance(value.get('actuators'), list) or
                self.engine == 'gazebo' and value.get('schema') == 2
                and value.get('engine') == 'gazebo' and isinstance(value.get('joints'), list)))
            if (not schema
                    or any(type(value.get(key)) is not int or value[key] < 0
                           for key in ('capture_ns', 'epoch', 'sequence'))):
                raise ValueError('native controls diagnostic schema')
            if len(self.native_controls) >= 20000:
                raise ValueError('native controls diagnostic capacity')
            value.update(received_ns=receipt, stage=self.stage)
            self._write('native_controls', value)
            self.native_controls.append(value)
        except (ValueError, TypeError) as error:
            self.transport_errors.append('native_controls:'+str(error))

    def _com(self, msg):
        stamp = msg.header.stamp.sec*1_000_000_000+msg.header.stamp.nanosec
        p = msg.pose.position
        if self.native_com is None or stamp > self.native_com.stamp_ns:
            self.com_pending.setdefault(stamp, Sample(stamp, time.monotonic_ns(), 0, stamp,
                                                     msg.header.frame_id, (p.x, p.y, p.z)))
        while len(self.com_pending) > 10:
            del self.com_pending[min(self.com_pending)]

    def _motion(self, key, msg):
        value = dict(state=msg.state, phase=msg.phase, swing_foot=msg.swing_foot,
                     generation=msg.generation, model_sha256=msg.model_sha256,
                     ready=msg.ready, stopped=msg.stopped, fault_reason=msg.fault_reason,
                     stamp_ns=msg.header.stamp.sec*1_000_000_000+msg.header.stamp.nanosec,
                     received_ns=time.monotonic_ns())
        self.motion[key] = value
        self._write(key+'_state', value)

    def _tf(self, msg, info):
        try:
            raw_gid = info.get('publisher_gid') if isinstance(info, dict) else getattr(info, 'publisher_gid', None)
            if (raw_gid is None and isinstance(info, dict)
                    and type(info.get('source_timestamp')) is int
                    and type(info.get('received_timestamp')) is int):
                self.tf_api = dict(publisher_gid_available=False,
                                  authority_source='required_native_cpp_observer')
                return  # this API capability is not a native runtime fault
            gid_bytes = bytes(raw_gid) if raw_gid is not None else b''
            if not gid_bytes:
                raise ValueError('missing publisher_gid')
            gid = gid_bytes.hex()
        except (ValueError, TypeError) as error:
            self.errors.append('tf_metadata:'+str(error))
            return  # retain a usable executor for explicit owner/engine cleanup
        for transform in msg.transforms:
            reference = dict(parent=transform.header.frame_id,
                child=transform.child_frame_id, gid=gid,
                stamp_ns=transform.header.stamp.sec*1_000_000_000+transform.header.stamp.nanosec)
            if self.bounded_history:self._write('tf_transform',reference)
            self.transforms.append(reference)

    def _frame(self):
        ros_ns, wall_ns = self.get_clock().now().nanoseconds, time.monotonic_ns()
        samples = asdict(self.inbox.bundle(ros_ns))
        eligible = [stamp for stamp in self.com_pending if stamp <= ros_ns]
        if eligible:
            latest = max(eligible)
            self.native_com = self.com_pending[latest]
            for stamp in list(self.com_pending):
                if stamp <= latest:
                    del self.com_pending[stamp]
        samples['native_com'] = asdict(self.native_com) if self.native_com else None
        absent = [key for key, value in samples.items() if value is None]
        if absent:
            self.missing.update(absent)
            return
        row = dict(ros_ns=ros_ns, wall_ns=wall_ns, stage=self.stage, samples=samples,
                   crawl=dict(self.motion.get('crawl', {})))
        self.frames.append(row)
        self._write('frame', row)

    def fault(self):
        with self._lock:
            faults = [key+':'+value['fault_reason'] for key, value in self.motion.items() if value['fault_reason']]
            return (self.errors+faults)[0] if self.errors or faults else ''

    def latest_frame(self):
        # _frame appends a fresh asdict snapshot and never mutates that row.
        with self._lock:return self.frames[-1] if self.frames else None

    def owner_graph(self,*,include_command_sources=False):
        topics = ('/clock', '/joint_states', '/odom', '/navigation/odom', '/scan', '/navigation/imu',
                  '/navigation/foot_contacts', '/navigation/native_com', '/navigation/carry_state',
                  '/leg_position_controller/commands', '/gripper_position_controller/commands',
                  '/navigation/cmd_vel')
        topics += ('/navigation/native_controls',)
        if include_command_sources:
            topics+=('/navigation/cmd_vel_raw','/navigation/cmd_vel_smoothed')
        return {topic: [dict(node=value.node_namespace+'/'+value.node_name,
                            gid=bytes(value.endpoint_gid).hex())
                        for value in self.get_publishers_info_by_topic(topic)] for topic in topics}

    def close_log(self):
        self._stop_gc_observer()
        if not self.raw.closed:
            self.raw.flush()
            self.raw.close()
