"""Exact completed source/evidence checkpoint, without promoting its verdict."""
import hashlib
import json
from pathlib import Path
import sys
import zipfile

repo=Path.cwd().resolve()
base=repo/'Ch13/evidence/section_13_5/85670137-e73c-4c72-bcb2-0c73e755088b'
root=(base/sys.argv[1]).resolve(strict=True)
assert root.parent==base and root.name.startswith(('native-g1-mujoco-','native-g1-gazebo-','native-g2-mujoco-','native-g2-gazebo-'))
label=sys.argv[2]
assert label.replace('-','').isalnum()
target=base/(label+'.zip')
ledger=target.with_suffix('.json')
assert not target.exists() and not ledger.exists()
manifest=json.loads((root/'source_manifest.json').read_text())
result=json.loads((root/'result.json').read_text())
teardown=json.loads((root/'teardown.json').read_text())
assert teardown['parent_reaped'] and not teardown['residual_live_pids']
members={}
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    def add(path,name,expected=None):
        raw=path.read_bytes();sha=hashlib.sha256(raw).hexdigest()
        assert expected is None or sha==expected,path
        assert name not in members
        archive.writestr(name,raw);members[name]=dict(size=len(raw),sha256=sha)
    for name,sha in manifest['files'].items():add(repo/name,'sources/'+name,sha)
    for directory in (root,root.with_name(root.name+'-prepared')):
        for path in sorted(directory.rglob('*')):
            if path.is_file():add(path,'evidence/'+str(path.relative_to(base)))
    tests=repo/'Ch13/ros2_ws/src/integrated_robot_navigation/test'
    for path in sorted(tests.rglob('*')):
        if path.is_file() and path.suffix in ('.py','.json'):
            add(path,'tests/'+str(path.relative_to(tests)))
    sensor_tests=repo/'Ch13/ros2_ws/src/integrated_robot_navigation_sensors/test'
    for path in sorted(sensor_tests.rglob('*')):
        if path.is_file() and path.suffix in ('.cpp','.hpp'):
            add(path,'sensor-tests/'+str(path.relative_to(sensor_tests)))
    for name in ('task8-calibration-preload-return-related.log',
                 'task8-calibration-native-reference-qos-green.log',
                 'task8-calibration-preload-return-native-build.log',
                 'task8-calibration-preload-return-qos-audit.json',
                 'task8-mujoco-relay-scope-red.log',
                 'task8-mujoco-relay-scope-green.log',
                 'task8-mujoco-relay-wire-current-build.log',
                 'task8-mujoco-relay-wire-current.log',
                 'task8-mujoco-relay-wire-current.xml',
                 'task8-navigation-full-mujoco-relay-20261026.log',
                 'task8-mujoco-relay-scope-native-build.log',
                 'task8-mujoco-relay-scope-native-install-audit.json',
                 'task8-guard-latest-state-red.log',
                 'task8-guard-latest-state-green.log',
                 'task8-guard-latest-both-modes-green.log',
                 'task8-guard-latest-native-build.log',
                 'task8-guard-latest-native-install-audit.json',
                 'task8-native-boundary-red-build.log',
                 'task8-native-boundary-red.log',
                 'task8-native-boundary-red.xml',
                 'task8-command-publication-red.log',
                 'task8-command-publication-green.log',
                 'task8-boundary-runner-related.log',
                 'task8-native-boundary-green-build.log',
                 'task8-native-boundary-green-install-audit.json',
                 'task8-native-boundary-green-ros.log',
                 'task8-native-boundary-green-ros.xml',
                 'task8-native-boundary-sensors-related.log',
                 'task8-final-command-dispatch-red.log',
                 'task8-fault-stop-red.log',
                 'task8-fault-stop-green.log',
                 'task8-final-command-dispatch-green.log',
                 'task8-final-command-isolated-green.log',
                 'task8-final-command-final-related.log',
                 'task8-final-command-final-related-corrected.log',
                 'task8-final-command-native-build.log',
                 'task8-final-command-native-install-audit.json',
                 'task8-loaded-return-red.log',
                 'task8-loaded-return-green.log',
                 'task8-loaded-return-related-green.log',
                 'task8-loaded-settle-budget-red.log',
                 'task8-loaded-return-full-related.log',
                 'task8-loaded-return-native-build.log',
                 'task8-loaded-return-native-install-audit.json',
                 'task8-raw-tf-red.log',
                 'task8-raw-tf-related-green.log',
                 'task8-raw-tf-related-corrected-green.log',
                 'task8-raw-tf-native-build.log',
                 'task8-raw-tf-native-install-audit.json',
                 'task8-probe-ingress-red.log',
                 'task8-probe-ingress-related-green.log',
                 'task8-probe-ingress-all-related.log',
                 'task8-probe-ingress-native-build.log',
                 'task8-probe-ingress-native-install-audit.json',
                 'task8-probe-receipt-lock-red.log',
                 'task8-probe-projection-lock-red.log',
                 'task8-probe-projection-lock-corrected-red.log',
                 'task8-probe-receipt-lock-green.log',
                 'task8-probe-receipt-lock-all-related.log',
                 'task8-probe-receipt-lock-all-corrected.log',
                 'task8-native-trace-copy-red.log',
                 'task8-native-trace-copy-related-green.log',
                 'task8-probe-lock-trace-native-build.log',
                 'task8-probe-lock-trace-native-install-audit.json',
                 'task8-immutable-record-red-resume.log',
                 'task8-immutable-record-green.log',
                 'task8-immutable-record-probe-regression.log',
                 'task8-immutable-ingress-isolated.log',
                 'task8-immutable-native-scalar-red.log',
                 'task8-immutable-record-probe-corrected.log',
                 'task8-observer-thread-restored-audit.json',
                 'task8-probe-continuous-red.log',
                 'task8-probe-continuous-related.log',
                 'task8-probe-continuous-install-audit.json',
                 'task8-split-observer-red.log',
                 'task8-split-observer-green.log',
                 'task8-split-observer-eof-red.log',
                 'task8-split-observer-sticky-green.log',
                 'task8-split-observer-related.log',
                 'task8-split-observer-runner-red.log',
                 'task8-split-observer-runner-green.log',
                 'task8-split-observer-all-related.log',
                 'task8-split-observer-install-audit.json',
                 'task8-split-runtime-fault-red.log',
                 'task8-split-runtime-fault-green.log',
                 'task8-split-runtime-fault-readiness.log',
                 'task8-g1-reference-clock-red.log',
                 'task8-g1-reference-clock-related.log',
                 'task8-g1-reference-clock-corrected.log',
                 'task8-g1-reference-clock-final-related.log',
                 'task8-g1-reference-clock-native-build.log',
                 'task8-g1-reference-clock-native-install-audit.json',
                 'task8-crawl-shift-clock-red.log',
                 'task8-crawl-shift-clock-green.log',
                 'task8-crawl-shift-clock-related.log',
                 'task8-crawl-shift-clock-native-build.log',
                 'task8-crawl-shift-clock-native-install-audit.json',
                 'task8-applied-reference-credit-red.log',
                 'task8-applied-reference-credit-green.log',
                 'task8-gait-reference-credit-red.log',
                 'task8-gait-reference-credit-green.log',
                 'task8-applied-reference-plugin-red-build.log',
                 'task8-applied-reference-plugin-red.log',
                 'task8-applied-reference-plugin-red.xml',
                 'task8-applied-reference-plugin-green-build.log',
                 'task8-applied-reference-plugin-green.log',
                 'task8-applied-reference-plugin-green.xml',
                 'task8-applied-reference-worker-green.log',
                 'task8-applied-reference-worker-green.xml',
                 'task8-applied-reference-ros-red.log',
                 'task8-applied-reference-ros-green.log',
                 'task8-applied-reference-owner-related.log',
                 'task8-applied-reference-foreign-guard-isolated.log',
                 'task8-applied-reference-event-qos-red.log',
                 'task8-applied-reference-owner-fixed-related.log',
                 'task8-applied-reference-sensors-related.log',
                 'task8-applied-reference-native-build.log',
                 'task8-credit-three-stance-red.log',
                 'task8-credit-three-stance-green.log',
                 'task8-applied-reference-corrected-native-build.log',
                 'task8-applied-reference-corrected-native-install-audit.json',
                 'task8-applied-reference-sensors-corrected.log',
                 'task8-unload-credit-rate-red.log',
                 'task8-unload-credit-rate-green.log',
                 'task8-touchdown-credit-rate-red.log',
                 'task8-contact-search-credit-green.log',
                 'task8-contact-fault-landing-red.log',
                 'task8-contact-fault-landing-green.log',
                 'task8-contact-fault-landing-captured.log',
                 'task8-contact-fault-landing-captured-start.json',
                 'task8-contact-fault-landing-captured-end.json',
                 'task8-domain235-diagnostic.log',
                 'task8-domain235-diagnostic-start.json',
                 'task8-domain235-diagnostic-end.json',
                 'task8-contact-fault-landing-valid-domain.log',
                 'task8-contact-fault-landing-valid-domain-start.json',
                 'task8-contact-fault-landing-valid-domain-end.json',
                 'task8-worker-stop-reply-red.log',
                 'task8-worker-stop-reply-green.log',
                 'task8-contact-rate-fault-stop-native-build.log',
                 'task8-contact-rate-fault-stop-native-install-audit.json',
                 'task8-crawl-ingress-independent-red.log',
                 'task8-crawl-ingress-independent-green.log',
                 'task8-crawl-ingress-remap-red.log',
                 'task8-crawl-ingress-remap-safety-green.log',
                 'task8-crawl-ingress-owner-credit-green.log',
                 'task8-crawl-ingress-native-build.log',
                 'task8-crawl-ingress-native-install-audit.json',
                 'task8-crawl-timesource-ingress-red.log',
                 'task8-crawl-timesource-ingress-green.log',
                 'task8-crawl-timesource-lifecycle-stable-window.log',
                 'task8-crawl-timesource-owner-credit-green.log',
                 'task8-crawl-timesource-native-build.log',
                 'task8-crawl-timesource-native-install-audit.json',
                 'task8-timesource-role-attestation-red.log',
                 'task8-timesource-role-attestation-green.log',
                 'task8-timesource-role-attestation-fixed.log',
                 'task8-timesource-role-native-build.log',
                 'task8-timesource-role-native-install-audit.json',
                 'task8-applied-capture-format-red-build.log',
                 'task8-applied-capture-format-red.log',
                 'task8-applied-capture-format-native-build.log',
                 'task8-applied-capture-format-native-install-audit.json',
                 'task8-applied-capture-format-green-build.log',
                 'task8-applied-capture-format-green.log',
                 'task8-applied-capture-format-sensors.log',
                 'task8-applied-capture-format-credit-guard.log',
                 'task8-shutdown-inactive-lifecycle-red.log',
                 'task8-shutdown-inactive-lifecycle-green.log',
                 'task8-clock-stability-preflight-red.log',
                 'task8-clock-stability-preflight-green.log',
                 'task8-clock-preflight-lifecycle-native-build.log',
                 'task8-clock-preflight-lifecycle-native-install-audit.json',
                 'task8-fault-hold-stop-red.log',
                 'task8-fault-hold-stop-green.log',
                 'task8-fault-hold-stop-diagnostic.log',
                 'task8-fault-hold-stop-stationary-red.log',
                 'task8-fault-hold-stop-stationary-green.log',
                 'task8-fault-hold-status-red.log',
                 'task8-fault-hold-status-related-green.log',
                 'task8-fault-hold-native-build.log',
                 'task8-fault-hold-native-install-audit.json',
                 'task8-g2-sim-cadence-red.log',
                 'task8-g2-sim-cadence-green.log',
                 'task8-reference-advance-clock-red.log',
                 'task8-reference-advance-clock-green.log'):
        add(base/name,'verification/'+name)
    for path in sorted(base.glob('task8-g2-sim-cadence-clock-stable-*.*')):
        if path.is_file():add(path,'verification/'+path.name)
    add(Path(__file__),'tools/'+Path(__file__).name)
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    for name,entry in members.items():assert hashlib.sha256(archive.read(name)).hexdigest()==entry['sha256']
value=dict(scope='completed_native_trial_checkpoint_not_section_completion',gate=result.get('gate'),
    trial=root.name,status=result['status'],required_checks=result['required_checks'],
    checks=result['checks'],source_count=len(manifest['files']),source_head=manifest['head'],
    source_manifest_sha256=hashlib.sha256((root/'source_manifest.json').read_bytes()).hexdigest(),
    archive=target.name,size=target.stat().st_size,
    sha256=hashlib.sha256(target.read_bytes()).hexdigest(),originals_retained=True,members=members)
if value['size']>=95_000_000:
    # Original archive retained locally. Publish bounded parts, never omit
    # failed-run records or put a >100MB blob in the future Git commit.
    value['archive_local_only']=True
    value['parts']=[]
    combined=hashlib.sha256()
    with target.open('rb') as original:
        index=1
        while block:=original.read(72_000_000):
            part=target.with_name(target.name+f'.part{index:03d}')
            with part.open('xb') as output:output.write(block)
            digest=hashlib.sha256(part.read_bytes()).hexdigest()
            assert digest==hashlib.sha256(block).hexdigest()
            combined.update(block)
            value['parts'].append(dict(path=part.name,size=len(block),sha256=digest))
            index+=1
    assert combined.hexdigest()==value['sha256']
with ledger.open('x') as output:json.dump(value,output,indent=2,allow_nan=False)
print(json.dumps({k:v for k,v in value.items() if k not in ('members','checks','required_checks')},indent=2))
