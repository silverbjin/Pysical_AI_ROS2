"""Waiting for application freezes references, never the original safety checks."""
from copy import deepcopy
from dataclasses import replace
import numpy as np
from test_crawl_shift_clock_progress import shifting
from test_calibration_clock_progress import sample_at
from gait_fixture import IdealFeedback
from test_gait import machine


def test_no_credit_holds_shift_reference_but_consumes_original_decision_clocks(nav_robot_model):
    value,plant=shifting(nav_robot_model,(.01,0.,0.))
    held=value.reference_body.copy();targets=deepcopy(value._targets)
    ros,wall=value._last_ros+20_000_000,value._last_wall+20_000_000
    result=value.advance(sample_at(plant.state,ros,wall),(.01,0.,0.),ros,wall,
        reference_permitted=False)
    assert result.state=='CRAWL'
    assert np.array_equal(value.reference_body,held)
    assert all(np.array_equal(value._targets[key],point) for key,point in targets.items())
    assert value._last_ros==ros and value._last_wall==wall


def test_no_credit_cannot_bypass_measured_support_failure(nav_robot_model):
    value,plant=shifting(nav_robot_model,(.01,0.,0.))
    ros,wall=value._last_ros+20_000_000,value._last_wall+20_000_000
    bundle=sample_at(plant.state,ros,wall)
    data={**bundle.contacts.data,'forces':(0.,0.,30.,30.),'touching':(False,False,True,True)}
    bundle=replace(bundle,contacts=replace(bundle.contacts,data=data))
    result=value.advance(bundle,(.01,0.,0.),ros,wall,reference_permitted=False)
    assert result.state=='FAULT' and result.joint_targets is None


def test_explicit_stop_does_not_wait_for_reference_credit(nav_robot_model):
    value,plant=shifting(nav_robot_model,(.01,0.,0.));value.request_stop(urgent=True)
    ros,wall=value._last_ros+20_000_000,value._last_wall+20_000_000
    result=value.advance(sample_at(plant.state,ros,wall),(0.,0.,0.),ros,wall,reference_permitted=False)
    assert result.state!='CRAWL' and value.stopping


def swinging(model):
    plant=IdealFeedback(model);value=machine(model,plant)
    for _ in range(1200):
        result=value.advance(plant.state,(.01,0.,0.),plant.ros,plant.wall)
        assert result.state!='FAULT',result.reason
        plant.tick(value,result)
        if value.phase=='SWING' and .3<(plant.ros-value._phase_start)/1e9/value._swing_duration<.6:
            return value,plant
    raise AssertionError('moving SWING not reached')


def test_delayed_swing_cannot_catch_up_missed_reference_steps(nav_robot_model):
    normal,plant=swinging(nav_robot_model);delayed=deepcopy(normal)
    ros,wall=normal._last_ros,normal._last_wall
    a=normal.advance(sample_at(plant.state,ros+20_000_000,wall+20_000_000),(.01,0.,0.),
        ros+20_000_000,wall+20_000_000,reference_permitted=True)
    b=delayed.advance(sample_at(plant.state,ros+40_000_000,wall+27_906_419),(.01,0.,0.),
        ros+40_000_000,wall+27_906_419,reference_permitted=True)
    assert a.state!='FAULT' and b.state!='FAULT'
    assert all(np.allclose(delayed._targets[key],point,atol=1e-12)
        for key,point in normal._targets.items())


def test_waiting_credit_keeps_three_stance_margin_even_after_early_foot_contact(nav_robot_model):
    value,plant=swinging(nav_robot_model)
    ros,wall=value._last_ros+20_000_000,value._last_wall+20_000_000
    bundle=sample_at(plant.state,ros,wall)
    _,_,_,_,_,com=value._measure(bundle,ros,wall)
    points=tuple((com[0]+x,com[1]+y,0.) for x,y in ((-.2,-.1),(.2,-.1),(.2,.1),(-.2,.1)))
    data={**bundle.contacts.data,'points':points,'forces':(30.,)*4,'touching':(True,)*4}
    bundle=replace(bundle,contacts=replace(bundle.contacts,data=data))
    _,_,_,loads,actual_points,actual_com=value._measure(bundle,ros,wall)
    assert value._margin(actual_com,loads,actual_points)>.09
    assert value._margin(actual_com,loads,actual_points,value.swing_foot)<.01
    result=value.advance(bundle,(.01,0.,0.),ros,wall,reference_permitted=False)
    assert result.state=='FAULT' and result.reason=='swing support lost', \
        'application wait bypassed the original three-stance SWING support check'
