"""Owned thread tick deltas by actual probe phase; names are NOT stack proof."""
import hashlib
import json
from pathlib import Path
import sys
root=Path(sys.argv[1]);source=root/'native-thread-cpu.jsonl'
entries=[json.loads(line) for line in source.read_text().splitlines()]
closed=[r for r in entries if r.get('event')=='closed'];rows=[r for r in entries if 'tasks' in r]
assert len(closed)==1 and len(rows)>3
identity={(r['pid'],r['pgid'],r['process_start_ticks']) for r in rows};assert len(identity)==1
frames=json.loads((root/'all_frames.json').read_text())['frames'];phases={}
for phase in ('bootstrap','stand','calibrate'):
    captures=[f for f in frames if f['stage']==phase]
    if not captures:continue
    start,end=captures[0]['wall_ns'],captures[-1]['wall_ns'];threads={};coverage=0.
    for first,last in zip(rows,rows[1:]):
        if not start<=first['wall_ns']<last['wall_ns']<=end:continue
        elapsed=(last['wall_ns']-first['wall_ns'])/1e9;coverage+=elapsed
        previous={(r['tid'],r['start_ticks']):r for r in first['tasks']}
        for task in last['tasks']:
            key=(task['tid'],task['start_ticks'])
            if key not in previous:continue
            before=previous[key];ticks=task['user_ticks']+task['system_ticks']-before['user_ticks']-before['system_ticks']
            assert ticks>=0
            value=threads.setdefault(key,dict(tid=task['tid'],start_ticks=task['start_ticks'],
                name=task['name'],cpu_s=0.,observed_wall_s=0.,processors=set()))
            value['cpu_s']+=ticks/last['clock_ticks_per_s'];value['observed_wall_s']+=elapsed
            value['processors'].add(task['processor'])
    for value in threads.values():
        value['processors']=sorted(value['processors'])
        value['one_core_cpu_percent']=100*value['cpu_s']/value['observed_wall_s']
    phases[phase]=dict(covered_wall_s=coverage,threads=sorted(threads.values(),key=lambda r:-r['cpu_s']))
topology=[]
for cpu in sorted(Path('/sys/devices/system/cpu').glob('cpu[0-9]*')):
    directory=cpu/'topology'
    topology.append(dict(cpu=int(cpu.name[3:]),**{k:(directory/k).read_text().strip()
        for k in ('physical_package_id','core_id','thread_siblings_list')}))
value=dict(scope='owned_thread_CPU_deltas_names_NOT_function_stack_or_affinity_recommendation',
    input_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),identity=list(identity)[0],
    closed=closed[0],affinity=rows[0]['affinity'],analysis_host_current_topology=topology,phases=phases)
with (root/'native-thread-cpu-analysis.json').open('x') as output:json.dump(value,output,indent=2)
print(json.dumps({**value,'phases':{k:{**v,'threads':v['threads'][:8]} for k,v in phases.items()}},indent=2))
