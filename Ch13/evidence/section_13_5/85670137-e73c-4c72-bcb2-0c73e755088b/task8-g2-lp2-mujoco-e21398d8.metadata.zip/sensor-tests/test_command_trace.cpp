// SPDX-License-Identifier: Apache-2.0
#include <gtest/gtest.h>
#include "integrated_robot_navigation_sensors/command_trace.hpp"
namespace nav = integrated_robot_navigation_sensors;

TEST(CommandTrace, BoundedOverwriteAndExportOmissionAreExplicit)
{
  nav::CommandTraceLane lane(3);
  std::atomic<bool> accepting{true};
  for (int i=1; i<=5; ++i) {
    nav::CommandTraceRow row;
    row.snapshot_ros_ns=i*2000000; row.steady_ns=i*3000000; row.ctrl[0]=i;
    lane.record(row, accepting);
  }
  accepting=false;
  auto result=lane.export_frozen(1, 2);
  EXPECT_EQ(result.at("total"), 5);
  EXPECT_EQ(result.at("capacity"), 3);
  EXPECT_EQ(result.at("overwritten"), 2);
  EXPECT_EQ(result.at("omitted_from_export"), 1);
  EXPECT_EQ(result.at("dropped_busy"), 0);
  EXPECT_EQ(result.at("rows")[0].at("sequence"), 4);
  EXPECT_DOUBLE_EQ(result.at("rows")[1].at("ctrl")[0].get<double>(), 5.);
}

TEST(CommandTrace, StopIsPermanentAndInputStorageIsNeverAliased)
{
  nav::NativeCommandTrace trace;
  nav::CommandTraceRow row;
  row.ctrl[0]=.123;
  trace.cm_write.record(row, trace.accepting);
  row.ctrl[0]=.456;
  trace.stop();
  trace.cm_write.record(row, trace.accepting);
  trace.pre_step.record(row, trace.accepting);
  auto cm=trace.cm_write.export_frozen(1, 20);
  EXPECT_EQ(cm.at("total"), 1);
  EXPECT_DOUBLE_EQ(cm.at("rows")[0].at("ctrl")[0].get<double>(), .123);
  EXPECT_EQ(trace.pre_step.export_frozen(1, 20).at("total"), 0);
  EXPECT_EQ(trace.cm_write.export_frozen(1, 20), cm);
}
