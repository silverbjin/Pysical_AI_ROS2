"""CPU-only hand-fixture characterization, never engine/safety acceptance."""
import cProfile
import hashlib
import io
import json
import os
from pathlib import Path
import pstats
import subprocess
import sys
import time

repo = Path.cwd()
base = repo/'Ch13/evidence/section_13_5/85670137-e73c-4c72-bcb2-0c73e755088b'
if '--worker' not in sys.argv:
    result = dict(scope='hand_fixture_cpu_characterization_not_native_acceptance', cases={})
    for label, changes in [('inherited',{}),('blas1',dict(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1'))]:
        env = dict(os.environ,**changes)
        run = subprocess.run([sys.executable,__file__,'--worker'],env=env,capture_output=True,text=True,check=True)
        result['cases'][label] = json.loads(run.stdout)
    target = base/'task8-sensor-cpu-characterization.json'
    with target.open('x') as output: json.dump(result,output,indent=2,allow_nan=False)
    print(json.dumps(result,indent=2))
    raise SystemExit

sys.path.insert(0,str(repo/'Ch13/ros2_ws/src/integrated_robot_navigation/test'))
from guard_fixture import bundle
from integrated_robot_navigation.model import compile_model
from integrated_robot_navigation.gait import CrawlMachine
from integrated_robot_navigation.carry_profile import default_limits
import xacro
model = compile_model(xacro.process_file(str(repo/'Ch13/ros2_ws/src/integrated_robot_description/urdf/robot_system.urdf.xacro'),
    mappings={'hip_mount_y':'0.13'}).toxml())
machine = CrawlMachine(model,default_limits())
state = bundle(model)
machine.reset(state,1_000_000_000,10_000_000_000)
assert machine.state == 'STAND'
def tick(index):
    ros,wall = 1_000_000_000+index*20_000_000,10_000_000_000+index*20_000_000
    result = machine.advance(bundle(model,ros,wall),(0.,0.,0.),ros,wall)
    assert result.state == 'STAND' and len(result.joint_targets) == 12,result.reason
for index in range(1,21): tick(index)
started,cpu = time.perf_counter_ns(),time.process_time_ns()
for index in range(21,221): tick(index)
wall_ns,cpu_ns = time.perf_counter_ns()-started,time.process_time_ns()-cpu
profile = cProfile.Profile()
profile.enable()
for index in range(221,271): tick(index)
profile.disable()
buffer = io.StringIO()
pstats.Stats(profile,stream=buffer).strip_dirs().sort_stats('cumulative').print_stats(25)
threads = len(list(Path('/proc/self/task').iterdir()))
runtime_sources = {str(Path(module.__file__).resolve()):hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest()
    for name,module in sys.modules.copy().items() if name.startswith('integrated_robot_navigation.') and getattr(module,'__file__',None)}
print(json.dumps(dict(wall_ns=wall_ns,cpu_ns=cpu_ns,wall_ms_per_tick=wall_ns/200/1e6,
    cpu_ms_per_tick=cpu_ns/200/1e6,threads=threads,env={name:os.environ.get(name) for name in
        ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS')}, profile=buffer.getvalue(),sources=runtime_sources)))
