"""Exact current runtime + completed MuJoCo regression + fresh test evidence."""
import hashlib
import json
from pathlib import Path
import zipfile

repo = Path.cwd().resolve()
base = repo/'Ch13/evidence/section_13_5/85670137-e73c-4c72-bcb2-0c73e755088b'
run = base/'native-g1-mujoco-c1ae8cd3-a240-4145-88bc-0cfd719a4033'
manifest = json.loads((run/'source_manifest.json').read_text())
result = json.loads((run/'result.json').read_text())
assert result['status']=='PASS' and len(result['required_checks'])==23 and all(result['checks'].values())
prior = json.loads((base/'native-g1-gazebo-5f2a8463-2ae6-4bdd-acef-50e28e853a48/source_manifest.json').read_text())
assert manifest['files']==prior['files'], 'engines must share the frozen runtime source'
target = base/'task8-control-clock-mailbox-mujoco-regression.zip'
ledger = target.with_suffix('.json')
assert not target.exists() and not ledger.exists()
members = {}
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as output:
    def add(path,label,expected=None):
        data = path.read_bytes()
        sha = hashlib.sha256(data).hexdigest()
        assert expected is None or sha==expected,path
        assert label not in members
        output.writestr(label,data)
        members[label]=dict(size=len(data),sha256=sha)
    for relative,sha in manifest['files'].items(): add(repo/relative,'sources/'+relative,sha)
    for directory in (run,run.with_name(run.name+'-prepared')):
        for path in sorted(directory.rglob('*')):
            if path.is_file(): add(path,'evidence/'+str(path.relative_to(base)))
    for path in sorted(base.iterdir()):
        if path.is_file() and (path.name.startswith(('task8-control-clock-mailbox-','task8-sensor-'))
                or path.name in ('task8-mujoco-prepare-c1ae8cd3-a240-4145-88bc-0cfd719a4033.log',
                                 'task8-mujoco-runner-c1ae8cd3-a240-4145-88bc-0cfd719a4033.log')):
            if path.suffix in ('.log','.json','.stderr','.xml'): add(path,'verification/'+path.name)
    for path in sorted((repo/'.superpowers/sdd/SECTION_13_5_IMPLEMENTATION_PLAN_KO').glob('*')):
        if path.name in ('profile-crawl-budget.py','profile-crawl-dispatch.py','profile-crawl-dispatch.sh',
            'analyze-calibration-budget.py','analyze-calibration-budget.sh','freeze-mailbox-regression.py',
            'verify-sensors-current.sh','check-native.sh','task8-native-mj.sh'):
            add(path,'tools/'+path.name)
    add(base/'native-g1-gazebo-5f2a8463-2ae6-4bdd-acef-50e28e853a48/calibration-budget-postmortem.json',
        'postmortem/gazebo-calibration-budget.json')
with zipfile.ZipFile(target) as saved:
    assert saved.testzip() is None
    for label,value in members.items():
        assert hashlib.sha256(saved.read(label)).hexdigest()==value['sha256']
value=dict(scope='mailbox_checkpoint_not_Gazebo_G1_G2_or_Nav2_completion',
    mujoco_status='PASS',gazebo_status='FAIL',runtime_source_count=len(manifest['files']),
    source_head=manifest['head'],originals_retained=True,archive=target.name,
    size=target.stat().st_size,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),members=members)
assert value['size']<95_000_000
with ledger.open('x') as output: json.dump(value,output,indent=2)
print(json.dumps({key:v for key,v in value.items() if key!='members'},indent=2))
