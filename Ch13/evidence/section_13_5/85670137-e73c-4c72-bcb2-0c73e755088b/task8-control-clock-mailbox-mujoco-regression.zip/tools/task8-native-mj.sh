#!/usr/bin/env bash
set -e
cd /mnt/c/Users/Jinho/.codex/.chatgpt-projects/g-p-6ad1e56cf8f881919fe23e1ab94d2855/work/Pysical_AI_ROS2
source .superpowers/sdd/SECTION_13_5_IMPLEMENTATION_PLAN_KO/env-native.sh
trial_id=$(python -c 'import uuid;print(uuid.uuid4())')
trial_base="$CH13_NAV_EVIDENCE/native-g1-mujoco-$trial_id"
python Ch13/scripts/prepare_navigation_model_13_5.py --scene-engine mujoco --output-dir "$trial_base-prepared" > "$CH13_NAV_EVIDENCE/task8-mujoco-prepare-$trial_id.log" 2>&1
printf 'Native prefix: %s\nFresh MuJoCo diagnostic: %s\n' "$CH13_NAV_INSTALL" "$trial_base"
set +e
python Ch13/scripts/run_navigation_13_5.py --engine mujoco --scenario sensors-carry --scene-dir "$trial_base-prepared/scene" --profile "$trial_base-prepared/carry_profile.json" --output-dir "$trial_base" > "$CH13_NAV_EVIDENCE/task8-mujoco-runner-$trial_id.log" 2>&1
result=$?
tail -n 18 "$CH13_NAV_EVIDENCE/task8-mujoco-runner-$trial_id.log"
printf 'MuJoCo diagnostic exit: %s\nEvidence: %s\n' "$result" "$trial_base"
exit "$result"
