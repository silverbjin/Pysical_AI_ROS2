"""Controlled DDS profiling only; fixture sources are never native evidence."""
import cProfile
import io
import json
from pathlib import Path
import pstats
import sys
import threading
import time

repo = Path.cwd()
sys.path.insert(0,str(repo/'Ch13/ros2_ws/src/integrated_robot_navigation/test'))
from test_crawl_lifecycle import CrawlRig
from guard_fixture import CARRY
from integrated_robot_navigation.carry_profile import prepare_profile
from integrated_robot_navigation.model import compile_model
from integrated_robot_navigation.crawl_controller import CrawlController
from integrated_robot_navigation.clock_execution import make_control_executor
from rclpy.context import Context
from rclpy.parameter import Parameter
from rclpy.qos import qos_profile_sensor_data
from rosgraph_msgs.msg import Clock
from lifecycle_msgs.msg import Transition
import rclpy
import xacro

model = compile_model(xacro.process_file(str(repo/'Ch13/ros2_ws/src/integrated_robot_description/urdf/robot_system.urdf.xacro'),
    mappings={'hip_mount_y':'0.13'}).toxml())
reports = dict(scope='controlled_DDS_fixture_not_engine_verdict', cases={})
for mode in ('native','relay100'):
    context = Context()
    rclpy.init(context=context)
    owner = CrawlController(model,prepare_profile(model,CARRY),'mujoco',context=context,
        cli_args=['--ros-args','-r','/clock:=/navigation/control_clock'] if mode=='relay100' else None,
        parameter_overrides=[Parameter('use_sim_time',value=True),Parameter('validation_mode',value=True),
            Parameter('control_clock_mode',value=mode)])
    rig = CrawlRig(owner,model,context)
    if mode == 'relay100':
        rig.node.destroy_publisher(rig.clock)
        rig.clock = rig.node.create_publisher(Clock,'/navigation/control_clock',qos_profile_sensor_data)
    rig.executor.remove_node(owner)
    executor = make_control_executor(owner)
    executor.add_node(owner)
    profile = cProfile.Profile()
    failures = []
    def spin():
        try: profile.runcall(executor.spin)
        except BaseException as error: failures.append(repr(error))
    thread = threading.Thread(target=spin)
    thread.start()
    try:
        rig.pump(.3)
        assert rig.transition(Transition.TRANSITION_CONFIGURE)
        assert rig.transition(Transition.TRANSITION_ACTIVATE)
        started,cpu = time.monotonic(),time.process_time()
        rig.pump(3.)
        wall,cpu = time.monotonic()-started,time.process_time()-cpu
        last = rig.crawl_states[-1]
        report = dict(wall_s=wall,process_cpu_s=cpu,process_one_core_cpu_percent=100*cpu/wall,
            commands=len(rig.commands),states=len(rig.crawl_states),state=last.state,fault=last.fault_reason,
            threads=len(list(Path('/proc/self/task').iterdir())))
    finally:
        executor.shutdown(timeout_sec=2.)
        thread.join(timeout=2.)
        assert not thread.is_alive()
        rig.close()
        context.try_shutdown()
    assert not failures,failures
    buffer = io.StringIO()
    pstats.Stats(profile,stream=buffer).strip_dirs().sort_stats('tottime').print_stats(30)
    report['executor_profile'] = buffer.getvalue()
    reports['cases'][mode] = report
target = repo/'Ch13/evidence/section_13_5/85670137-e73c-4c72-bcb2-0c73e755088b/task8-sensor-dispatch-profile.json'
with target.open('x') as output: json.dump(reports,output,indent=2)
print(json.dumps(reports,indent=2))
