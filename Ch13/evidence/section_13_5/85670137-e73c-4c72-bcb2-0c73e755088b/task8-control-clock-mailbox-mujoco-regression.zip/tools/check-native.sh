#!/usr/bin/env bash
set -e
cd /mnt/c/Users/Jinho/.codex/.chatgpt-projects/g-p-6ad1e56cf8f881919fe23e1ab94d2855/work/Pysical_AI_ROS2
source .superpowers/sdd/SECTION_13_5_IMPLEMENTATION_PLAN_KO/env-native.sh
label=$1
shift
test ! -e "$CH13_NAV_EVIDENCE/$label.log"
set +e
python -m pytest "$@" -q > "$CH13_NAV_EVIDENCE/$label.log" 2>&1
result=$?
tail -n 35 "$CH13_NAV_EVIDENCE/$label.log"
exit "$result"
