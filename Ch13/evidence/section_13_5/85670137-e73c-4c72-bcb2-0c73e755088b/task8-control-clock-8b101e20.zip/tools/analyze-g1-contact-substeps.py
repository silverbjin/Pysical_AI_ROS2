"""Trace raw native 2ms contact tuples; no filtering or original verdict rewrite."""
import hashlib
import json
from pathlib import Path
import sys

root = Path(sys.argv[1])
failure_key = 'first_stop' if '--first-stop' in sys.argv[2:] else 'first_fault'
fault = json.loads((root/'controller_report.json').read_text())[failure_key]
if fault is None:
    raise SystemExit('No first fault: do not invent a contact-loss window')
t = fault['ros_ns']
raw = (root/'native_controls.json').read_bytes()
packets = json.loads(raw)
assert not packets['diagnostic_errors']
references = [r['raw_contacts'] for p in packets['records'] for r in p['body_references']]
assert references and len({r['capture_ns'] for r in references})==len(references)
window = []
for r in references:
    if abs(r['capture_ns']-t)>50_000_000:
        continue
    assert r['sample_phase']=='post_physics' and r['source']=='gazebo_ecm_raw_contact_sensor_data'
    feet = []
    for foot in r['feet']:
        feet.append(dict(name=foot['name'],center_z_m=foot['center_world'][2],
            native_pairs=len(foot['pairs']),
            native_positions=sum(len(p['positions_world']) for p in foot['pairs']),
            native_wrenches=sum(len(p['force1_world']) for p in foot['pairs']),
            sum_abs_force1_world_z_n=sum(abs(v[2]) for p in foot['pairs'] for v in p['force1_world']),
            native_depths=[d for p in foot['pairs'] for d in p['depths']]))
    window.append(dict(capture_ns=r['capture_ns'],feet=feet))
value = dict(scope='raw_native_post_step_diagnostic_not_support_acceptance_or_recovery',
    input_sha256=hashlib.sha256(raw).hexdigest(),failure_key=failure_key,fault_ros_ns=t,reason=fault['reason'],
    owner_contact_capture_ns=fault['samples']['contacts']['stamp_ns'],
    owner_forces_n=fault['samples']['contacts']['data']['forces'],window=window,
    caveat='Force sum is a raw per-foot diagnostic; no pair dedup/ground validation or normalization override. Empty lists stay empty.')
assert window
with (root/'contact-substep-postmortem.json').open('x') as handle:
    json.dump(value,handle,indent=2,allow_nan=False)
print(json.dumps({k:v for k,v in value.items() if k!='window'},indent=2))
for row in window:
    print(row['capture_ns'],[(f['name'],f['native_pairs'],round(f['sum_abs_force1_world_z_n'],4),
                              round(f['center_z_m'],7)) for f in row['feet']])
