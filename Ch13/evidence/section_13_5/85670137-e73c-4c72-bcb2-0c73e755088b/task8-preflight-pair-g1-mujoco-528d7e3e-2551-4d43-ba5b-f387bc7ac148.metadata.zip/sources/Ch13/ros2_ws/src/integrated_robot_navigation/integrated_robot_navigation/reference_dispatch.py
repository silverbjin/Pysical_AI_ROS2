"""One coalesced wake: wall control period and unmodified ROS progress.

Caller serializes this mailbox with its inbox lock. This class grants no
motion or ACK; the sole model owner must revalidate all original contracts.
"""


class ReferenceDispatch:
    period_ns=20_000_000

    def __init__(self):
        self.last_decision=None
        self.waiting=self.notified=False
        self.issues=self.notifications=0

    def allowed(self,ros_ns,wall_ns):
        if self.last_decision is None:return ros_ns>0 and wall_ns>=0
        return (ros_ns>self.last_decision[0]
            and wall_ns-self.last_decision[1]>=self.period_ns)

    def issued(self,ros_ns,wall_ns):
        """Commit the published reference's original decision clocks.

        Calculation is inside the 20ms period. Actual publication time remains
        the separate application-ACK deadline anchor in AppliedReferenceCredit.
        """
        if not self.allowed(ros_ns,wall_ns):raise ValueError('reference dispatch rate/clock')
        self.last_decision=(ros_ns,wall_ns);self.issues+=1;self.cancel()

    def defer(self):self.waiting=True

    def notify(self,ros_ns,wall_ns):
        if not self.waiting or self.notified or not self.allowed(ros_ns,wall_ns):return False
        self.notified=True;self.notifications+=1
        return True

    def take_notification(self):
        ready=self.notified
        if ready:self.cancel()
        return ready

    def begin_tick(self):self.cancel()

    def cancel(self):self.waiting=self.notified=False

    def snapshot(self):
        return dict(scope='wall_reference_decision_cadence_not_application_deadline',
            clock_rule='positive_original_ros_progress_no_extrapolation',
            last_decision=self.last_decision,waiting=self.waiting,notified=self.notified,
            period_ns=self.period_ns,issues=self.issues,notifications=self.notifications)
