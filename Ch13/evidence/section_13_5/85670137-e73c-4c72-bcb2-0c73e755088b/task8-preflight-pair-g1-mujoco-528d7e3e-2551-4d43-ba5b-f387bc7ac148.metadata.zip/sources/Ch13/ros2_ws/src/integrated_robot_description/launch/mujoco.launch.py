# Copyright 2026 Jinho
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import hashlib
import os
from pathlib import Path
import subprocess
import tempfile

from ament_index_python.packages import get_package_prefix, get_package_share_directory
from integrated_robot_vision.trace import trace_options as validate_trace_options
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction, TimerAction
from launch.substitutions import Command, LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
import yaml


def materialize_controller_config(source, plugin_source=None, *, trace_options=None, vision=False):
    """Avoid ros2_control treating a package path as a robot_description argument."""
    data = Path(source).read_bytes()
    if vision:
        config = yaml.safe_load(data)
        config['controller_manager']['ros__parameters']['arm_trajectory_controller']['type'] = (
            'integrated_robot_controller/JointTrajectoryController')
        data = yaml.safe_dump(config, sort_keys=False).encode('utf-8')
    if plugin_source is not None:
        # Controlled roots are disjoint: named controllers and /**.
        # One short file avoids native CM multi-file argv forwarding errors.
        plugin_data = Path(plugin_source).read_bytes()
        if trace_options is not None:
            options = validate_trace_options(
                trace_options['trace_enabled'], trace_options['trace_run_id'])
            if options['trace_enabled']:
                config = yaml.safe_load(plugin_data)
                eye = config['/**']['ros__parameters']['mujoco_plugins'].get('eye_camera', {})
                if eye.get('type') == 'integrated_robot_camera/SnapshotCameraPlugin':
                    eye.update(options)
                    plugin_data = yaml.safe_dump(config, sort_keys=False).encode('utf-8')
        data += b'\n' + plugin_data
    digest = hashlib.sha256(data).hexdigest()[:12]
    target = Path(tempfile.gettempdir()) / f'ch13_2_controllers_{digest}.yaml'
    if not target.exists() or target.read_bytes() != data:
        temporary = target.with_suffix('.tmp')
        temporary.write_bytes(data)
        temporary.replace(target)
    return str(target)


def camera_plugin_config(share, vision, backend='upstream'):
    if backend not in ('upstream', 'snapshot'):
        raise ValueError('vision_camera_backend must be upstream or snapshot')
    return str(Path(share)/'config'/(
        ('mujoco_snapshot_vision_plugins.yaml' if backend == 'snapshot' else
         'mujoco_vision_plugins.yaml') if vision else 'mujoco_legacy_cameras.yaml'))


def probe_snapshot_plugin(expected_prefix: Path) -> dict:
    """Actually load the selected class, then reject stale/foreign installed code."""
    try:
        prefix = Path(get_package_prefix('integrated_robot_camera')).resolve()
        probe = prefix/'lib/integrated_robot_camera/camera_plugin_probe'
        if not probe.is_file() or not probe.resolve().is_relative_to(prefix):
            raise RuntimeError('snapshot camera probe missing or outside package prefix')
        result = subprocess.run([str(probe)], check=True, capture_output=True,
                                text=True, timeout=15)
    except (OSError, subprocess.SubprocessError, LookupError) as error:
        raise RuntimeError(f'snapshot camera probe unavailable: {error}') from error
    lines = result.stdout.strip().splitlines()
    if len(lines) != 1:
        raise RuntimeError('snapshot camera probe did not return one library path')
    library = Path(lines[0])
    if not library.is_absolute() or not library.is_file():
        raise RuntimeError('snapshot camera library is not an existing absolute file')
    library = library.resolve()
    if prefix != Path(expected_prefix).resolve() or not library.is_relative_to(prefix):
        raise RuntimeError('snapshot camera library does not match expected package prefix')
    return {
        'class_id': 'integrated_robot_camera/SnapshotCameraPlugin',
        'library_path': str(library),
        'library_sha256': hashlib.sha256(library.read_bytes()).hexdigest(),
        'package_prefix': str(prefix),
    }


def launch_nodes(context):
    trace = validate_trace_options(
        LaunchConfiguration('trace_enabled', default='false').perform(context),
        LaunchConfiguration('trace_run_id', default='').perform(context))
    share = get_package_share_directory('integrated_robot_description')
    vision = LaunchConfiguration('vision_enabled').perform(context).lower() == 'true'
    backend = LaunchConfiguration('vision_camera_backend', default='upstream').perform(context)
    navigation = LaunchConfiguration('navigation_enabled', default='false').perform(context).lower() == 'true'
    scene = None
    if navigation:
        from integrated_robot_navigation.scene import load_scene
        scene = load_scene('mujoco', LaunchConfiguration('navigation_scene').perform(context))
        if not vision or backend != 'snapshot':
            raise ValueError('navigation requires vision and the owned snapshot camera')
    camera_config = camera_plugin_config(share, vision, backend)
    if navigation:
        camera_config = LaunchConfiguration('navigation_plugins').perform(context)
    if vision and backend == 'snapshot':
        probe_snapshot_plugin(Path(get_package_prefix('integrated_robot_camera')))
    xacro_path = os.path.join(share, 'urdf', 'robot_system.urdf.xacro')
    model_path = LaunchConfiguration('model_path').perform(context) or os.path.join(
        share, 'mujoco', 'vision_fixture.xml' if vision else 'robot_system.xml')
    if scene:
        requested = LaunchConfiguration('model_path').perform(context)
        if requested and Path(requested).resolve() != Path(scene['world']['path']).resolve():
            raise ValueError('navigation model_path must match bound scene')
        model_path = scene['world']['path']
    controllers = materialize_controller_config(
        scene['controllers']['path'] if scene else os.path.join(share, 'config', 'controllers.yaml'),
        camera_config,
        trace_options=trace if vision and backend == 'snapshot' else None,
        vision=vision,
    )
    description = ParameterValue(
        Command(
            ['xacro ', xacro_path, ' control_backend:=mujoco mujoco_model_path:=', model_path,
             ' vision_enabled:=', str(vision).lower(),
             ' mujoco_auto_register_cameras:=',
             str(not (vision and backend == 'snapshot')).lower(),
             ' mujoco_headless:=', LaunchConfiguration('mujoco_headless').perform(context)]
        ),
        value_type=str,
    )
    if scene:
        description = ParameterValue(Path(scene['robot']['path']).read_text(), value_type=str)
    control_node = Node(
        package='mujoco_ros2_control',
        executable='ros2_control_node',
        output='screen',
        parameters=[{'robot_description': description, 'use_sim_time': True}, controllers],
    )
    state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[{'robot_description': description, 'use_sim_time': True}],
    )
    spawners = [
        Node(
            package='controller_manager',
            executable='spawner',
            arguments=[name, '--param-file', controllers],
            output='screen',
        )
        for name in (
            'joint_state_broadcaster',
            'leg_position_controller',
            'arm_trajectory_controller',
            'gripper_position_controller',
        )
    ]
    nodes = [control_node, state_publisher, TimerAction(period=3.0, actions=spawners)]
    if vision:
        nodes.append(Node(package='integrated_robot_vision', executable='native_pose_adapter',
                          parameters=[{'engine': 'mujoco', 'use_sim_time': not navigation}]))
        nodes.append(Node(package='integrated_robot_vision',
                          executable='native_camera_info_adapter',
                          parameters=[{'use_sim_time': not navigation}]))
    return nodes


def generate_launch_description():
    return LaunchDescription([DeclareLaunchArgument('vision_enabled', default_value='false'),
                              DeclareLaunchArgument(
                                  'vision_camera_backend', default_value='upstream'),
                              DeclareLaunchArgument('mujoco_headless', default_value='false'),
                              DeclareLaunchArgument('model_path', default_value=''),
                              DeclareLaunchArgument('trace_enabled', default_value='false'),
                              DeclareLaunchArgument('trace_run_id', default_value=''),
                              DeclareLaunchArgument('navigation_enabled', default_value='false'),
                              DeclareLaunchArgument('navigation_scene', default_value=''),
                              DeclareLaunchArgument('navigation_plugins', default_value=''),
                              OpaqueFunction(function=launch_nodes)])
