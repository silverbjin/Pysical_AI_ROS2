#!/usr/bin/env bash
set -e
cd /mnt/c/Users/Jinho/.codex/.chatgpt-projects/g-p-6ad1e56cf8f881919fe23e1ab94d2855/work/Pysical_AI_ROS2
source .superpowers/sdd/SECTION_13_5_IMPLEMENTATION_PLAN_KO/env-native.sh
label=$1
test ! -e "$CH13_NAV_EVIDENCE/$label-build.log"
cmake -S Ch13/ros2_ws/src/integrated_robot_navigation_sensors -B "$CH13_NAV_BUILD/integrated_robot_navigation_sensors" > "$CH13_NAV_EVIDENCE/$label-build.log" 2>&1 || { tail -n30 "$CH13_NAV_EVIDENCE/$label-build.log"; exit 1; }
cmake --build "$CH13_NAV_BUILD/integrated_robot_navigation_sensors" --target test_control_clock_gate test_control_clock_ros -j2 >> "$CH13_NAV_EVIDENCE/$label-build.log" 2>&1 || { tail -n30 "$CH13_NAV_EVIDENCE/$label-build.log"; exit 1; }
set +e
"$CH13_NAV_BUILD/integrated_robot_navigation_sensors/test_control_clock_ros" --gtest_output="xml:$CH13_NAV_EVIDENCE/$label.xml" > "$CH13_NAV_EVIDENCE/$label.log" 2>&1
result=$?
tail -n30 "$CH13_NAV_EVIDENCE/$label.log"
exit "$result"
