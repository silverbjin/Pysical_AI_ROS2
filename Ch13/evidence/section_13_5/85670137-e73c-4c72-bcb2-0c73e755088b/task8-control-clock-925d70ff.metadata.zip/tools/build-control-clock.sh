#!/usr/bin/env bash
set -e
cd /mnt/c/Users/Jinho/.codex/.chatgpt-projects/g-p-6ad1e56cf8f881919fe23e1ab94d2855/work/Pysical_AI_ROS2
source .superpowers/sdd/SECTION_13_5_IMPLEMENTATION_PLAN_KO/env-native.sh
label=$1
test ! -e "$CH13_NAV_EVIDENCE/$label-build.log"
export CMAKE_BUILD_PARALLEL_LEVEL=2
python /usr/bin/colcon --log-base "$CH13_NAV_LOG" build --base-paths Ch13/ros2_ws/src --build-base "$CH13_NAV_BUILD" --install-base "$CH13_NAV_INSTALL" --packages-select integrated_robot_navigation_sensors integrated_robot_navigation --executor sequential --cmake-args -DCMAKE_BUILD_TYPE=RelWithDebInfo > "$CH13_NAV_EVIDENCE/$label-build.log" 2>&1 || { tail -n30 "$CH13_NAV_EVIDENCE/$label-build.log"; exit 1; }
tail -n8 "$CH13_NAV_EVIDENCE/$label-build.log"
source "$CH13_NAV_INSTALL/local_setup.bash"
set +e
python /usr/bin/colcon --log-base "$CH13_NAV_LOG" test --base-paths Ch13/ros2_ws/src --build-base "$CH13_NAV_BUILD" --install-base "$CH13_NAV_INSTALL" --packages-select integrated_robot_navigation_sensors integrated_robot_navigation --executor sequential --return-code-on-test-failure > "$CH13_NAV_EVIDENCE/$label-test.log" 2>&1
result=$?
tail -n15 "$CH13_NAV_EVIDENCE/$label-test.log"
python /usr/bin/colcon test-result --test-result-base "$CH13_NAV_BUILD/integrated_robot_navigation_sensors" --verbose
python /usr/bin/colcon test-result --test-result-base "$CH13_NAV_BUILD/integrated_robot_navigation" --verbose
test "$result" = 0 || exit "$result"
bash .superpowers/sdd/SECTION_13_5_IMPLEMENTATION_PLAN_KO/audit-native.sh "$label-install-audit"
