#!/usr/bin/env bash
set -e
cd /mnt/c/Users/Jinho/.codex/.chatgpt-projects/g-p-6ad1e56cf8f881919fe23e1ab94d2855/work/Pysical_AI_ROS2
source .superpowers/sdd/SECTION_13_5_IMPLEMENTATION_PLAN_KO/env-native.sh
build="$CH13_NAV_NATIVE_ROOT/build/dart-default-query"
test ! -e "$build"
test ! -e "$CH13_NAV_EVIDENCE/task8-calibration-dart-contact-default.json"
cmake -S .superpowers/sdd/SECTION_13_5_IMPLEMENTATION_PLAN_KO/dart-default-query -B "$build" > "$CH13_NAV_EVIDENCE/task8-calibration-dart-contact-default-cmake.log" 2>&1
cmake --build "$build" --parallel 2 >> "$CH13_NAV_EVIDENCE/task8-calibration-dart-contact-default-cmake.log" 2>&1
ldd "$build/query_dart_contact_default" > "$CH13_NAV_EVIDENCE/task8-calibration-dart-contact-default-libraries.log"
"$build/query_dart_contact_default" > "$CH13_NAV_EVIDENCE/task8-calibration-dart-contact-default.json"
sha256sum "$build/query_dart_contact_default" > "$CH13_NAV_EVIDENCE/task8-calibration-dart-contact-default-binary.sha256"
cat "$CH13_NAV_EVIDENCE/task8-calibration-dart-contact-default.json"
