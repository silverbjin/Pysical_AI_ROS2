"""Archive reproducible read-only analysis and fresh verification, no promotion."""
import hashlib
import json
from pathlib import Path
import zipfile

repo=Path.cwd().resolve();tools=Path(__file__).parent
base=repo/'Ch13/evidence/section_13_5/85670137-e73c-4c72-bcb2-0c73e755088b'
target=base/'task8-contact-boundary-analysis-20261025.zip'
ledger=target.with_suffix('.json');assert not target.exists() and not ledger.exists()
members={}
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED) as archive:
    def add(path,label):
        raw=path.read_bytes();sha=hashlib.sha256(raw).hexdigest();assert label not in members
        archive.writestr(label,raw);members[label]=dict(size=len(raw),sha256=sha)
    for name in ('analyze-g1-phase-contact.py','analyze-g1-contact-events.py','analyze-event-body-fit.py',
        'analyze-event-body-fit.sh','analyze-contact-gap-transition.py','query-dart-contact-default.cpp',
        'query-dart-contact-default-cmake.sh','dart-default-query/CMakeLists.txt','archive-contact-analysis.py'):
        add(tools/name,'tools/'+name)
    for name in ('native-g1-gazebo-e2cb2cc1-96ca-4689-8c6f-439975d3c2c4',
                 'native-g1-gazebo-15aaca4a-0333-4f16-a46f-abcf2e8bc93f',
                 'native-g1-gazebo-3d830070-5d58-47c3-9db1-4a15c0835319'):
        for path in (base/name).glob('*postmortem.json'):add(path,'postmortem/'+name+'/'+path.name)
    for pattern in ('task8-calibration-reference-ramp-full.log','task8-calibration-contact-event-post-native*',
                    'task8-calibration-dart-contact-default*'):
        for path in base.glob(pattern):
            if path.is_file():add(path,'verification/'+path.name)
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    for name,record in members.items():assert hashlib.sha256(archive.read(name)).hexdigest()==record['sha256']
value=dict(scope='read_only_contact_boundary_analysis_not_G1_G2_Nav2_completion',
    archive=target.name,size=target.stat().st_size,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),members=members)
with ledger.open('x') as output:json.dump(value,output,indent=2)
print(json.dumps({k:v for k,v in value.items() if k!='members'},indent=2))
