"""Offline rigid root fit from four actual foot centres + actual joint FK.

Not odometry, command generation, a root setter, or native accelerometer data.
"""
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
from integrated_robot_navigation.model import compile_model
from integrated_robot_navigation.leg_kinematics import fk_leg

root=Path(sys.argv[1]);source=root/'contact-event-postmortem.json'
raw=source.read_bytes();events=json.loads(raw)
urdf=root.with_name(root.name+'-prepared')/'scene/robot.urdf'
model=compile_model(urdf.read_text())
fits=[]
for row in events['rows']:
    joints={j['name']:j['position'] for j in row['joints']}
    local=np.array([fk_leg(model,foot,tuple(joints[foot[:2]+'_'+part+'_joint'] for part in ('hip','thigh','calf')))
                    for foot in model.feet])
    world=np.array([next(f['center_world'] for f in row['feet'] if f['name']==foot) for foot in model.feet])
    x,y=local-local.mean(axis=0),world-world.mean(axis=0)
    u,s,vt=np.linalg.svd(x.T@y)
    assert s[1]>1e-8,'collinear foot fit'
    r=vt.T@np.diag([1.,1.,np.linalg.det(vt.T@u.T)])@u.T
    p=world.mean(axis=0)-r@local.mean(axis=0)
    residual=float(np.max(np.linalg.norm((r@local.T).T+p-world,axis=1)))
    assert residual<1e-8,(row['capture_ns'],residual,'not a rigid fit: do not infer root motion')
    fits.append(dict(capture_ns=row['capture_ns'],position_world_m=p.tolist(),rotation_world=r.tolist(),
        fit_max_residual_m=residual,native_angular_velocity=row['angular_velocity'],
        missing_pairs=[f['name'] for f in row['feet'] if not f['pair_count']],
        arm_velocity={j['name']:j['velocity'] for j in row['joints'] if j['name'].startswith('arm_')},
        gripper_velocity={j['name']:j['velocity'] for j in row['joints'] if j['name'].startswith('gripper_')}))
accelerations=[]
for i in range(2,len(fits)):
    a,b,c=fits[i-2:i+1]
    if b['capture_ns']-a['capture_ns']!=2_000_000 or c['capture_ns']-b['capture_ns']!=2_000_000:continue
    value=(np.array(c['position_world_m'])-2*np.array(b['position_world_m'])+np.array(a['position_world_m']))/.002**2
    accelerations.append(dict(capture_ns=c['capture_ns'],position_second_difference_mps2=value.tolist(),
        norm_mps2=float(np.linalg.norm(value))))
assert accelerations
value=dict(scope='offline_measured_FK_rigid_fit_not_native_accelerometer_or_causal_proof',
    input_sha256=hashlib.sha256(raw).hexdigest(),model_sha256=model.model_sha256,
    maximum_fit_residual_m=max(r['fit_max_residual_m'] for r in fits),
    maximum_discrete_acceleration=max(accelerations,key=lambda r:r['norm_mps2']),
    fits=fits,discrete_accelerations=accelerations,
    caveats=['Acceleration is a two-step position second difference at2ms, not an IMU sample.',
        'No interpolation across missing captures; actual foot centres and post-step joint angles only.',
        'No contact support/force value, runtime pose, original sensor header or verdict is replaced.'])
with (root/'event-body-fit-postmortem.json').open('x') as output:json.dump(value,output,indent=2,allow_nan=False)
print(json.dumps({k:v for k,v in value.items() if k not in ('fits','discrete_accelerations')},indent=2))
for row in sorted(accelerations,key=lambda r:r['norm_mps2'],reverse=True)[:5]:print(json.dumps(row))
