// Read-only installed DART API query, not an engine or setting change.
#include <dart/constraint/ContactConstraint.hpp>
#include <iomanip>
#include <iostream>
int main()
{
  std::cout<<std::setprecision(17)<<"{\"error_allowance_m\":"
    <<dart::constraint::ContactConstraint::getErrorAllowance()<<"}\n";
}
