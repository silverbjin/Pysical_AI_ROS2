"""Raw last-loaded/lost/restored triplets; no promotion from geometry to force."""
import hashlib
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

root=Path(sys.argv[1]);raw=(root/'native_controls.json').read_bytes();data=json.loads(raw)
urdf=ET.parse(root.with_name(root.name+'-prepared')/'scene/robot.urdf')
references=[r['raw_contacts'] for p in data['records'] if p['stage']=='calibrate' for r in p['body_references']]
rows=[]
for i in range(1,len(references)-1):
    before,current,after=references[i-1:i+2]
    if current['capture_ns']-before['capture_ns']!=2_000_000 or after['capture_ns']-current['capture_ns']!=2_000_000:continue
    for foot in current['feet']:
        previous=next(f for f in before['feet'] if f['name']==foot['name'])
        following=next(f for f in after['feet'] if f['name']==foot['name'])
        if foot['pair_count'] or not previous['pair_count']:continue
        sphere=urdf.find(f"link[@name='{foot['name']}']/collision/geometry/sphere")
        assert sphere is not None
        radius=float(sphere.get('radius'))
        rows.append(dict(name=foot['name'],loss_capture_ns=current['capture_ns'],radius_m=radius,
            before=dict(capture_ns=before['capture_ns'],center_z_m=previous['center_world'][2],
                sphere_bottom_world_z_m=previous['center_world'][2]-radius,
                raw_normal_magnitude_n=previous['sum_abs_force1_world_z_n']),
            lost=dict(center_z_m=foot['center_world'][2],pair_count=0),
            restored=dict(capture_ns=after['capture_ns'],center_z_m=following['center_world'][2],
                pair_count=following['pair_count'],raw_normal_magnitude_n=following['sum_abs_force1_world_z_n'])))
assert rows
value=dict(scope='raw_contact_triplets_not_solver_bug_or_airborne_proof',
    input_sha256=hashlib.sha256(raw).hexdigest(),rows=rows,
    caveats=['Bottom is world z minus URDF sphere radius, not a force/support substitute.',
        'Validate ground top and engine pose update semantics before attributing a geometric separation.',
        'A tiny positive bottom or empty pair alone does not prove collision detector causality.'])
with (root/'contact-gap-transition-postmortem.json').open('x') as output:json.dump(value,output,indent=2)
print(json.dumps(value,indent=2))
