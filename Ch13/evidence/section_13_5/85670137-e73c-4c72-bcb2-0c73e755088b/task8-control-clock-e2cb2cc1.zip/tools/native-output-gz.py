"""One storage-location comparison; runtime/model/thresholds remain unchanged."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import uuid

repo = Path.cwd().resolve()
native = Path('/home/jinho/ch13_5_completion_85670137-e73c-4c72-bcb2-0c73e755088b')
assert native.resolve() == native and native.stat().st_uid == os.getuid()
base = repo/'Ch13/evidence/section_13_5/85670137-e73c-4c72-bcb2-0c73e755088b'
key = str(uuid.uuid4())
name = 'native-g1-gazebo-'+key
prepared = base/(name+'-prepared')  # keep model storage equal to preceding run
destination = base/name
output = native/'evidence'/name
assert not destination.exists() and not output.exists() and not prepared.exists()
output.parent.mkdir(exist_ok=True)
assert output.resolve().is_relative_to(native)
prepare_log = native/'evidence'/('prepare-'+key+'.log')
with prepare_log.open('x') as log:
    subprocess.run([sys.executable, 'Ch13/scripts/prepare_navigation_model_13_5.py',
        '--scene-engine', 'gazebo', '--output-dir', str(prepared)], stdout=log,
        stderr=subprocess.STDOUT, check=True)
driver_log = native/'evidence'/('runner-'+key+'.log')
attribution_log = native/'evidence'/('attribution-'+key+'.log')
print(json.dumps(dict(native_output=str(output), preserved_destination=str(destination),
    record_storage='WSL_native', purpose=os.environ.get('CH13_GZ_TRIAL_PURPOSE','native-output-debugging'),
    lp_num_threads=os.environ.get('LP_NUM_THREADS')), indent=2), flush=True)
with attribution_log.open('x') as log, driver_log.open('x') as driver:
    observer = subprocess.Popen([sys.executable,
        '.superpowers/sdd/SECTION_13_5_IMPLEMENTATION_PLAN_KO/capture-native-tree.py', str(output)],
        stdout=log, stderr=subprocess.STDOUT)
    clock_log = None
    clock_observer = None
    if os.environ.get('CH13_CLOCK_RATE_DIAGNOSTIC') == '1':
        clock_log = (native/'evidence'/('clock-rate-'+key+'.log')).open('x')
        clock_observer = subprocess.Popen([sys.executable,
            '.superpowers/sdd/SECTION_13_5_IMPLEMENTATION_PLAN_KO/capture-clock-rate.py',str(output)],
            stdout=clock_log,stderr=subprocess.STDOUT)
    result = subprocess.run([sys.executable, 'Ch13/scripts/run_navigation_13_5.py',
        '--engine', 'gazebo', '--scenario', 'sensors-carry', '--scene-dir', str(prepared/'scene'),
        '--profile', str(prepared/'carry_profile.json'), '--output-dir', str(output),
        '--control-clock-mode', os.environ.get('CH13_CONTROL_CLOCK_MODE','native')],
        stdout=driver, stderr=subprocess.STDOUT)
    attribution_code = observer.wait(timeout=90.)
    clock_code = clock_observer.wait(timeout=75.) if clock_observer else None
    if clock_log:
        clock_log.close()
# Preserve original native evidence. Never delete/move or rewrite its manifests.
shutil.copytree(output, destination)
copied = {}
for path in output.rglob('*'):
    if path.is_file():
        relative = path.relative_to(output)
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        assert hashlib.sha256((destination/relative).read_bytes()).hexdigest() == digest
        copied[str(relative)] = digest
for original in (prepare_log, driver_log, attribution_log):
    target = base/('task8-native-output-'+original.name)
    assert not target.exists()
    shutil.copyfile(original, target)
if clock_observer:
    shutil.copyfile(Path(clock_log.name),base/('task8-native-output-clock-rate-'+key+'.log'))
teardown = json.loads((output/'teardown.json').read_text())
ledger = dict(scope='byte_exact_copy_after_trial_native_original_retained',
    command_output_root=str(output), repository_copy=str(destination), files=copied,
    runner_returncode=result.returncode, attribution_returncode=attribution_code,
    purpose=os.environ.get('CH13_GZ_TRIAL_PURPOSE','native-output-debugging'),
    control_clock_mode=os.environ.get('CH13_CONTROL_CLOCK_MODE','native'),
    clock_diagnostic_returncode=clock_code,
    driver_does_not_edit_runtime_or_model=True)
with (destination/'storage-copy-ledger.json').open('x') as handle:
    json.dump(ledger, handle, indent=2)
print(json.dumps(dict(path=str(destination), status=json.loads((output/'result.json').read_text())['status'],
    runner_returncode=result.returncode, copied_files=len(copied),
    forced_cleanup=teardown['forced_cleanup'], residual=teardown['residual_live_pids']), indent=2), flush=True)
if teardown['residual_live_pids'] or not teardown['parent_reaped']:
    raise RuntimeError('owned cleanup unconfirmed; do not start another engine')
raise SystemExit(result.returncode)
