"""Exact completed source/evidence checkpoint, without promoting its verdict."""
import hashlib
import json
from pathlib import Path
import sys
import zipfile

repo=Path.cwd().resolve()
base=repo/'Ch13/evidence/section_13_5/85670137-e73c-4c72-bcb2-0c73e755088b'
root=(base/sys.argv[1]).resolve(strict=True)
assert root.parent==base and root.name.startswith(('native-g1-mujoco-','native-g1-gazebo-'))
label=sys.argv[2]
assert label.replace('-','').isalnum()
target=base/(label+'.zip')
ledger=target.with_suffix('.json')
assert not target.exists() and not ledger.exists()
manifest=json.loads((root/'source_manifest.json').read_text())
result=json.loads((root/'result.json').read_text())
teardown=json.loads((root/'teardown.json').read_text())
assert teardown['parent_reaped'] and not teardown['residual_live_pids']
members={}
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    def add(path,name,expected=None):
        raw=path.read_bytes();sha=hashlib.sha256(raw).hexdigest()
        assert expected is None or sha==expected,path
        assert name not in members
        archive.writestr(name,raw);members[name]=dict(size=len(raw),sha256=sha)
    for name,sha in manifest['files'].items():add(repo/name,'sources/'+name,sha)
    for directory in (root,root.with_name(root.name+'-prepared')):
        for path in sorted(directory.rglob('*')):
            if path.is_file():add(path,'evidence/'+str(path.relative_to(base)))
    for path in sorted((repo/'Ch13/ros2_ws/src/integrated_robot_navigation/test').rglob('*.py')):
        add(path,'tests/'+path.name)
    for name in ('task8-calibration-preload-return-related.log',
                 'task8-calibration-native-reference-qos-green.log',
                 'task8-calibration-preload-return-native-build.log',
                 'task8-calibration-preload-return-qos-audit.json'):
        add(base/name,'verification/'+name)
    add(Path(__file__),'tools/'+Path(__file__).name)
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    for name,entry in members.items():assert hashlib.sha256(archive.read(name)).hexdigest()==entry['sha256']
value=dict(scope='completed_trial_checkpoint_not_Gazebo_G2_Nav2_or_section_completion',
    trial=root.name,status=result['status'],required_checks=result['required_checks'],
    checks=result['checks'],source_count=len(manifest['files']),source_head=manifest['head'],
    source_manifest_sha256=hashlib.sha256((root/'source_manifest.json').read_bytes()).hexdigest(),
    archive=target.name,size=target.stat().st_size,
    sha256=hashlib.sha256(target.read_bytes()).hexdigest(),originals_retained=True,members=members)
assert value['size']<95_000_000
with ledger.open('x') as output:json.dump(value,output,indent=2,allow_nan=False)
print(json.dumps({k:v for k,v in value.items() if k not in ('members','checks','required_checks')},indent=2))
