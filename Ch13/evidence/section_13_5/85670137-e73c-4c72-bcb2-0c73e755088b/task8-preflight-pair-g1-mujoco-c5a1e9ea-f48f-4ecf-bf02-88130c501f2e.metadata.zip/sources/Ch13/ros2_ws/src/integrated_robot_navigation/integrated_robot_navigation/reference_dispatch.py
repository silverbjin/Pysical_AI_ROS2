"""One coalesced wake, with original ROS/wall command spacing.

Caller serializes this mailbox with its inbox lock. This class grants no
motion or ACK; the sole model owner must revalidate all original contracts.
"""


class ReferenceDispatch:
    period_ns=20_000_000

    def __init__(self):
        self.last_issue=None
        self.waiting=self.notified=False
        self.issues=self.notifications=0

    def allowed(self,ros_ns,wall_ns):
        return self.last_issue is None or min(ros_ns-self.last_issue[0],
            wall_ns-self.last_issue[1])>=self.period_ns

    def issued(self,ros_ns,wall_ns):
        if not self.allowed(ros_ns,wall_ns):raise ValueError('reference dispatch rate/clock')
        self.last_issue=(ros_ns,wall_ns);self.issues+=1;self.cancel()

    def defer(self):self.waiting=True

    def notify(self,ros_ns,wall_ns):
        if not self.waiting or self.notified or not self.allowed(ros_ns,wall_ns):return False
        self.notified=True;self.notifications+=1
        return True

    def take_notification(self):
        ready=self.notified
        if ready:self.cancel()
        return ready

    def begin_tick(self):self.cancel()

    def cancel(self):self.waiting=self.notified=False

    def snapshot(self):
        return dict(last_issue=self.last_issue,waiting=self.waiting,notified=self.notified,
            period_ns=self.period_ns,issues=self.issues,notifications=self.notifications)
