"""Bounded/coalesced notification is not command permission or an ACK."""
import importlib
import pytest


def gate():
    assert importlib.util.find_spec('integrated_robot_navigation.reference_dispatch'), \
        'single-owner reference wake admission missing'
    return importlib.import_module('integrated_robot_navigation.reference_dispatch').ReferenceDispatch()


@pytest.mark.parametrize('ros,wall',[(119_999_999,120_000_000),(120_000_000,119_999_999)])
def test_neither_clock_can_bypass_the_20ms_command_spacing(ros,wall):
    value=gate();value.issued(100_000_000,100_000_000);value.defer()
    assert not value.allowed(ros,wall)
    assert not value.notify(ros,wall)
    assert not value.take_notification()
    assert value.allowed(120_000_000,120_000_000)
    assert value.notify(120_000_000,120_000_000)
    assert not value.notify(121_000_000,121_000_000), 'duplicate notification accumulated'
    assert value.take_notification() and not value.take_notification()


def test_new_issue_cancels_old_wait_and_never_releases_a_second_command_early():
    value=gate();value.issued(100_000_000,100_000_000);value.defer()
    assert value.notify(125_000_000,125_000_000)
    value.begin_tick()  # a regular timer can supersede a queued notification
    assert not value.take_notification()
    value.issued(125_000_000,125_000_000);value.defer()
    assert not value.notify(144_999_999,145_000_000)
    assert value.notify(145_000_000,145_000_000)
    value.cancel()
    assert not value.take_notification() and not value.notify(200_000_000,200_000_000)
