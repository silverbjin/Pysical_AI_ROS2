"""A slow evidence sink must not own the native observation ingress lock."""
import json
import threading
import time
import pytest
import rclpy
from rclpy.context import Context
from probe_navigation_13_5 import NavigationProbe


def test_slow_journal_write_does_not_block_probe_callback_and_is_joined(tmp_path,monkeypatch):
    context=Context();rclpy.init(context=context)
    probe=NavigationProbe(tmp_path,engine='gazebo',bounded_history=True,context=context)
    entered,release,finished=threading.Event(),threading.Event(),threading.Event()
    original=probe.raw.write;errors=[]
    def blocked(value):
        entered.set()
        assert release.wait(3.)
        return original(value)
    monkeypatch.setattr(probe.raw,'write',blocked)
    def callback():
        try:probe._dispatch(probe._write,'controlled',dict(capture_ns=123))
        except BaseException as error:errors.append(error)
        finally:finished.set()
    producer=threading.Thread(target=callback)
    try:
        producer.start()
        assert entered.wait(1.)
        assert finished.wait(.15),'file IO still blocks the ingress callback'
        assert not errors
        assert probe._lock.acquire(timeout=.05),'file IO still owns the native inbox lock'
        probe._lock.release()
        release.set();producer.join(1.)
        probe.restore_history(receiver_joined=True)
        assert probe.journal.report()['joined'] is True
        assert probe.journal.report()['submitted']==probe.journal.report()['written']==1
        assert json.loads((tmp_path/'observations.jsonl').read_text())['value']['capture_ns']==123
    finally:
        release.set();producer.join(3.)
        probe.close_log();probe.destroy_node();context.try_shutdown()


@pytest.mark.parametrize('bound',['records','bytes'])
def test_journal_overflow_is_sticky_without_overwrite_and_drain_is_joined(tmp_path,bound):
    from probe_navigation_13_5 import EvidenceJournal
    entered,release=threading.Event(),threading.Event()
    sink=(tmp_path/'journal').open('w');original=sink.write
    def blocked(value):
        entered.set();assert release.wait(2.)
        return original(value)
    sink.write=blocked
    writer=EvidenceJournal(sink,max_records=1 if bound=='records' else 3,
                           max_bytes=4 if bound=='bytes' else 1024)
    try:
        writer.submit('1234');assert entered.wait(1.)
        with pytest.raises(RuntimeError,match='capacity'):writer.submit('5')
        with pytest.raises(RuntimeError,match='capacity'):writer.submit('6')
        release.set()
        with pytest.raises(RuntimeError,match='capacity'):writer.close(timeout_sec=1.)
        assert writer.report()['joined']
        assert writer.report()['submitted']==writer.report()['written']==1
        assert (tmp_path/'journal').read_text()=='1234'
    finally:
        release.set()
        try:writer.close(timeout_sec=2.)
        except RuntimeError:pass


def test_journal_error_and_join_timeout_never_become_success(tmp_path):
    from probe_navigation_13_5 import EvidenceJournal
    entered,release=threading.Event(),threading.Event()
    sink=(tmp_path/'journal').open('w')
    def broken(value):
        entered.set();assert release.wait(2.)
        raise OSError('injected disk error')
    sink.write=broken;writer=EvidenceJournal(sink)
    try:
        writer.submit('original');assert entered.wait(1.)
        with pytest.raises(RuntimeError,match='not joined'):writer.close(timeout_sec=.01)
        assert not writer.report()['joined']
        with pytest.raises(RuntimeError,match='closed'):writer.submit('late')
        release.set()
        with pytest.raises(RuntimeError,match='injected disk error'):writer.close(timeout_sec=1.)
        assert writer.report()['joined'] and writer.report()['written']==0
        assert sink.closed
    finally:
        release.set()
        try:writer.close(timeout_sec=2.)
        except RuntimeError:pass


def test_probe_journal_preserves_immutable_submission_and_order(tmp_path):
    context=Context();rclpy.init(context=context)
    probe=NavigationProbe(tmp_path,engine='gazebo',bounded_history=True,context=context)
    try:
        value=dict(nested=dict(capture_ns=17))
        probe._write('first',value);value['nested']['capture_ns']=99
        probe._write('second',dict(capture_ns=18))
        probe.restore_history(receiver_joined=True)
        rows=[json.loads(x) for x in (tmp_path/'observations.jsonl').read_text().splitlines()]
        assert rows==[dict(kind='first',value=dict(nested=dict(capture_ns=17))),
                      dict(kind='second',value=dict(capture_ns=18))]
        assert probe.journal.report()['written']==2
    finally:probe.close_log();probe.destroy_node();context.try_shutdown()


def test_actual_dds_native_ingress_continues_while_sink_waits(tmp_path,nav_robot_model,monkeypatch):
    from carry_feedback_peer import CarryFeedbackPeer
    from guard_fixture import bundle
    from probe_navigation_13_5 import ProbeReceiver
    peer=CarryFeedbackPeer(nav_robot_model.model_sha256,bundle(nav_robot_model).joints.data['position'])
    context=Context();rclpy.init(context=context)
    probe=NavigationProbe(tmp_path,engine='gazebo',bounded_history=True,context=context)
    entered,release=threading.Event(),threading.Event();original=probe.raw.write
    def blocked(value):
        entered.set();assert release.wait(3.)
        return original(value)
    monkeypatch.setattr(probe.raw,'write',blocked)
    receiver=ProbeReceiver(probe)
    try:
        assert entered.wait(2.)
        with probe._lock:first=probe.inbox.samples['joints']
        assert first is not None
        time.sleep(.25)
        receiver.check()
        with probe._lock:latest=probe.inbox.samples['joints']
        assert latest.stamp_ns>first.stamp_ns
        assert time.monotonic_ns()-latest.received_ns<100_000_000
        assert probe.journal.report()['written']==0
        release.set()
        assert receiver.shutdown(timeout_sec=2.)
        probe.restore_history(receiver_joined=True)
        assert probe.journal.report()['submitted']==probe.journal.report()['written']
    finally:
        release.set()
        assert receiver.shutdown(timeout_sec=2.)
        probe.close_log();probe.destroy_node();context.try_shutdown();peer.close()
