"""Postmortem on original sensor/probe captures, not an owner replay or PASS."""
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
from integrated_robot_navigation.model import compile_model
from integrated_robot_navigation.leg_kinematics import fk_leg
from integrated_robot_navigation.projection import body_rotation

root = Path(sys.argv[1]).resolve()
frames = json.loads((root/'all_frames.json').read_text())['frames']
report = json.loads((root/'controller_report.json').read_text())
scene = root.with_name(root.name+'-prepared')/'scene/robot.urdf'
model = compile_model(scene.read_text())
def center(row):
    samples = row['samples']
    body = samples['body']['data']
    q = samples['joints']['data']['position']
    rotation,_ = body_rotation(body)
    return rotation @ np.array(fk_leg(model,'fl_foot',tuple(q['fl_'+part+'_joint'] for part in
        ('hip','thigh','calf'))))+np.array(body['position'])
stand = [row for row in frames if row['stage']=='stand']
rows = [row for row in frames if row['stage']=='calibrate']
baseline = float(center(stand[0])[2])
phases,first_unloaded,first_lift = [],None,None
maximum = -1.
for row in rows:
    key = (row['crawl']['state'],row['crawl']['phase'])
    observation = dict(phase='/'.join(key),ros_ns=row['ros_ns'],wall_ns=row['wall_ns'],
        contacts_stamp_ns=row['samples']['contacts']['stamp_ns'],
        fl_force_n=row['samples']['contacts']['data']['forces'][1],
        measured_fl_center_z_m=float(center(row)[2]))
    observation['measured_lift_m'] = observation['measured_fl_center_z_m']-baseline
    maximum = max(maximum,observation['measured_lift_m'])
    if not phases or phases[-1]['phase'] != observation['phase']: phases.append(observation)
    if first_unloaded is None and observation['fl_force_n'] < 2.: first_unloaded = observation
    if first_lift is None and observation['fl_force_n'] < 2. and observation['measured_lift_m'] >= .005:
        first_lift = observation
value = dict(scope='asynchronous_probe_postmortem_not_owner_replay_or_new_acceptance',
    frame_sha256=hashlib.sha256((root/'all_frames.json').read_bytes()).hexdigest(),
    baseline_center_z_m=baseline,phase_changes=phases,first_force_below_2n=first_unloaded,
    first_measured_5mm_lift=first_lift,max_lift_m=maximum,
    last_probe=dict(ros_ns=rows[-1]['ros_ns'],wall_ns=rows[-1]['wall_ns'],crawl=rows[-1]['crawl']),
    owner_report_current=report['current'],
    elapsed_at_first_lift_wall_s=(first_lift['wall_ns']-rows[0]['wall_ns'])/1e9 if first_lift else None,
    caveat='FK body/joint/contact captures differ; no exact owner trajectory or completion inferred.')
target = root/'calibration-budget-postmortem.json'
with target.open('x') as output: json.dump(value,output,indent=2,allow_nan=False)
print(json.dumps({key:value for key,value in value.items() if key!='owner_report_current'},indent=2))
