"""Real DDS local-loop cost only; not sensors, control or physical acceptance."""
import json
from pathlib import Path
import sys
import time
import rclpy
from rclpy.context import Context
from rclpy.event_handler import PublisherEventCallbacks, SubscriptionEventCallbacks
from rclpy.executors import SingleThreadedExecutor
from rclpy.node import Node
from std_msgs.msg import String

rows=[]
for default in (True,False):
    context=Context();rclpy.init(context=context,domain_id=164)
    node=Node('qos_cost_fixture',context=context)
    executor=SingleThreadedExecutor(context=context)
    publishers=[];subscriptions=[];received=[[] for _ in range(8)]
    try:
        for i in range(8):
            publishers.append(node.create_publisher(String,'/qos_cost/ch'+str(i),100,
                event_callbacks=PublisherEventCallbacks(use_default_callbacks=default)))
            subscriptions.append(node.create_subscription(String,'/qos_cost/ch'+str(i),
                lambda msg,index=i:received[index].append(int(msg.data)),100,
                event_callbacks=SubscriptionEventCallbacks(use_default_callbacks=default)))
        executor.add_node(node)
        startup=time.monotonic()+2.
        while not all(p.get_subscription_count()==1 for p in publishers):
            assert time.monotonic()<startup
            executor.spin_once(timeout_sec=.01)
        sent=[0]
        def publish():
            sent[0]+=1
            for p in publishers:p.publish(String(data=str(sent[0])))
        timer=node.create_timer(.02,publish)
        cpu=time.process_time_ns();start=time.monotonic_ns();end=start+4_000_000_000
        while time.monotonic_ns()<end:executor.spin_once(timeout_sec=.05)
        elapsed=time.monotonic_ns()-start;cpu=time.process_time_ns()-cpu
        timer.cancel()
        for _ in range(32):executor.spin_once(timeout_sec=.001)
        assert all(values==list(range(1,sent[0]+1)) for values in received),(sent[0],list(map(len,received)))
        rows.append(dict(use_default_callbacks=default,waitables=len(tuple(node.waitables)),
            messages=sum(map(len,received)),wall_ns=elapsed,process_cpu_ns=cpu,
            cpu_ns_per_message=cpu/sum(map(len,received))))
    finally:
        executor.shutdown();node.destroy_node();rclpy.shutdown(context=context)
value=dict(scope='8topic50Hz_REAL_DDS_local_loop_NOT_actual_stack_or_acceptance',rows=rows)
with Path(sys.argv[1]).open('x') as output:json.dump(value,output,indent=2)
print(json.dumps(value,indent=2))
