"""One bounded read-only capture of this invocation's UID/PGID/start-tick tree."""
import hashlib
import json
import os
from pathlib import Path
import sys
import time

directory = Path(sys.argv[1])
identity = None
discovery_deadline = time.monotonic()+45.
while time.monotonic() < discovery_deadline:
    try:
        identity = json.loads((directory/'result.json').read_text()).get('launch_identity')
    except (OSError, ValueError):
        pass
    if identity is not None:
        break
    time.sleep(.2)
if identity is None:
    raise SystemExit('No owned launch identity was published in the discovery budget')
pgid = identity['pgid']
names = {'libnavigation_gazebo_observer.so', 'libnavigation_gazebo_observation.so',
         'libnavigation_position_system.so'}
deadline = time.monotonic()+40.
while time.monotonic() < deadline:
    root = Path('/proc')/str(identity['pid'])
    if not root.exists():
        raise SystemExit('Owned launch exited before the diagnostic; no attribution inferred')
    fields = (root/'stat').read_text().rsplit(')', 1)[1].split()
    if root.stat().st_uid != os.getuid() or int(fields[19]) != identity['start_ticks']:
        raise SystemExit('Launch identity changed')
    members = []
    libraries = set()
    for path in Path('/proc').glob('[0-9]*'):
        try:
            if path.stat().st_uid != os.getuid():
                continue
            state = (path/'stat').read_text().rsplit(')', 1)[1].split()
            if int(state[2]) != pgid:
                continue
            command = (path/'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace')
            mapped = []
            for line in (path/'maps').read_text().splitlines():
                fields = line.split(maxsplit=5)
                if len(fields) != 6 or Path(fields[5]).name not in names:
                    continue
                lib = Path(fields[5])
                entry = dict(path=str(lib), sha256=hashlib.sha256(lib.read_bytes()).hexdigest())
                if entry not in mapped:
                    mapped.append(entry)
                libraries.add(lib.name)
            members.append(dict(pid=int(path.name), ppid=int(state[1]), pgid=int(state[2]),
                start_ticks=int(state[19]), command=command, mapped_libraries=mapped))
            if mapped:
                fields = (path/'environ').read_bytes().split(b'\0')
                selected_keys = {b'LP_NUM_THREADS', b'OMP_NUM_THREADS', b'OPENBLAS_NUM_THREADS',
                                 b'MUJOCO_GL', b'ROS_DOMAIN_ID'}
                members[-1]['selected_environment'] = {
                    key.decode(): value.decode(errors='replace') for field in fields if b'=' in field
                    for key, value in [field.split(b'=', 1)] if key in selected_keys}
        except (OSError, ValueError):
            continue
    if libraries == names:
        report = dict(scope='read_only_owned_process_attribution_not_exit_or_G1_proof',
            capture_wall_ns=time.monotonic_ns(), launch_identity=identity, members=members)
        with (directory/'native-owned-tree.json').open('x') as stream:
            json.dump(report, stream, indent=2)
        print(json.dumps([row for row in members if row['mapped_libraries']], indent=2))
        break
    time.sleep(.2)
else:
    raise SystemExit('Required mapped libraries not confirmed in the bounded capture')
