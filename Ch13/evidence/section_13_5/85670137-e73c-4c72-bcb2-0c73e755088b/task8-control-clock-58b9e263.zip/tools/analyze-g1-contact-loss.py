"""Preserved native pre-physics P-law and post-step contact window, never a PASS."""
import hashlib
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

root = Path(sys.argv[1])
raw = (root/'native_controls.json').read_bytes()
controls = json.loads(raw)
report = json.loads((root/'controller_report.json').read_text())
fault = report['first_fault']
assert fault and fault['reason'] == 'current measured support lost'
t = fault['ros_ns']
model = ET.fromstring((root.with_name(root.name+'-prepared')/'scene/robot.urdf').read_text())
kp = {j.get('name'):float(j.find("param[@name='ch13_kp']").text)
      for j in model.findall('ros2_control/joint')}
assert not controls['diagnostic_errors']
rows = [r for r in controls['records'] if t-600_000_000<=r['capture_ns']<=t+100_000_000]
references, maximum = [], (0.,None)
previous = None
for r in rows:
    assert r['sample_phase']=='pre_physics' and r['state_capture_ns']==r['capture_ns']-r['step_ns']
    joints = {j['name']:j for j in r['joints'] if j['name'].startswith(('fr_','fl_','rr_','rl_'))}
    # Only valid for the audited unsaturated Ch13 external P force law. This is
    # an inferred sampled reference, NOT a controller callback/receipt trace.
    assert all(j['force_command'] is not None and abs(j['force_command'])<j['effort_limit']
               for j in joints.values())
    target = {n:j['position']+j['force_command']/kp[n] for n,j in joints.items()}
    if previous:
        dt = (r['capture_ns']-previous['capture_ns'])/1e9
        speed = max(abs(target[n]-previous['target'][n])/dt for n in target)
        maximum = max(maximum,(speed,r['capture_ns']),key=lambda v:v[0])
    references.append(dict(capture_ns=r['capture_ns'],state_capture_ns=r['state_capture_ns'],
        target=target,velocity={n:j['velocity'] for n,j in joints.items()},
        force={n:j['force_command'] for n,j in joints.items()}))
    previous = references[-1]
frames = json.loads((root/'all_frames.json').read_text())['frames']
unique = {}
for r in frames:
    c = r['samples']['contacts']
    if t-600_000_000<=c['stamp_ns']<=t+100_000_000:
        unique.setdefault(c['stamp_ns'],c)
contacts = [dict(capture_ns=c['stamp_ns'],forces=c['data']['forces'],points=c['data']['points'])
            for _,c in sorted(unique.items())]
value = dict(scope='postmortem_unsaturated_P_law_not_actual_callback_trace_or_acceptance',
    native_controls_sha256=hashlib.sha256(raw).hexdigest(),fault_ros_ns=t,
    contact_zero_capture_ns=[c['capture_ns'] for c in contacts if sum(v>=2 for v in c['forces'])<3],
    maximum_sampled_inferred_target_velocity_rad_s=maximum,
    inferred_references=references,contacts=contacts,
    caveat='50Hz pre-physics commands and post-step normalized contacts cannot establish 2ms contact-gap duration or raw pair presence.')
with (root/'contact-loss-postmortem.json').open('x') as handle:
    json.dump(value,handle,indent=2,allow_nan=False)
print(json.dumps({k:v for k,v in value.items() if k not in ('inferred_references','contacts')},indent=2))
print(json.dumps(dict(contact_window=[c for c in contacts if abs(c['capture_ns']-t)<=50_000_000],
    nearest_reference=min(references,key=lambda r:abs(r['capture_ns']-t))),indent=2))
