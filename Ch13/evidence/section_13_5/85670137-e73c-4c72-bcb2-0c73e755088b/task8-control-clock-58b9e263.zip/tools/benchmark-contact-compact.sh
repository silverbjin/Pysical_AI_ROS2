#!/usr/bin/env bash
set -e
cd /mnt/c/Users/Jinho/.codex/.chatgpt-projects/g-p-6ad1e56cf8f881919fe23e1ab94d2855/work/Pysical_AI_ROS2
source .superpowers/sdd/SECTION_13_5_IMPLEMENTATION_PLAN_KO/env-native.sh
task_dir=.superpowers/sdd/SECTION_13_5_IMPLEMENTATION_PLAN_KO
test ! -e "$CH13_NAV_EVIDENCE/task8-calibration-observer-compact-cost.json"
g++ -O2 -std=c++17 "$task_dir/benchmark-contact-compact.cpp" -ICh13/ros2_ws/src/integrated_robot_navigation_sensors/include $(pkg-config --cflags --libs gz-sim8) -L"$CH13_NAV_INSTALL/integrated_robot_navigation_sensors/lib" -lnavigation_gazebo_observation -o "$task_dir/benchmark-contact-compact" > "$CH13_NAV_EVIDENCE/task8-calibration-observer-compact-cost-build.log" 2>&1
"$task_dir/benchmark-contact-compact" > "$CH13_NAV_EVIDENCE/task8-calibration-observer-compact-cost.json"
sha256sum "$task_dir/benchmark-contact-compact" "$CH13_NAV_INSTALL/integrated_robot_navigation_sensors/lib/libnavigation_gazebo_observation.so" > "$CH13_NAV_EVIDENCE/task8-calibration-observer-compact-cost.sha256"
cat "$CH13_NAV_EVIDENCE/task8-calibration-observer-compact-cost.json"
