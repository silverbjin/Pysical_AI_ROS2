"""Fixed endpoint + actual asynchronous captures, NOT an owner replay/lease."""
import json
from pathlib import Path
import sys
import numpy as np
from integrated_robot_navigation.model import compile_model
from integrated_robot_navigation.leg_kinematics import ik_leg
root=Path(sys.argv[1]);report=json.loads((root/'controller_report.json').read_text())
f=report['first_fault'];c=f['calibration'];stage=next(s for s in c['stages'] if s['phase']=='STAND' and s['ros_ns']>c['request']['ros_ns'])
model=compile_model((root.with_name(root.name+'-prepared')/'scene/robot.urdf').read_text())
inverse=np.linalg.inv(np.asarray(f['reference_body']));target={}
for foot,p in f['targets'].items():
    names=[foot[:2]+'_'+part+'_joint' for part in ('hip','thigh','calf')]
    local=inverse@np.array((*p,1.))
    q=ik_leg(model,foot,tuple(local[:3]),tuple(f['samples']['joints']['data']['position'][n] for n in names))
    target.update(zip(names,q))
rows=[]
for frame in json.loads((root/'all_frames.json').read_text())['frames']:
    if frame['stage']!='calibrate' or not stage['ros_ns']<=frame['ros_ns']<=f['ros_ns']:continue
    samples=frame['samples'];j=samples['joints']['data'];body=samples['body']['data']
    errors={n:abs(j['position'][n]-v) for n,v in target.items()}
    speed={n:abs(j['velocity'][n]) for n in target}
    tests=dict(error=max(errors.values())<=.03,speed=max(speed.values())<=.02,
        contacts=all(samples['contacts']['data']['touching']),
        body_v=bool(np.hypot(*body['linear_velocity'][:2])<=.003),body_w=abs(body['angular_velocity'][2])<=.01)
    rows.append(dict(ros_ns=frame['ros_ns'],wall_ns=frame['wall_ns'],
        joints_capture_ns=samples['joints']['stamp_ns'],tests=tests,
        worst_error_joint=max(errors,key=errors.get),worst_error_rad=max(errors.values()),
        worst_speed_joint=max(speed,key=speed.get),worst_speed_rps=max(speed.values())))
assert rows
value=dict(scope='fixed_endpoint_vs_asynchronous_probe_NOT_exact_owner_settle',
    stages=c['stages'],candidate_remaining_wall_ns=c['request']['deadline_wall_ns']-stage['wall_ns'],
    fault=f['reason'],target=target,first=rows[0],last=rows[-1],
    failed_counts={k:sum(not r['tests'][k] for r in rows) for k in rows[0]['tests']},
    rows=rows)
payload=json.dumps(value,indent=2)
with (root/'stand-readiness-postmortem-v2.json').open('x') as output:output.write(payload)
print(json.dumps({k:v for k,v in value.items() if k not in ('rows','target')},indent=2))
