#!/usr/bin/env bash
set -eo pipefail
cd /mnt/c/Users/Jinho/.codex/.chatgpt-projects/g-p-6ad1e56cf8f881919fe23e1ab94d2855/work/Pysical_AI_ROS2
source .superpowers/sdd/SECTION_13_5_IMPLEMENTATION_PLAN_KO/env-native.sh
label=$1
test ! -e "$CH13_NAV_EVIDENCE/$label.log"
set +e
{
  g++ -std=c++17 -Wall -Wextra -Wpedantic -ICh13/ros2_ws/src/integrated_robot_navigation_sensors/include Ch13/ros2_ws/src/integrated_robot_navigation_sensors/test/test_control_clock_gate.cpp -lgtest_main -lgtest -pthread -o "$CH13_NAV_NATIVE_ROOT/$label"
  built=$?
  if test "$built" = 0; then "$CH13_NAV_NATIVE_ROOT/$label"; else exit "$built"; fi
} > "$CH13_NAV_EVIDENCE/$label.log" 2>&1
result=$?
tail -n 35 "$CH13_NAV_EVIDENCE/$label.log"
exit "$result"
