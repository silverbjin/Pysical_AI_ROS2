"""Separate static and SHIFT raw-contact gaps; not a causal/acceptance verdict."""
import hashlib
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

root=Path(sys.argv[1])
raw=(root/'native_controls.json').read_bytes()
data=json.loads(raw)
assert not data['diagnostic_errors']
urdf=ET.fromstring((root.with_name(root.name+'-prepared')/'scene/robot.urdf').read_text())
kp={j.get('name'):float(j.find("param[@name='ch13_kp']").text)
    for j in urdf.findall('ros2_control/joint')}
carry=json.loads((root/'carry_failure_report.json').read_text())['first_fault']
t=carry['selected_joint_sample']['stamp_ns']
phases={}
window=[]
steps=[]
previous=None
reference_diagnostics=[]
for packet in data['records']:
    phase=packet['stage']
    summary=phases.setdefault(phase,dict(packets=0,references=0,any_missing_pair=0,
        fewer_than_three_raw_loaded=0,missing_pair_by_foot={},maximum_arm_velocity_rad_s=0.))
    summary['packets']+=1
    summary['maximum_arm_velocity_rad_s']=max(summary['maximum_arm_velocity_rad_s'],
        max(abs(j['velocity']) for j in packet['joints'] if j['name'].startswith('arm_')))
    leg=[j for j in packet['joints'] if j['name'] in kp and j['name'].startswith(('fr_','fl_','rr_','rl_'))]
    for joint in leg:
        if 'position_reference' in joint:
            reference=joint['position_reference']
            expected=max(-joint['effort_limit'],min(joint['effort_limit'],
                kp[joint['name']]*(reference['applied']-joint['position'])))
            reference_diagnostics.append(dict(capture_ns=packet['capture_ns'],name=joint['name'],
                input_applied_difference_rad=abs(reference['source_input']-reference['applied']),
                force_law_error_nm=abs(expected-joint['force_command']),
                write_age_ns=packet['capture_ns']-reference['write_capture_ns']))
    if len(leg)==12 and all(j['force_command'] is not None and abs(j['force_command'])<j['effort_limit'] for j in leg):
        target={j['name']:j['position']+j['force_command']/kp[j['name']] for j in leg}
        if previous and previous['stage']==phase:
            delta=max(abs(target[n]-previous['target'][n]) for n in target)
            if abs(packet['capture_ns']-t)<600_000_000:
                steps.append(dict(capture_ns=packet['capture_ns'],delta_rad=delta,
                    elapsed_capture_ns=packet['capture_ns']-previous['capture_ns']))
        previous=dict(target=target,stage=phase,capture_ns=packet['capture_ns'])
    else:previous=None
    for reference in packet['body_references']:
        contact=reference['raw_contacts']
        summary['references']+=1
        missing=[f['name'] for f in contact['feet'] if f['pair_count']==0]
        summary['any_missing_pair']+=bool(missing)
        summary['fewer_than_three_raw_loaded']+=sum(f['sum_abs_force1_world_z_n']>=2 for f in contact['feet'])<3
        for name in missing:
            summary['missing_pair_by_foot'][name]=summary['missing_pair_by_foot'].get(name,0)+1
        if missing and abs(contact['capture_ns']-t)<100_000_000:
            window.append(dict(capture_ns=contact['capture_ns'],missing=missing,
                centers_z_m={f['name']:f['center_world'][2] for f in contact['feet']},
                forces_n={f['name']:f['sum_abs_force1_world_z_n'] for f in contact['feet']}))
value=dict(scope='read_only_phase_comparison_not_callback_trace_or_contact_truth_override',
    native_controls_sha256=hashlib.sha256(raw).hexdigest(),selected_carry_joint_capture_ns=t,
    phases=phases,missing_pairs_near_selected_joint=window,
    native_reference_diagnostics=dict(records=len(reference_diagnostics),
        max_input_applied_difference_rad=max((r['input_applied_difference_rad'] for r in reference_diagnostics),default=None),
        max_native_force_law_error_nm=max((r['force_law_error_nm'] for r in reference_diagnostics),default=None),
        max_write_age_ns=max((r['write_age_ns'] for r in reference_diagnostics),default=None)),
    largest_sampled_inferred_target_steps=sorted(steps,key=lambda r:r['delta_rad'],reverse=True)[:8],
    caveats=['P-law inversion only for unsaturated sampled records; no intervening command callback timing.',
        'Raw pair absence does not establish geometric airborne or solver fault.',
        'A phase with no recorded gap is not a repeatability guarantee or proof of absent unrecorded packets.'])
with (root/'phase-contact-postmortem.json').open('x') as output:json.dump(value,output,indent=2,allow_nan=False)
print(json.dumps(value,indent=2))
