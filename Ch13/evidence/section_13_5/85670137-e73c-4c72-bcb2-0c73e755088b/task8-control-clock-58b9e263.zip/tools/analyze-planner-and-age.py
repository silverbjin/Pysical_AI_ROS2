"""Four arithmetic predictions cost and original failed ages; no owner replay."""
import hashlib
import json
from pathlib import Path
import sys
import time
import numpy as np
from integrated_robot_navigation.carry_profile import default_limits
from integrated_robot_navigation.gait import CrawlMachine
from integrated_robot_navigation.model import compile_model
from integrated_robot_navigation.samples import Sample, SensorBundle, sample_valid
root=Path(sys.argv[1]);raw=(root/'all_frames.json').read_bytes()
row=next(r for r in json.loads(raw)['frames'] if r['stage']=='stand')
model=compile_model((root.with_name(root.name+'-prepared')/'scene/robot.urdf').read_text())
bundle=SensorBundle(**{key:Sample(**row['samples'][key]) for key in SensorBundle.__dataclass_fields__})
cost=[]
for _ in range(50):
    value=CrawlMachine(model,default_limits());value.reset(bundle,row['ros_ns'],row['wall_ns'])
    value.request_contact_calibration()
    q,_,_,loads,points,com=value._measure(bundle,row['ros_ns'],row['wall_ns'])
    value._begin_shift(com,loads,points,row['ros_ns'],q)
    start=time.monotonic_ns()
    for _ in range(4):next(value._shift_plan)
    cost.append(time.monotonic_ns()-start)
bad=[];counts={}
for row in json.loads((root/'frames.json').read_text())['frames']:
    for key in ('joints','imu','contacts','body','scan','native_com'):
        s=Sample(**row['samples'][key])
        ok,reason=sample_valid(s,row['ros_ns'],row['wall_ns'],0,
            max_age_ns=300_000_000 if key=='scan' else 200_000_000)
        if not ok:
            counts[key+':'+reason]=counts.get(key+':'+reason,0)+1
            bad.append(dict(sensor=key,reason=reason,ros_ns=row['ros_ns'],wall_ns=row['wall_ns'],
                capture_ns=s.stamp_ns,received_ns=s.received_ns,ros_age_ns=row['ros_ns']-s.stamp_ns,
                wall_age_ns=row['wall_ns']-s.received_ns))
result=dict(scope='offline_bounded_arithmetic_cost_and_original_recorded_ages_NOT_native_PASS',
    input_sha256=hashlib.sha256(raw).hexdigest(),four_prediction_wall_ns=dict(
        samples=len(cost),minimum=min(cost),p95=float(np.percentile(cost,95)),maximum=max(cost)),
    original_failed_age_counts=counts,original_failed_age_samples=bad[:12])
with (root/'planner-and-age-postmortem.json').open('x') as output:json.dump(result,output,indent=2)
print(json.dumps(result,indent=2))
