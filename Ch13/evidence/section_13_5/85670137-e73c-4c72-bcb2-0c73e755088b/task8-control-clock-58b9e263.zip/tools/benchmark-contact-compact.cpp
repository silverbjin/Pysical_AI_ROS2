// Read-only ECM fixture characterization. Not a real engine/G1 verdict.
#include "integrated_robot_navigation_sensors/gazebo_observation.hpp"
#include <gz/sim/components/Collision.hh>
#include <gz/sim/components/ContactSensorData.hh>
#include <gz/sim/components/Model.hh>
#include <gz/sim/components/Link.hh>
#include <gz/sim/components/CanonicalLink.hh>
#include <gz/sim/components/ParentEntity.hh>
#include <gz/sim/components/Name.hh>
#include <gz/sim/components/Pose.hh>
#include <gz/sim/components/AngularVelocity.hh>
#include <nlohmann/json.hpp>
#include <chrono>
#include <iostream>
namespace sim=gz::sim;
namespace comp=sim::components;
namespace nav=integrated_robot_navigation_sensors;
int main()
{
  sim::EntityComponentManager ecm;
  auto robot=ecm.CreateEntity(); ecm.CreateComponent(robot,comp::Model());
  auto base=ecm.CreateEntity(); ecm.SetParentEntity(base,robot);
  ecm.CreateComponent(base,comp::ParentEntity(robot));
  ecm.CreateComponent(base,comp::Link()); ecm.CreateComponent(base,comp::CanonicalLink());
  ecm.CreateComponent(base,comp::Name("base_footprint"));
  ecm.CreateComponent(base,comp::WorldPose(gz::math::Pose3d(0,0,.46,0,0,0)));
  ecm.CreateComponent(base,comp::WorldAngularVelocity(gz::math::Vector3d(0,0,0)));
  for (const std::string name : {"fr_foot","fl_foot","rr_foot","rl_foot"}) {
    auto foot=ecm.CreateEntity(); ecm.SetParentEntity(foot,base);
    ecm.CreateComponent(foot,comp::ParentEntity(base));
    ecm.CreateComponent(foot,comp::Collision());
    ecm.CreateComponent(foot,comp::Name("navcol__"+name+"__0"));
    ecm.CreateComponent(foot,comp::Pose(gz::math::Pose3d(.25,.18,-.44,0,0,0)));
    gz::msgs::Contacts data;
    auto * pair=data.add_contact();
    pair->mutable_collision1()->set_id(foot); pair->mutable_collision2()->set_id(999);
    pair->add_position()->set_z(0.); pair->add_depth(.00001);
    auto * w=pair->add_wrench();
    w->mutable_body_1_wrench()->mutable_force()->set_z(35.);
    w->mutable_body_2_wrench()->mutable_force()->set_z(-35.);
    ecm.CreateComponent(foot,comp::ContactSensorData(data));
  }
  nlohmann::json output{{"scope","CPU_fixture_not_actual_engine_or_G1"},{"iterations",10000}};
  for (bool detailed : {false,true}) {
    size_t bytes=0;
    const auto start=std::chrono::steady_clock::now();
    for (int i=0;i<10000;++i) {
      auto body=nlohmann::json::parse(nav::read_gazebo_body_reference(robot,ecm,std::chrono::milliseconds(2*i),i)->data());
      if (detailed) body["raw_contacts"]=nlohmann::json::parse(nav::read_gazebo_contact_reference(robot,ecm,std::chrono::milliseconds(2*i),true)->data());
      bytes+=body.dump().size();
    }
    const auto ns=std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-start).count();
    output[detailed?"body_and_compact_contacts":"body_only"]={{"ns_per_step",ns/10000.},{"bytes_per_step",bytes/10000.}};
  }
  std::cout<<output.dump(2)<<'\n';
}
