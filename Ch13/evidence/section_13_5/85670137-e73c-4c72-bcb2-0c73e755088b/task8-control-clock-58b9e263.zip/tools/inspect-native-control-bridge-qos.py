"""Actual installed bridge graph characterization; no simulator/motor commands."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import uuid
import rclpy
from rclpy.context import Context
from rclpy.executors import SingleThreadedExecutor
from rclpy.node import Node

os.environ['ROS_DOMAIN_ID']='163'  # this helper/child only; normal domain159 stays unchanged
base=Path(os.environ['CH13_NAV_EVIDENCE'])
label=sys.argv[1]
assert label.replace('-','').isalnum()
destination=base/(label+'.json')
assert not destination.exists()
config=Path('Ch13/ros2_ws/src/integrated_robot_navigation/config/navigation_bridge.yaml').resolve()
prefix=Path(subprocess.check_output(['ros2','pkg','prefix','ros_gz_bridge'],text=True).strip())
exe=prefix/'lib/ros_gz_bridge/parameter_bridge'
assert exe.is_file()
name='ch13_bridge_qos_'+uuid.uuid4().hex[:8]
command=[str(exe),'--ros-args','-r','__node:='+name,'-p','config_file:='+str(config)]
record=dict(scope='actual_bridge_QoS_component_not_engine_or_G1_acceptance',command=command,
    domain_id=163,executable_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),
    config_sha256=hashlib.sha256(config.read_bytes()).hexdigest())
context=Context();rclpy.init(context=context)
node=Node('ch13_bridge_qos_reader',context=context)
executor=SingleThreadedExecutor(context=context)
executor.add_node(node)
process=None
try:
    with (base/(label+'.log')).open('x') as log:
        process=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        record['pid']=process.pid
        deadline=time.monotonic()+5.
        endpoints=[]
        while time.monotonic()<deadline and process.poll() is None:
            executor.spin_once(timeout_sec=.05)
            endpoints=[p for p in node.get_publishers_info_by_topic('/navigation/native_controls') if p.node_name==name]
            if endpoints:break
        record['publishers']=[dict(node=p.node_name,gid=bytes(p.endpoint_gid).hex(),
            reliability=p.qos_profile.reliability.name,durability=p.qos_profile.durability.name,
            history=p.qos_profile.history.name,discovered_depth=p.qos_profile.depth) for p in endpoints]
        record['one_owned_publisher']=len(endpoints)==1
finally:
    # Reap our direct child even when discovery/Context fails. Never force-kill.
    if process is not None:
        if process.poll() is None:process.send_signal(signal.SIGINT)
        try:record['returncode']=process.wait(timeout=10.)
        except subprocess.TimeoutExpired:record['cleanup_timeout']=True
    record['owned_exit_confirmed']=process is not None and process.poll() is not None
    executor.shutdown();node.destroy_node();context.try_shutdown()
    with destination.open('x') as output:json.dump(record,output,indent=2,allow_nan=False)
print(json.dumps(record,indent=2))
assert record['one_owned_publisher'] and record['returncode']==0
