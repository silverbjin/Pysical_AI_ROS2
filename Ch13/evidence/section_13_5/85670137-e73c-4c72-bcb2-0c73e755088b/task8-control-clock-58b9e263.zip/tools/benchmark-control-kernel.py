"""Read-only recorded STAND kernel cost; NOT a live owner or native PASS."""
import cProfile
import hashlib
import io
import json
import os
from pathlib import Path
import pstats
import sys
import time
import numpy as np
from integrated_robot_navigation.carry_profile import default_limits
from integrated_robot_navigation.gait import CrawlMachine
from integrated_robot_navigation.model import compile_model
from integrated_robot_navigation.samples import Sample, SensorBundle

root=Path(sys.argv[1]); output=Path(sys.argv[2])
rows=json.loads((root/'all_frames.json').read_text())['frames']
row=next(r for r in rows if r['stage']=='stand')
model=compile_model((root.with_name(root.name+'-prepared')/'scene/robot.urdf').read_text())
bundle=SensorBundle(**{key:Sample(**row['samples'][key]) for key in SensorBundle.__dataclass_fields__})
machine=CrawlMachine(model,default_limits())
machine.reset(bundle,row['ros_ns'],row['wall_ns'])
def kernel():
    measured=machine._measure(bundle,row['ros_ns'],row['wall_ns'])
    targets=machine._solve(measured[0],True)
    return dict(com=list(measured[-1]),targets=targets)
expected=kernel()
profiler=cProfile.Profile(); wall=time.monotonic_ns(); cpu=time.process_time_ns()
profiler.enable()
for _ in range(500):
    result=kernel()
    assert result==expected
profiler.disable()
cpu=time.process_time_ns()-cpu;wall=time.monotonic_ns()-wall
stream=io.StringIO();pstats.Stats(profiler,stream=stream).sort_stats('cumulative').print_stats(18)
value=dict(scope='recorded_stand_numerical_kernel_not_ros_dispatch_or_physical_acceptance',
    input_sha256=hashlib.sha256((root/'all_frames.json').read_bytes()).hexdigest(),
    numpy_version=np.__version__,openblas_env=os.environ.get('OPENBLAS_NUM_THREADS'),
    omp_env=os.environ.get('OMP_NUM_THREADS'),threads=len(list(Path('/proc/self/task').iterdir())),
    blas_maps=sorted({line.split()[-1] for line in Path('/proc/self/maps').read_text().splitlines() if 'blas' in line}),
    iterations=500,wall_ns=wall,cpu_ns=cpu,ns_per_iteration=wall/500,output=expected,profile=stream.getvalue())
with output.open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
print(json.dumps({k:v for k,v in value.items() if k not in ('output','profile')},indent=2))
print(stream.getvalue())
