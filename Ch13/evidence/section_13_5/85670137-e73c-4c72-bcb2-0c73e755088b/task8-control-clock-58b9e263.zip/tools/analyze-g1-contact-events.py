"""Post-step raw wrench/state witnesses; keep command phase/capture explicit."""
import hashlib
import json
import math
from pathlib import Path
import sys

root=Path(sys.argv[1]);raw=(root/'native_controls.json').read_bytes();data=json.loads(raw)
assert not data['diagnostic_errors']
rows=[]
for packet in data['records']:
    if packet['stage']!='calibrate':continue
    for reference in packet['body_references']:
        if not reference.get('contact_event_window'):continue
        contact=reference['raw_contacts'];joints=reference['contact_event_joints']
        assert contact['details_included'] and joints['sample_phase']=='post_physics_debug'
        assert joints['state_capture_ns']==reference['capture_ns']==contact['capture_ns']
        feet=[]
        for foot in contact['feet']:
            forces=[];unknown=[]
            for pair in foot['pairs']:
                if pair['collision1_id']==foot['entity']:forces.extend(pair['force1_world'])
                elif pair['collision2_id']==foot['entity']:forces.extend(pair['force2_world'])
                else:unknown.append(pair)
            feet.append(dict(name=foot['name'],entity=foot['entity'],center_world=foot['center_world'],
                pair_count=foot['pair_count'],pairs=foot['pairs'],unattributed_pairs=unknown,
                raw_foot_force_sum_world=[sum(v[i] for v in forces) for i in range(3)] if not unknown else None))
        rows.append(dict(capture_ns=reference['capture_ns'],feet=feet,joints=joints['joints'],
            angular_velocity=reference['angular_velocity']))
assert rows,'no native contact-event witness; do not infer a callback or physical event'
assert len({r['capture_ns'] for r in rows})==len(rows)
carry_path=root/'carry_failure_report.json'
carry=json.loads(carry_path.read_text())['first_fault'] if carry_path.exists() else None
closest=None
if carry:
    selected=carry['selected_joint_sample']
    def difference(row):
        return max(abs(j['velocity']-selected['data']['velocity'][j['name']]) for j in row['joints'])
    matched=min(rows,key=difference)
    closest=dict(post_capture_ns=matched['capture_ns'],reported_joint_header_ns=selected['stamp_ns'],
        max_velocity_component_difference_rad_s=difference(matched),
        arm4_velocity=next(j['velocity'] for j in matched['joints'] if j['name']=='arm_joint_4'),
        feet=[dict(name=f['name'],pair_count=f['pair_count'],raw_foot_force_sum_world=f['raw_foot_force_sum_world'],
            depths=[d for p in f['pairs'] for d in p['depths']]) for f in matched['feet']])
value=dict(scope='native_event_postmortem_not_contact_acceptance_or_causal_proof',
    native_controls_sha256=hashlib.sha256(raw).hexdigest(),event_post_steps=len(rows),
    selected_joint_match=closest,rows=rows,
    caveats=['Raw force sums have no pair deduplication and do not replace FootContacts.',
        'Post-step q/qd and wrenches are distinct from pre-step commanded forces; null stays null.',
        'Reference write_capture_ns is retained; reported JointState header is never rewritten.'])
with (root/'contact-event-postmortem.json').open('x') as output:json.dump(value,output,indent=2,allow_nan=False)
print(json.dumps({k:v for k,v in value.items() if k!='rows'},indent=2))
