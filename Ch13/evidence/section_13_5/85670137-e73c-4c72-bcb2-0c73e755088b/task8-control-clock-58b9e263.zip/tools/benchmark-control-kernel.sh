#!/usr/bin/env bash
set -e
cd /mnt/c/Users/Jinho/.codex/.chatgpt-projects/g-p-6ad1e56cf8f881919fe23e1ab94d2855/work/Pysical_AI_ROS2
source .superpowers/sdd/SECTION_13_5_IMPLEMENTATION_PLAN_KO/env-native.sh
task_dir=.superpowers/sdd/SECTION_13_5_IMPLEMENTATION_PLAN_KO
input="$CH13_NAV_EVIDENCE/native-g1-gazebo-bd8ad3ae-4d3b-4ce5-950b-da61eebd4df2"
python "$task_dir/benchmark-control-kernel.py" "$input" "$CH13_NAV_EVIDENCE/task8-calibration-kernel-default.json"
OPENBLAS_NUM_THREADS=1 python "$task_dir/benchmark-control-kernel.py" "$input" "$CH13_NAV_EVIDENCE/task8-calibration-kernel-blas1.json"
