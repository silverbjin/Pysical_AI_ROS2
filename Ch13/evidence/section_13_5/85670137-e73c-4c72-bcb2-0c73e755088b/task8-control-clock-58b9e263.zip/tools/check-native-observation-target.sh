#!/usr/bin/env bash
set -e
cd /mnt/c/Users/Jinho/.codex/.chatgpt-projects/g-p-6ad1e56cf8f881919fe23e1ab94d2855/work/Pysical_AI_ROS2
source .superpowers/sdd/SECTION_13_5_IMPLEMENTATION_PLAN_KO/env-native.sh
label=$1
test ! -e "$CH13_NAV_EVIDENCE/$label.log"
set +e
# Focused target only, NOT an installation audit or native engine verdict.
cmake --build "$CH13_NAV_BUILD/integrated_robot_navigation_sensors" --target test_gazebo_observation --parallel 2 > "$CH13_NAV_EVIDENCE/$label.log" 2>&1
result=$?
if test "$result" = 0; then
  export LD_LIBRARY_PATH="$CH13_NAV_BUILD/integrated_robot_navigation_sensors:${LD_LIBRARY_PATH:-}"
  "$CH13_NAV_BUILD/integrated_robot_navigation_sensors/test_gazebo_observation" >> "$CH13_NAV_EVIDENCE/$label.log" 2>&1
  result=$?
fi
tail -n 23 "$CH13_NAV_EVIDENCE/$label.log"
exit "$result"
