"""Read-only postmortem. Producer cadence and independent state-stamp lineage.
Neither this report nor CPU improvement is a physical acceptance verdict.
"""
import hashlib
import json
from pathlib import Path
import sys

root = Path(sys.argv[1]).resolve()
trace = root/'control_clock.jsonl'
rows = [json.loads(line) for line in trace.read_text().splitlines()]
published = [row for row in rows if row['event'] == 'publish']
by_stamp = {row['capture_ns']: row for row in published}
deltas = [b['published_wall_ns']-a['published_wall_ns'] for a,b in zip(published,published[1:])]
def stats(values):
    if not values:
        return dict(count=0)
    ordered = sorted(values)
    return dict(count=len(values), minimum=ordered[0], maximum=ordered[-1],
                p50=ordered[(len(values)-1)//2], p95=ordered[int((len(values)-1)*.95)])

raw = root/'observations.jsonl'
if not raw.is_file():
    raise RuntimeError('actual probe observations.jsonl missing; no producer-only substitution')
states = {}
for line in raw.open():
    packet = json.loads(line)
    kind = packet['kind']
    if kind not in ('guard_state','crawl_state','carry_state','startup_state'):
        continue
    row = packet['value']
    state = states.setdefault(kind, dict(total=0, zero_bootstrap=0, positive=0, missing=0, delays=[]))
    state['total'] += 1
    if row['stamp_ns'] == 0:
        state['zero_bootstrap'] += 1
        continue
    state['positive'] += 1
    source = by_stamp.get(row['stamp_ns'])
    if source is None:
        state['missing'] += 1
    else:
        state['delays'].append(row['received_ns']-source['published_wall_ns'])
for value in states.values():
    value['publish_to_state_receipt_ns'] = stats(value.pop('delays'))
report = dict(scope='postmortem_not_task_success', trace_sha256=hashlib.sha256(trace.read_bytes()).hexdigest(),
    raw_sha256=hashlib.sha256(raw.read_bytes()).hexdigest(), publications=len(published),
    unique_captures=len(by_stamp), wall_publication_interval_ns=stats(deltas),
    average_wall_hz=(len(published)-1)*1e9/sum(deltas) if deltas and sum(deltas) else None,
    source_receipt_to_publish_ns=stats([row['published_wall_ns']-row['received_wall_ns'] for row in published]),
    last_event=rows[-1], actual_received_state_lineage=states,
    caveats=['State receipt latency includes middleware/node/probe scheduling, not only relay delay.',
             'nav_projection has no MotionState publisher; its clock route is graph-audited.',
             'Producer trace is not an independent observation of every clock wire message.',
             'No bootstrap-zero or missing-positive value is counted as lineage success.'])
with (root/'control-clock-postmortem.json').open('x') as handle:
    json.dump(report, handle, indent=2, allow_nan=False)
print(json.dumps(report, indent=2))
