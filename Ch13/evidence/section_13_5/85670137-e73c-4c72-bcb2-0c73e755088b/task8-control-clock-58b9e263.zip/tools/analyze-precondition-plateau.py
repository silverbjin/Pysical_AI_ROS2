"""Offline command FK + same-capture raw load, not actual foot/owner replay."""
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
from integrated_robot_navigation.model import compile_model
from integrated_robot_navigation.leg_kinematics import fk_leg

root=Path(sys.argv[1])
report=json.loads((root/'controller_report.json').read_text())
fault=report['first_fault']
context=fault['phase_context']
cal=fault['calibration']
native=json.loads((root/'native_controls.json').read_text())
model=compile_model((root.with_name(root.name+'-prepared')/'scene/robot.urdf').read_text())
body=np.asarray(fault['reference_body'])
rows=[]
for packet in native['records']:
    if packet['stage']!='calibrate': continue
    ns=packet['state_capture_ns']
    references=[r for r in packet['body_references'] if r['capture_ns']==ns]
    if len(references)!=1: continue
    joint_refs={j['name']:j['position_reference'] for j in packet['joints'] if 'position_reference' in j}
    q=tuple(joint_refs['fl_'+part+'_joint']['source_input'] for part in ('hip','thigh','calf'))
    point=body[:3,:3]@np.asarray(fk_leg(model,'fl_foot',q))+body[:3,3]
    measured_q={j['name']:j['position'] for j in packet['joints']}
    measured_point=body[:3,:3]@np.asarray(fk_leg(model,'fl_foot',tuple(measured_q['fl_'+part+'_joint']
                                for part in ('hip','thigh','calf'))))+body[:3,3]
    feet=references[0]['raw_contacts']['feet']
    forces={f['name']:f['sum_abs_force1_world_z_n'] for f in feet}
    rows.append(dict(capture_ns=ns,command_world_z_m=float(point[2]),forces_n=forces,
                     measured_reference_z_m=float(measured_point[2]),
                     tracking_compression_m=float(measured_point[2]-point[2]),
                     measured_fl_center_z_m=next(f['center_world'][2] for f in feet if f['name']=='fl_foot')))
before=[r for r in rows if r['capture_ns']<context['_unload_start']]
assert before
maximum=max(r['command_world_z_m'] for r in before)
plateau=[r for r in before if abs(r['command_world_z_m']-maximum)<1e-8]
value=dict(scope='offline_command_FK_with_fixed_reference_rotation_and_z_not_physical_height',
    input_sha256={f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in ('controller_report.json','native_controls.json')},
    phase_context=context,first=before[0],last=before[-1],plateau=dict(count=len(plateau),
        first=plateau[0],last=plateau[-1],duration_ros_s=(plateau[-1]['capture_ns']-plateau[0]['capture_ns'])/1e9,
        min_fl_force_n=min(r['forces_n']['fl_foot'] for r in plateau),
        min_any_force_n=min(min(r['forces_n'].values()) for r in plateau)),
    samples_every_10th=rows[::10],calibration=cal)
with (root/'precondition-compression-postmortem.json').open('x') as output:json.dump(value,output,indent=2)
print(json.dumps({k:v for k,v in value.items() if k not in ('samples_every_10th','calibration')},indent=2))
