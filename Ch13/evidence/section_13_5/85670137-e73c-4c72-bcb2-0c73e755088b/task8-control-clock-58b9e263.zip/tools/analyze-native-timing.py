"""Phase-local ROS/wall and owned process CPU from preserved measurements."""
import json
from pathlib import Path
import sys

directory = Path(sys.argv[1])
frames = json.loads((directory/'all_frames.json').read_text())['frames']
metrics = [json.loads(line) for line in (directory/'process_metrics.jsonl').read_text().splitlines()]
hz = json.loads((directory/'result.json').read_text())['cpu_clock_ticks_per_s']
report = {}
for stage in sorted({f['stage'] for f in frames}):
    selected = [f for f in frames if f['stage'] == stage]
    a, b = selected[0], selected[-1]
    wall = (b['wall_ns']-a['wall_ns'])/1e9
    ros = (b['ros_ns']-a['ros_ns'])/1e9
    processes = {}
    for sample in metrics:
        if not a['wall_ns'] <= sample['wall_ns'] <= b['wall_ns']:
            continue
        for row in sample['members']:
            key = (row['pid'], row['start_ticks'])
            processes.setdefault(key, []).append(dict(wall_ns=sample['wall_ns'], **row))
    cpu = []
    for (pid, start), values in processes.items():
        first, last = values[0], values[-1]
        seconds = (last['wall_ns']-first['wall_ns'])/1e9
        if seconds <= 0:
            continue
        ticks = last['user_ticks']+last['system_ticks']-first['user_ticks']-first['system_ticks']
        cpu.append(dict(pid=pid, start_ticks=start, executable=last['executable'],
            one_core_cpu_percent=100*ticks/hz/seconds,
            max_threads=max(r['threads'] for r in values), measured_s=seconds))
    report[stage] = dict(frames=len(selected), ros_s=ros, wall_s=wall,
        ros_to_wall=ros/wall if wall else None,
        cpu=sorted(cpu, key=lambda r: -r['one_core_cpu_percent']))
with (directory/'phase-timing-analysis.json').open('x') as stream:
    json.dump(report, stream, indent=2, allow_nan=False)
print(json.dumps({s: {**r, 'cpu': r['cpu'][:3]} for s, r in report.items()}, indent=2))
