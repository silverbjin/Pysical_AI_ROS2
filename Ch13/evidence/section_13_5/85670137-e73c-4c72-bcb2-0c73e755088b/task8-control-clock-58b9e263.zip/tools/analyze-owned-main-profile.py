"""Main-thread wall profile; never infer watchdog cost or whole CPU from it."""
import hashlib
import io
import json
from pathlib import Path
import pstats
import sys
root=Path(sys.argv[1]);source=root/'motion_guard.prof'
stream=io.StringIO();stats=pstats.Stats(str(source),stream=stream)
stats.sort_stats('tottime').print_stats(35)
rows=[]
for (file,line,name),(primitive,calls,own,cumulative,callers) in stats.stats.items():
    rows.append(dict(file=file,line=line,name=name,calls=calls,primitive_calls=primitive,
        own_wall_s=own,cumulative_wall_s=cumulative))
result=json.loads((root/'result.json').read_text())
assert result['execution_mode']['diagnostic_profile_node']=='motion_guard'
assert result['checks']['unprofiled_acceptance'] is False
value=dict(scope='owned_motion_guard_MAIN_thread_wall_profile_NOT_watchdog_or_CPU_time',
    profile_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
    launch_command=result['command'],total_calls=stats.total_calls,total_profile_wall_s=stats.total_tt,
    top_own=sorted(rows,key=lambda r:-r['own_wall_s'])[:40],
    top_cumulative=sorted(rows,key=lambda r:-r['cumulative_wall_s'])[:40])
with (root/'main-profile-analysis.json').open('x') as f:json.dump(value,f,indent=2)
print(stream.getvalue())
