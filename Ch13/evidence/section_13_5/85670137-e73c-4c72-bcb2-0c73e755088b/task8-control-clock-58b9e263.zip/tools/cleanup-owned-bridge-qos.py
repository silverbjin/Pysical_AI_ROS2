"""Cleanup ONLY the exact failed helper's UUID-named, hash-verified child."""
import hashlib,json,os
from pathlib import Path
import signal,time
base=Path(os.environ['CH13_NAV_EVIDENCE'])
record=json.loads((base/'task8-calibration-bridge-qos.json').read_text())
pid=record['pid']; proc=Path('/proc')/str(pid)
value=dict(scope='failed_diagnostic_child_cleanup_not_engine_or_normal_exit_PASS',pid=pid,
    signal='SIGINT',returncode=None,not_our_direct_child=True,forced_cleanup=False)
if proc.exists():
    actual=(proc/'exe').resolve(strict=True)
    assert actual==Path(record['command'][0]).resolve(strict=True)
    assert proc.stat().st_uid==os.getuid()==1000
    args=(proc/'cmdline').read_bytes().split(b'\0')[:-1]
    assert [a.decode() for a in args]==record['command']
    assert hashlib.sha256(actual.read_bytes()).hexdigest()==record['executable_sha256']
    value['verified_command']=record['command']
    os.kill(pid,signal.SIGINT)
    deadline=time.monotonic()+10.
    while proc.exists() and time.monotonic()<deadline:time.sleep(.05)
value['proc_absent']=not proc.exists()
with (base/'task8-calibration-bridge-qos-cleanup.json').open('x') as out:json.dump(value,out,indent=2)
print(json.dumps(value,indent=2))
assert value['proc_absent'],'Owned diagnostic cleanup unconfirmed; do not start another engine'
