#!/usr/bin/env bash
set -e
cd /mnt/c/Users/Jinho/.codex/.chatgpt-projects/g-p-6ad1e56cf8f881919fe23e1ab94d2855/work/Pysical_AI_ROS2
source .superpowers/sdd/SECTION_13_5_IMPLEMENTATION_PLAN_KO/env-native.sh
python .superpowers/sdd/SECTION_13_5_IMPLEMENTATION_PLAN_KO/analyze-calibration-budget.py "$CH13_NAV_EVIDENCE/$1"
