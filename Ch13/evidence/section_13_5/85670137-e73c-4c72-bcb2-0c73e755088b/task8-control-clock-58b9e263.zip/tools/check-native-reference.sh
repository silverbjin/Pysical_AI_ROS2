#!/usr/bin/env bash
set -e
cd /mnt/c/Users/Jinho/.codex/.chatgpt-projects/g-p-6ad1e56cf8f881919fe23e1ab94d2855/work/Pysical_AI_ROS2
source .superpowers/sdd/SECTION_13_5_IMPLEMENTATION_PLAN_KO/env-native.sh
label=$1
test ! -e "$CH13_NAV_EVIDENCE/$label.log"
export CMAKE_BUILD_PARALLEL_LEVEL=2
set +e
python /usr/bin/colcon --log-base "$CH13_NAV_LOG" build --base-paths Ch13/ros2_ws/src --build-base "$CH13_NAV_BUILD" --install-base "$CH13_NAV_INSTALL" --packages-select integrated_robot_navigation_sensors --executor sequential --cmake-args -DCMAKE_BUILD_TYPE=RelWithDebInfo > "$CH13_NAV_EVIDENCE/$label.log" 2>&1
result=$?
if test "$result" = 0; then
  source "$CH13_NAV_INSTALL/local_setup.bash"
  "$CH13_NAV_BUILD/integrated_robot_navigation_sensors/test_gazebo_position_system" >> "$CH13_NAV_EVIDENCE/$label.log" 2>&1
  result=$?
fi
tail -n 35 "$CH13_NAV_EVIDENCE/$label.log"
exit "$result"
