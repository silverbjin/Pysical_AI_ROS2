"""Navigation-owned ROS entities without unused warning-only QoS waitables.

Message QoS, callbacks and ownership are unchanged. Explicit event containers
are preserved. Missing/stale inputs still fail through the measured watchdog;
default incompatible-QoS/type log warnings are not a safety acknowledgement.
Only public rclpy APIs are used; no executor or middleware internals are patched.
"""
from rclpy.event_handler import PublisherEventCallbacks, SubscriptionEventCallbacks
from rclpy.lifecycle import LifecycleNode
from rclpy.node import Node


class _NavigationEvents:
    def create_publisher(self,*args,**kwargs):
        if kwargs.get('event_callbacks') is None:
            kwargs['event_callbacks']=PublisherEventCallbacks(use_default_callbacks=False)
        return super().create_publisher(*args,**kwargs)

    def create_subscription(self,*args,**kwargs):
        if kwargs.get('event_callbacks') is None:
            kwargs['event_callbacks']=SubscriptionEventCallbacks(use_default_callbacks=False)
        return super().create_subscription(*args,**kwargs)


class NavigationNode(_NavigationEvents,Node):
    pass


class NavigationLifecycleNode(_NavigationEvents,LifecycleNode):
    pass
