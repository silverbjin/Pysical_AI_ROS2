#!/usr/bin/env python3
import time
import threading
import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from moveit_msgs.action import MoveGroup
from moveit_msgs.msg import Constraints, PositionConstraint, OrientationConstraint, PositionIKRequest
from control_msgs.action import FollowJointTrajectory
from trajectory_msgs.msg import JointTrajectoryPoint
from tf2_ros import Buffer, TransformListener
from shape_msgs.msg import SolidPrimitive

class MissionController(Node):
    def __init__(self):
        super().__init__('mission_controller')

        self.is_working = False
        
        # 1. TF Listener 설정 (Point 토픽 대신 TF에서 직접 좌표 획득)
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        # 2. Action Clients
        self.move_group_client = ActionClient(self, MoveGroup, 'move_action')
        self.gripper_client = ActionClient(
            self, FollowJointTrajectory, '/gripper_controller/follow_joint_trajectory'
        )

        self.get_logger().info("Waiting for Action Servers...")
        # self.move_group_client.wait_for_server()
        # self.gripper_client.wait_for_server()
        self.get_logger().info("System Ready! Waiting for TF [target_object]...")

        # 3. FSM 트리거용 타이머 (주기적으로 타겟 TF 확인)
        self.timer = self.create_timer(1.0, self.check_target_and_execute)

    def check_target_and_execute(self):
        if self.is_working:
            return

        try:
            # base_link를 기준으로 target_object의 현재 위치를 가져옴
            transform = self.tf_buffer.lookup_transform(
                "base_link", "target_object", rclpy.time.Time()
            )
            
            target_x = transform.transform.translation.x
            target_y = transform.transform.translation.y
            target_z = transform.transform.translation.z
            
            self.get_logger().info(f"Target TF Detected: ({target_x:.3f}, {target_y:.3f}, {target_z:.3f})")
            
            # 작업을 별도의 스레드로 분리하여 ROS 2 Executor가 멈추지 않도록 함
            self.is_working = True
            threading.Thread(target=self.execute_pick_and_place, args=(target_x, target_y, target_z)).start()

        except Exception as e:
            # 타겟이 아직 발견되지 않았거나 TF가 방송되지 않은 경우 대기
            pass

    def execute_pick_and_place(self, t_x, t_y, t_z):
        try:
            # [Step 1] Pre-Grasp: 물체 상공 15cm
            self.get_logger().info(">>> [Step 1] Pre-Grasp Approach")
            self.move_arm(t_x, t_y, t_z + 0.15)
            self.control_gripper("open")
            time.sleep(1.0) 

            # [Step 2] Grasp Approach: 하강 (z + 0.02)
            self.get_logger().info(">>> [Step 2] Descending to Object")
            self.move_arm(t_x, t_y, t_z + 0.02) 
            time.sleep(0.5)

            # [Step 3] Grasping: 잡기
            self.get_logger().info(">>> [Step 3] Gripping")
            self.control_gripper("close")
            time.sleep(1.0) 

            # [Step 4] Post-Grasp: 들어 올리기
            self.get_logger().info(">>> [Step 4] Lifting")
            self.move_arm(t_x, t_y, t_z + 0.20)
            time.sleep(0.5)

            # [Step 5] Move to Bin (x=0.0, y=0.3, z=0.3)
            self.get_logger().info(">>> [Step 5] Moving to Bin")
            self.move_arm(0.0, 0.3, 0.3)
            time.sleep(1.0)

            # [Step 6] Release: 놓기
            self.get_logger().info(">>> [Step 6] Releasing")
            self.control_gripper("open")
            time.sleep(0.5)

            # [Step 7] Return Home (Action Client 방식에서는 관절 목표값으로 전송해야 하므로 여기서는 생략)
            self.get_logger().info(">>> [Step 7] Mission Complete.")

        except Exception as e:
            self.get_logger().error(f"Mission Failed: {e}")
        finally:
            self.is_working = False 

    def move_arm(self, x, y, z):
        """MoveGroup Action Client를 이용한 Cartesian 이동 로직 (교육용 단순화 구조)"""
        goal_msg = MoveGroup.Goal()
        goal_msg.request.group_name = "arm" # MoveIt Setup Assistant에서 설정한 그룹명
        
        # Position Constraint 생성
        pos_constraint = PositionConstraint()
        pos_constraint.header.frame_id = "base_link"
        pos_constraint.link_name = "end_effector_link" # 실제 URDF의 EEF 링크명으로 변경 필요
        
        # Bounding Volume을 작게 주어 해당 점으로 수렴하도록 설정
        bv = SolidPrimitive()
        bv.type = SolidPrimitive.SPHERE
        bv.dimensions = [0.01] # 1cm 오차 허용
        pos_constraint.constraint_region.primitives.append(bv)
        
        target_pose = PositionIKRequest().pose_stamped # Helper 구조 활용
        target_pose.pose.position.x = x
        target_pose.pose.position.y = y
        target_pose.pose.position.z = z
        pos_constraint.constraint_region.primitive_poses.append(target_pose.pose)
        
        goal_msg.request.workspace_parameters.header.frame_id = "base_link"
        goal_msg.request.goal_constraints.append(Constraints(position_constraints=[pos_constraint]))

        # 동기적 대기를 위해 async 호출 후 결과 대기 (스레드 내부이므로 안전함)
        future = self.move_group_client.send_goal_async(goal_msg)
        # rclpy.spin_until_future_complete(self, future) # 실제 구동 시 추가 필요
        self.get_logger().info(f"Commanded Arm to: {x:.2f}, {y:.2f}, {z:.2f}")

    def control_gripper(self, command):
        # ⭐ 그리퍼 반전 컨벤션 적용 (open: 0.025, close: 0.005)
        width = 0.025 if command == 'open' else 0.005 
        
        goal = FollowJointTrajectory.Goal()
        goal.trajectory.joint_names = ['gripper_joint']
        point = JointTrajectoryPoint()
        point.positions = [width]
        point.time_from_start.sec = 1
        goal.trajectory.points = [point]
        
        self.gripper_client.send_goal_async(goal)

def main(args=None):
    rclpy.init(args=args)
    controller = MissionController()
    rclpy.spin(controller)
    controller.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()