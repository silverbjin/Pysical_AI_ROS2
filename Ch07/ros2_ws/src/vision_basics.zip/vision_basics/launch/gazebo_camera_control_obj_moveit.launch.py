import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command, LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue

def generate_launch_description():
    # 1. 패키지 경로 및 설정 변수
    pkg_name = 'vision_basics'
    pkg_share = get_package_share_directory(pkg_name)  
    pkg_ros_gz_sim = get_package_share_directory('ros_gz_sim')
    
    # MoveIt 설정 패키지 경로 추가
    moveit_config_pkg = get_package_share_directory('my_robot_moveit_config')
    
    # 비전/컨트롤 통합 Xacro 파일 경로
    xacro_file = os.path.join(pkg_share, 'urdf', 'my_robot.ros2_camera_control_gazebo.urdf.xacro')
    
    # 큐브 객체용 SDF 파일 경로
    cube_sdf_file = os.path.join(pkg_share, 'models', 'test_box.sdf')
    
    # ⭐ RViz 설정 파일 경로 변경 (MoveIt Setup Assistant가 생성한 파일 사용)
    # MoveIt의 MotionPlanning 플러그인을 기본으로 로드하기 위함입니다.
    rviz_config_file = os.path.join(moveit_config_pkg, 'config', 'moveit.rviz')

    # 2. Launch Argument 설정
    use_sim_time = LaunchConfiguration('use_sim_time')
    
    # 3. Robot State Publisher (RSP) 실행
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[{
            'use_sim_time': use_sim_time,
            'robot_description': ParameterValue(Command(['xacro ', xacro_file]), value_type=str)
        }]
    )
    
    # 4. Gazebo Simulator 실행
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_ros_gz_sim, 'launch', 'gz_sim.launch.py')
        ),
        launch_arguments={'gz_args': '-r empty.sdf'}.items(),
    )

    # 5. 로봇 스폰 (Spawn) 노드
    spawn_entity = Node(
        package='ros_gz_sim',
        executable='create',
        arguments=[
            '-topic', 'robot_description',
            '-name', 'my_robot',
        ],
        output='screen'
    )

    # 5-2. 테스트 큐브(물체) 스폰 노드
    spawn_cube = Node(
        package='ros_gz_sim',
        executable='create',
        arguments=[
            '-file', cube_sdf_file,
            '-name', 'test_box',
            '-x', '1.0',  
            '-z', '0.025' 
        ],
        output='screen'
    )

    # 6. ROS-Gazebo 파라미터 브리지
    bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=[
            '/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock',
            '/camera/camera_info@sensor_msgs/msg/CameraInfo@gz.msgs.CameraInfo',
            "/camera/image@sensor_msgs/msg/Image@gz.msgs.Image",            
        ],
        remappings=[
            ("/camera/image", "/camera/image_raw"),
        ],        
        output='screen'
    )

    # 7. ROS-Gazebo 이미지 전용 브리지
    image_bridge = Node(
        package='ros_gz_image',
        executable='image_bridge',
        arguments=['/camera/image_raw'],
        output='screen'
    )

    # 8. RViz2 실행
    rviz = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        arguments=['-d', rviz_config_file],
        parameters=[{'use_sim_time': use_sim_time}],
        output='screen'
    )

    # 9. ros2_control 제어기 스폰 노드들
    load_joint_state_broadcaster = Node(
        package="controller_manager",
        executable="spawner",
        arguments=["joint_state_broadcaster", "--controller-manager", "/controller_manager"],
        output="screen",
    )

    load_arm_controller = Node(
        package="controller_manager",
        executable="spawner",
        arguments=["arm_controller", "--controller-manager", "/controller_manager"],
        output="screen",
    )

    load_gripper_controller = Node(
        package="controller_manager",
        executable="spawner",
        arguments=["gripper_controller", "--controller-manager", "/controller_manager"],
        output="screen",
    )

    # ================================================================= #
    # 10. ⭐ [핵심 추가] MoveIt 2 실행 (move_group)
    # ================================================================= #
    move_group_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(moveit_config_pkg, 'launch', 'move_group.launch.py')
        ),
        # Gazebo 시뮬레이션 시간을 MoveIt 2에도 반드시 동기화해야 합니다.
        launch_arguments={'use_sim_time': use_sim_time}.items(),
    )

    return LaunchDescription([
        DeclareLaunchArgument(
            'use_sim_time',
            default_value='true',
            description='Use simulation (Gazebo) clock if true'),
        
        robot_state_publisher,
        gazebo,
        spawn_entity,
        spawn_cube,
        bridge,
        image_bridge,  
        rviz,
        load_joint_state_broadcaster,
        load_arm_controller,
        load_gripper_controller,
        
        # MoveIt 노드 추가
        move_group_launch
    ])